package net.minecraft.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

import java.awt.*;

public class Gui {
    public static final ResourceLocation optionsBackground = new ResourceLocation("textures/gui/options_background.png");
    public static final ResourceLocation statIcons = new ResourceLocation("textures/gui/container/stats_icons.png");
    public static final ResourceLocation icons = new ResourceLocation("textures/gui/icons.png");
    public static float zLevel;
    //// = "CL_00000662";

    /**
     * Draw a 1 pixel wide vertical line. Args : x, y1, y2, color
     */

    public static void drawFilledCircle(int xx, int yy, float radius, Color col) {
        byte sections = 50;
        double dAngle = (Math.PI * 2D) / (double) sections;
        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);

        for (int i = 0; i < sections; ++i) {
            float x = (float) ((double) radius * Math.sin((double) i * dAngle));
            float y = (float) ((double) radius * Math.cos((double) i * dAngle));
            GL11.glColor4f((float) col.getRed() / 255.0F, (float) col.getGreen() / 255.0F, (float) col.getBlue() / 255.0F, (float) col.getAlpha() / 255.0F);
            GL11.glVertex2f((float) xx + x, (float) yy + y);
        }

        GlStateManager.color(0.0F, 0.0F, 0.0F);
        GL11.glEnd();
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glPopMatrix();
    }

    /**
     * Draws a solid color rectangle with the specified coordinates and color (ARGB format). Args: x1, y1, x2, y2, color
     */
    public static void drawRect(int left, int top, int right, int bottom, int color) {
        int var5;

        if (left < right) {
            var5 = left;
            left = right;
            right = var5;
        }

        if (top < bottom) {
            var5 = top;
            top = bottom;
            bottom = var5;
        }

        float var11 = (float) (color >> 24 & 255) / 255.0F;
        float var6 = (float) (color >> 16 & 255) / 255.0F;
        float var7 = (float) (color >> 8 & 255) / 255.0F;
        float var8 = (float) (color & 255) / 255.0F;
        Tessellator var9 = Tessellator.getInstance();
        WorldRenderer var10 = var9.getWorldRenderer();
        GlStateManager.enableBlend();
        GlStateManager.func_179090_x();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color(var6, var7, var8, var11);
        var10.startDrawingQuads();
        var10.addVertex((double) left, (double) bottom, 0.0D);
        var10.addVertex((double) right, (double) bottom, 0.0D);
        var10.addVertex((double) right, (double) top, 0.0D);
        var10.addVertex((double) left, (double) top, 0.0D);
        var9.draw();
        GlStateManager.func_179098_w();
        GlStateManager.disableBlend();
    }

    public static void drawRect(int left, int top, int right, int bottom, Color color) {
        int var5;

        if (left < right) {
            var5 = left;
            left = right;
            right = var5;
        }

        if (top < bottom) {
            var5 = top;
            top = bottom;
            bottom = var5;
        }

        Tessellator var9 = Tessellator.getInstance();
        WorldRenderer var10 = var9.getWorldRenderer();
        GlStateManager.enableBlend();
        GlStateManager.func_179090_x();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
        var10.startDrawingQuads();
        var10.addVertex((double) left, (double) bottom, 0.0D);
        var10.addVertex((double) right, (double) bottom, 0.0D);
        var10.addVertex((double) right, (double) top, 0.0D);
        var10.addVertex((double) left, (double) top, 0.0D);
        var9.draw();
        GlStateManager.func_179098_w();
        GlStateManager.disableBlend();
    }

    /**
     * Renders the specified text to the screen, center-aligned. Args : renderer, string, x, y, color
     */
    public static void drawCenteredString(FontRenderer fontRendererIn, String text, int x, int y, int color) {
        fontRendererIn.func_175063_a(text, (float) (x - fontRendererIn.getStringWidth(text) / 2), (float) y, color);
    }

    /**
     * Draws a textured rectangle at z = 0. Args: x, y, u, v, width, height, textureWidth, textureHeight
     */
    public static void drawModalRectWithCustomSizedTexture(int x, int y, float u, float v, int width, int height, float textureWidth, float textureHeight) {
        float var8 = 1.0F / textureWidth;
        float var9 = 1.0F / textureHeight;
        Tessellator var10 = Tessellator.getInstance();
        WorldRenderer var11 = var10.getWorldRenderer();
        var11.startDrawingQuads();
        var11.addVertexWithUV((double) x, (double) (y + height), 0.0D, (double) (u * var8), (double) ((v + (float) height) * var9));
        var11.addVertexWithUV((double) (x + width), (double) (y + height), 0.0D, (double) ((u + (float) width) * var8), (double) ((v + (float) height) * var9));
        var11.addVertexWithUV((double) (x + width), (double) y, 0.0D, (double) ((u + (float) width) * var8), (double) (v * var9));
        var11.addVertexWithUV((double) x, (double) y, 0.0D, (double) (u * var8), (double) (v * var9));
        var10.draw();
    }

    /**
     * Draws a scaled, textured, tiled modal rect at z = 0. This method isn't used anywhere in vanilla code.
     */

    public static void drawImage(ResourceLocation image, int x, int y, int width, int height) {
        ScaledResolution scaledResolution = new ScaledResolution(Minecraft.getMinecraft(), Minecraft.getMinecraft().displayWidth, Minecraft.getMinecraft().displayHeight);
        GL11.glDisable((int) GL11.GL_DEPTH_TEST);
        GL11.glEnable((int) GL11.GL_BLEND);
        GL11.glDepthMask((boolean) false);
        OpenGlHelper.glBlendFunc(770, 771, 1, 0);
        GL11.glColor4f((float) 1.0f, (float) 1.0f, (float) 1.0f, (float) 1.0f);
        Minecraft.getMinecraft().getTextureManager().bindTexture(image);
        Gui.drawModalRectWithCustomSizedTexture(x, y, 0.0f, 0.0f, width, height, width, height);
        GL11.glDepthMask((boolean) true);
        GL11.glDisable((int) GL11.GL_BLEND);
        GL11.glEnable((int) GL11.GL_DEPTH_TEST);
    }

    public static void drawScaledCustomSizeModalRect(double x2, double y2, float u2, float v2, double uWidth, double vHeight, double width, double height, float tileWidth, float tileHeight) {
        float var10 = 1.0f / tileWidth;
        float var11 = 1.0f / tileHeight;
        Tessellator var12 = Tessellator.getInstance();
        WorldRenderer var13 = var12.getWorldRenderer();
        var13.startDrawingQuads();
        var13.addVertexWithUV(x2, y2 + height, 0.0, u2 * var10, (v2 + (float) vHeight) * var11);
        var13.addVertexWithUV(x2 + width, y2 + height, 0.0, (u2 + (float) uWidth) * var10, (v2 + (float) vHeight) * var11);
        var13.addVertexWithUV(x2 + width, y2, 0.0, (u2 + (float) uWidth) * var10, v2 * var11);
        var13.addVertexWithUV(x2, y2, 0.0, u2 * var10, v2 * var11);
        var12.draw();
    }

    public static void drawFilledCircle(float xx, float yy, float radius, Color col) {
        int sections = 50;
        double dAngle = (Math.PI * 2D) / sections;
        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);

        for (int i = 0; i < sections; i++) {
            float x = (float) (radius * Math.sin(i * dAngle));
            float y = (float) (radius * Math.cos(i * dAngle));
            GL11.glColor4f(col.getRed() / 255.0F, col.getGreen() / 255.0F, col.getBlue() / 255.0F, col.getAlpha() / 255.0F);
            GL11.glVertex2f(xx + x, yy + y);
        }

        GlStateManager.color(0.0F, 0.0F, 0.0F);
        GL11.glEnd();
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glPopMatrix();
    }

    public static void drawFilledCircle(int xx, int yy, float radius, int col) {
        float f = (col >> 24 & 0xFF) / 255.0F;
        float f1 = (col >> 16 & 0xFF) / 255.0F;
        float f2 = (col >> 8 & 0xFF) / 255.0F;
        float f3 = (col & 0xFF) / 255.0F;
        int sections = 50;
        double dAngle = (Math.PI * 2D) / sections;
        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);

        for (int i = 0; i < sections; i++) {
            float x = (float) (radius * Math.sin(i * dAngle));
            float y = (float) (radius * Math.cos(i * dAngle));
            GL11.glColor4f(f1, f2, f3, f);
            GL11.glVertex2f(xx + x, yy + y);
        }

        GlStateManager.color(0.0F, 0.0F, 0.0F);
        GL11.glEnd();
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glPopMatrix();
    }

    public static void drawCircle(int x, int y, float radius, int startPi, int endPi, int c) {
        float f = ((c >> 24) & 0xff) / 255F;
        float f1 = ((c >> 16) & 0xff) / 255F;
        float f2 = ((c >> 8) & 0xff) / 255F;
        float f3 = (c & 0xff) / 255F;
        GL11.glColor4f(f1, f2, f3, f);
        GlStateManager.enableAlpha();
        GlStateManager.enableBlend();
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.alphaFunc(516, 0.001F);
        Tessellator tess = Tessellator.getInstance();
        WorldRenderer render = tess.getWorldRenderer();

        for (double i = startPi; i < endPi; i++) {
            double cs = i * Math.PI / 180;
            double ps = (i - 1) * Math.PI / 180;
            double[] outer = new double[]
                    {
                            Math.cos(cs) * radius, -Math.sin(cs) * radius,
                            Math.cos(ps) * radius, -Math.sin(ps) * radius
                    };
            render.startDrawing(6);
            render.addVertex(x + outer[2], y + outer[3], 0);
            render.addVertex(x + outer[0], y + outer[1], 0);
            render.addVertex(x, y, 0);
            tess.draw();
        }

        GlStateManager.color(0.0F, 0.0F, 0.0F);
        GlStateManager.disableBlend();
        GlStateManager.alphaFunc(516, 0.1F);
        GlStateManager.disableAlpha();
        GL11.glEnable(GL11.GL_TEXTURE_2D);
    }

    public static void drawCircle(float x, float y, float radius, int startPi, int endPi, int c) {
        float f = ((c >> 24) & 0xff) / 255F;
        float f1 = ((c >> 16) & 0xff) / 255F;
        float f2 = ((c >> 8) & 0xff) / 255F;
        float f3 = (c & 0xff) / 255F;
        GL11.glColor4f(f1, f2, f3, f);
        GlStateManager.enableAlpha();
        GlStateManager.enableBlend();
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.alphaFunc(516, 0.001F);
        Tessellator tess = Tessellator.getInstance();
        WorldRenderer render = tess.getWorldRenderer();

        for (double i = startPi; i < endPi; i++) {
            double cs = i * Math.PI / 180;
            double ps = (i - 1) * Math.PI / 180;
            double[] outer = new double[]
                    {
                            Math.cos(cs) * radius, -Math.sin(cs) * radius,
                            Math.cos(ps) * radius, -Math.sin(ps) * radius
                    };
            render.startDrawing(6);
            render.addVertex(x + outer[2], y + outer[3], 0);
            render.addVertex(x + outer[0], y + outer[1], 0);
            render.addVertex(x, y, 0);
            tess.draw();
        }

        GlStateManager.color(0.0F, 0.0F, 0.0F);
        GlStateManager.disableBlend();
        GlStateManager.alphaFunc(516, 0.1F);
        GlStateManager.disableAlpha();
        GL11.glEnable(GL11.GL_TEXTURE_2D);
    }

    public static void drawFilledCircle(float xx, float yy, float radius, int col) {
        float f = (col >> 24 & 0xFF) / 255.0F;
        float f1 = (col >> 16 & 0xFF) / 255.0F;
        float f2 = (col >> 8 & 0xFF) / 255.0F;
        float f3 = (col & 0xFF) / 255.0F;
        int sections = 50;
        double dAngle = (Math.PI * 2D) / sections;
        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);

        for (int i = 0; i < sections; i++) {
            float x = (float) (radius * Math.sin(i * dAngle));
            float y = (float) (radius * Math.cos(i * dAngle));
            GL11.glColor4f(f1, f2, f3, f);
            GL11.glVertex2f(xx + x, yy + y);
        }

        GlStateManager.color(0.0F, 0.0F, 0.0F);
        GL11.glEnd();
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glPopMatrix();
    }

    public static void drawFilledCircle(int xx, int yy, float radius, int col, int xLeft, int yAbove, int xRight, int yUnder) {
        //TODO: look here
        float f = (col >> 24 & 0xFF) / 255.0F;
        float f1 = (col >> 16 & 0xFF) / 255.0F;
        float f2 = (col >> 8 & 0xFF) / 255.0F;
        float f3 = (col & 0xFF) / 255.0F;
        int sections = 50;
        double dAngle = (Math.PI * 2D) / sections;
        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);

        for (int i = 0; i < sections; i++) {
            float x = (float) (radius * Math.sin(i * dAngle));
            float y = (float) (radius * Math.cos(i * dAngle));
            float xEnd = xx + x;
            float yEnd = yy + y;

            if (xEnd < xLeft) {
                xEnd = xLeft;
            }

            if (xEnd > xRight) {
                xEnd = xRight;
            }

            if (yEnd < yAbove) {
                yEnd = yAbove;
            }

            if (yEnd > yUnder) {
                yEnd = yUnder;
            }

            GL11.glColor4f(f1, f2, f3, f);
            GL11.glVertex2f(xEnd, yEnd);
        }

        GlStateManager.color(0.0F, 0.0F, 0.0F);
        GL11.glEnd();
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glPopMatrix();
    }

    public static void drawRainbowRectHorizontal(int x, int y, int x1, int y1, int segments, float alpha) {
        if (segments < 1) {
            segments = 1;
        }

        if (segments > x1 - x) {
            segments = x1 - x;
        }

        int segmentLength = (x1 - x) / segments;
        long time = System.nanoTime();

        for (int i = 0; i < segments; ++i) {
            drawRect(x + segmentLength * i, y, x + (segmentLength + 1) * i, y1, rainbow(time, (float) i, alpha));
        }
    }

    public static void drawRainbowRectVertical(int x, int y, int x1, int y1, int segments, float alpha) {
        if (segments < 1) {
            segments = 1;
        }

        if (segments > y1 - y) {
            segments = y1 - y;
        }

        int segmentLength = (y1 - y) / segments;
        long time = System.nanoTime();

        for (int i = 0; i < segments; ++i) {
            Minecraft.getMinecraft().ingameGUI.drawGradientRect(x, y + segmentLength * i - 1, x1, y + (segmentLength + 1) * i, rainbow(time, (float) i * 0.1F, alpha).getRGB(), rainbow(time, ((float) i + 0.1F) * 0.1F, alpha).getRGB());
        }
    }

    public static Color rainbow(long time, float count, float fade) {
        float hue = ((float) time + (1.0F + count) * 2.0E8F) / 1.0E10F % 1.0F;
        long color = Long.parseLong(Integer.toHexString(Integer.valueOf(Color.HSBtoRGB(hue, 1.0F, 1.0F)).intValue()), 16);
        Color c = new Color((int) color);
        return new Color((float) c.getRed() / 255.0F * fade, (float) c.getGreen() / 255.0F * fade, (float) c.getBlue() / 255.0F * fade, (float) c.getAlpha() / 255.0F);
    }

    public static void drawRect(float x1, float y1, float x2, float y2, int color) {
        GL11.glPushMatrix();
        GL11.glEnable((int) GL11.GL_BLEND);
        GL11.glDisable((int) GL11.GL_TEXTURE_2D);
        GL11.glBlendFunc((int) GL11.GL_SRC_ALPHA, (int) GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glEnable((int) GL11.GL_LINE_SMOOTH);
        GL11.glPushMatrix();
        color(color);
        GL11.glBegin((int) GL11.GL_QUADS);
        GL11.glVertex2d((double) x2, (double) y1);
        GL11.glVertex2d((double) x1, (double) y1);
        GL11.glVertex2d((double) x1, (double) y2);
        GL11.glVertex2d((double) x2, (double) y2);
        GL11.glEnd();
        GL11.glPopMatrix();
        GL11.glEnable((int) GL11.GL_TEXTURE_2D);
        GL11.glDisable((int) GL11.GL_BLEND);
        GL11.glDisable((int) GL11.GL_LINE_SMOOTH);
        GL11.glPopMatrix();
    }

    public static void color(int color) {
        float f = (float) (color >> 24 & 255) / 255.0f;
        float f1 = (float) (color >> 16 & 255) / 255.0f;
        float f2 = (float) (color >> 8 & 255) / 255.0f;
        float f3 = (float) (color & 255) / 255.0f;
        GL11.glColor4f((float) f1, (float) f2, (float) f3, (float) f);
    }

    public static void drawCircle(float xx, float yy, float radius, Color col) {
        byte sections = 70;
        double dAngle = (Math.PI * 2D) / (double) sections;
        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glLineWidth(1.0F);
        GL11.glShadeModel(GL11.GL_SMOOTH);
        GL11.glBegin(GL11.GL_LINE_LOOP);

        for (int i = 0; i < sections; ++i) {
            float x = (float) ((double) radius * Math.cos((double) i * dAngle));
            float y = (float) ((double) radius * Math.sin((double) i * dAngle));
            GL11.glColor4f((float) col.getRed() / 255.0F, (float) col.getGreen() / 255.0F, (float) col.getBlue() / 255.0F, (float) col.getAlpha() / 255.0F);
            GL11.glVertex2f(xx + x, yy + y);
        }

        GlStateManager.color(0.0F, 0.0F, 0.0F);
        GL11.glEnd();
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glPopMatrix();
    }

    public static void drawRoundedRect(float x, float y, float x2, float y2, float round, int color) {
        GlStateManager.disableBlend();
        x = (float) ((double) x + ((double) (round / 2.0f) + 0));
        y = (float) ((double) y + ((double) (round / 2.0f) + 0));
        x2 = (float) ((double) x2 - ((double) (round / 2.0f) + 0));
        y2 = (float) ((double) y2 - ((double) (round / 2.0f) + 0));
        // drawRect(x, y, x2, y2, color);
        drawCircle(x2 -  round / 2,  y +  round/ 2,  round, 0, 90, color);
        // Gui.drawFilledCircle(x + round / 2.0f, y2 - round / 2.0f, round, color);
        drawCircle( x +  round / 2,  y + round/ 2, round, 90, 180, color);
        // Gui.drawFilledCircle(x2 - round / 2.0f, y2 - round / 2.0f, round, color);
        drawCircle(x+round / 2.0f, y2 - round / 2.0f, round, 180, 270, color);
        //Gui.drawFilledCircle(x + round / 2.0f, y + round / 2.0f, round, color);
        drawCircle(x2 - round / 2.0f, y2- round / 2.0f , round, 270, 360, color);//right bottem
        drawRect(x - round / 2.0f, y + round / 2.0f, x2, y2 - round / 2.0f, color);
        drawRect(x2 + round / 2.0f - (round / 2), y + round / 2.0f, x2 + round / 2.0f, y2 - round / 2, color);
        drawRect(x + round / 2.0f, y - round / 2.0f, x2 - round / 2.0f, y + round / 2.0f, color);
        //drawRect(x + round / 2.0f, y, x2 - round / 2.0f, y2 + round / 2.0f, color);
        //Gui.drawRect(x - round / 2.0f, y, x2 + round / 2.0f, y2 - round / 2.0f + 0f, color);
        drawRect(x + round / 2.0f, y2 - round / 2.0f + 0f, x2 - round / 2.0f, y2 + round / 2.0f + 0f, color);
        GlStateManager.disableBlend();
    }

    public static void drawRoundedRectTop(float x, float y, float x2, float y2, float round, int color) {
        GlStateManager.disableBlend();
        x = (float) ((double) x + ((double) (round / 2.0f) + 0));
        y = (float) ((double) y + ((double) (round / 2.0f) + 0));
        x2 = (float) ((double) x2 - ((double) (round / 2.0f) + 0));
        y2 = (float) ((double) y2 - ((double) (round / 2.0f) + 0));
        // drawRect(x, y, x2, y2, color);
        drawCircle((int) x2 - (int) round / 2, (int) y + (int) round / 2, round, 0, 90, color);
        // Gui.drawFilledCircle(x + round / 2.0f, y2 - round / 2.0f, round, color);
        drawCircle((int) x + (int) round / 2, (int) y + (int) round / 2, round, 90, 180, color);
        // Gui.drawFilledCircle(x2 - round / 2.0f, y2 - round / 2.0f, round, color);

        drawRect(x - round / 2.0f, y + round / 2.0f, x2, y2 + round / 2.0f, color);
        drawRect(x2 + round / 2.0f - (round / 2), y + round / 2.0f, x2 + round / 2.0f, y2 + round / 2, color);
        drawRect(x + round / 2.0f, y - round / 2.0f, x2 - round / 2.0f, y + round / 2.0f, color);

        //drawRect(x + round / 2.0f, y, x2 - round / 2.0f, y2 + round / 2.0f, color);
        GlStateManager.disableBlend();
    }

    public static void drawRoundedRectBottem(float x, float y, float x2, float y2, float round, int color) {
        x = (float) ((double) x + ((double) (round / 2.0f) + 0));
        y = (float) ((double) y + ((double) (round / 2.0f) + 0));
        x2 = (float) ((double) x2 - ((double) (round / 2.0f) + 0));
        y2 = (float) ((double) y2 - ((double) (round / 2.0f) + 0));
        //Gui.drawFilledCircle(x2 - round / 2.0f, y + round / 2.0f, round, color);
        Gui.drawCircle(x + round / 2.0f, y2 - round / 2.0f, round, 180, 270, color);
        //Gui.drawFilledCircle(x + round / 2.0f, y + round / 2.0f, round, color);
        Gui.drawCircle(x2 - round / 2.0f, y2 - round / 2.0f, round, 270, 360, color);
        //Gui.drawRect(x - round / 2.0f - 0f, y - round / 2.0f - 0f, x2 + round / 2, y2 - round / 2.0f, color);
        //Gui.drawRect(x, y - round / 2.0f - 0f, x2 + round / 2.0f + 0f, y2 - round / 2.0f, color);
        //Gui.drawRect(x + round / 2.0f, y - round / 2.0f - 0f, x2 - round / 2.0f, y2 - round / 2.0f, color);
        Gui.drawRect(x - round / 2.0f, y, x2 + round / 2.0f, y2 - round / 2.0f + 0f, color);
        Gui.drawRect(x + round / 2.0f, y2 - round / 2.0f + 0f, x2 - round / 2.0f, y2 + round / 2.0f + 0f, color);
    }

    public static void drawRoundedRectBottemLeft(float x, float y, float x2, float y2, float round, int color) {
        x = (float) ((double) x + ((double) (round / 2.0f) + 0));
        y = (float) ((double) y + ((double) (round / 2.0f) + 0));
        x2 = (float) ((double) x2 - ((double) (round / 2.0f) + 0));
        y2 = (float) ((double) y2 - ((double) (round / 2.0f) + 0));
        //Gui.drawRect(x, y, x2, y2, color);
        //Gui.drawFilledCircle(x2 - round / 2.0f, y + round / 2.0f, round, color);
        Gui.drawCircle(x + round / 2.0f, y2 - round / 2.0f, round, 180, 270, color);
        //Gui.drawFilledCircle(x + round / 2.0f, y + round / 2.0f, round, color);
        //Gui.drawFilledCircle(x2 - round / 2.0f, y2 - round / 2.0f, round, color);
        Gui.drawRect(x - round / 2.0f - 0f, y, x + round / 2.0f - 0f, y2 - round / 2.0f, color);
        // Gui.drawRect(x, y - round / 2.0f - 0f, x2 + round / 2.0f + 0f, y2 - round / 2.0f, color);
        // Gui.drawRect(x + round / 2.0f, y - round / 2.0f - 0f, x2 - round / 2.0f, y2 - round / 2.0f, color);
        Gui.drawRect(x + round / 2.0f, y, x2 + round / 2.0f, y2 + round / 2.0f + 0f, color);
    }

    public static void drawRoundedRectBottemRight(float x, float y, float x2, float y2, float round, int color) {
        x = (float) ((double) x + ((double) (round / 2.0f) + 0));
        y = (float) ((double) y + ((double) (round / 2.0f) + 0));
        x2 = (float) ((double) x2 - ((double) (round / 2.0f) + 0));
        y2 = (float) ((double) y2 - ((double) (round / 2.0f) + 0));
        //Gui.drawFilledCircle(x2 - round / 2.0f, y + round / 2.0f, round, color);
        // Gui.drawCircle(x + round / 2.0f, y2 - round / 2.0f, round,180,270, color);
        //Gui.drawFilledCircle(x + round / 2.0f, y + round / 2.0f, round, color);
        Gui.drawCircle(x2 - round / 2.0f, y2 - round / 2.0f, round, 270, 360, color);
        //Gui.drawRect(x - round / 2.0f - 0f, y - round / 2.0f - 0f, x2 + round / 2, y2 - round / 2.0f, color);
        //Gui.drawRect(x, y - round / 2.0f - 0f, x2 + round / 2.0f + 0f, y2 - round / 2.0f, color);
        //Gui.drawRect(x + round / 2.0f, y - round / 2.0f - 0f, x2 - round / 2.0f, y2 - round / 2.0f, color);
        Gui.drawRect(x - round / 2.0f, y, x2 + round / 2.0f, y2 - round / 2.0f + 0f, color);
        Gui.drawRect(x - round / 2.0f, y2 - round / 2.0f + 0f, x2 - round / 2.0f, y2 + round / 2.0f + 0f, color);
    }

    public static void circle(float x, float y, float radius, int fill) {
        arc(x, y, 0.0F, 360.0F, radius, fill);
    }

    public static void circle(float x, float y, float radius, Color fill) {
        arc(x, y, 0.0F, 360.0F, radius, fill);
    }

    public static void arc(float x, float y, float start, float end, float radius, int color) {
        arcEllipse(x, y, start, end, radius, radius, color);
    }

    public static void arc(float x, float y, float start, float end, float radius, Color color) {
        arcEllipse(x, y, start, end, radius, radius, color);
    }

    public static void arcEllipse(float x, float y, float start, float end, float w, float h, int color) {
        GlStateManager.color(0.0F, 0.0F, 0.0F);
        GL11.glColor4f(0.0F, 0.0F, 0.0F, 0.0F);
        float temp = 0.0F;

        if (start > end) {
            temp = end;
            end = start;
            start = temp;
        }

        float var11 = (float) (color >> 24 & 255) / 255.0F;
        float var6 = (float) (color >> 16 & 255) / 255.0F;
        float var7 = (float) (color >> 8 & 255) / 255.0F;
        float var8 = (float) (color & 255) / 255.0F;
        Tessellator var9 = Tessellator.getInstance();
        WorldRenderer var10 = var9.getWorldRenderer();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color(var6, var7, var8, var11);
        float i;
        float ldx;
        float ldy;

        if (var11 > 0.5F) {
            GL11.glEnable(GL11.GL_LINE_SMOOTH);
            GL11.glLineWidth(2.0F);
            GL11.glBegin(GL11.GL_LINE_STRIP);

            for (i = end; i >= start; i -= 4.0F) {
                ldx = (float) Math.cos((double) i * Math.PI / 180.0D) * w * 1.001F;
                ldy = (float) Math.sin((double) i * Math.PI / 180.0D) * h * 1.001F;
                GL11.glVertex2f(x + ldx, y + ldy);
            }

            GL11.glEnd();
            GL11.glDisable(GL11.GL_LINE_SMOOTH);
        }

        GL11.glBegin(GL11.GL_TRIANGLE_FAN);

        for (i = end; i >= start; i -= 4.0F) {
            ldx = (float) Math.cos((double) i * Math.PI / 180.0D) * w;
            ldy = (float) Math.sin((double) i * Math.PI / 180.0D) * h;
            GL11.glVertex2f(x + ldx, y + ldy);
        }

        GL11.glEnd();
        GlStateManager.disableBlend();
    }

    public static void arcEllipse(float x, float y, float start, float end, float w, float h, Color color) {
        GlStateManager.color(0.0F, 0.0F, 0.0F);
        GL11.glColor4f(0.0F, 0.0F, 0.0F, 0.0F);
        float temp = 0.0F;

        if (start > end) {
            temp = end;
            end = start;
            start = temp;
        }

        Tessellator var9 = Tessellator.getInstance();
        WorldRenderer var10 = var9.getWorldRenderer();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color((float) color.getRed() / 255.0F, (float) color.getGreen() / 255.0F, (float) color.getBlue() / 255.0F, (float) color.getAlpha() / 255.0F);
        float i;
        float ldx;
        float ldy;

        if ((float) color.getAlpha() > 0.5F) {
            GL11.glEnable(GL11.GL_LINE_SMOOTH);
            GL11.glLineWidth(2.0F);
            GL11.glBegin(GL11.GL_LINE_STRIP);

            for (i = end; i >= start; i -= 4.0F) {
                ldx = (float) Math.cos((double) i * Math.PI / 180.0D) * w * 1.001F;
                ldy = (float) Math.sin((double) i * Math.PI / 180.0D) * h * 1.001F;
                GL11.glVertex2f(x + ldx, y + ldy);
            }

            GL11.glEnd();
            GL11.glDisable(GL11.GL_LINE_SMOOTH);
        }

        GL11.glBegin(GL11.GL_TRIANGLE_FAN);

        for (i = end; i >= start; i -= 4.0F) {
            ldx = (float) Math.cos((double) i * Math.PI / 180.0D) * w;
            ldy = (float) Math.sin((double) i * Math.PI / 180.0D) * h;
            GL11.glVertex2f(x + ldx, y + ldy);
        }

        GL11.glEnd();
        GlStateManager.disableBlend();
    }

    /**
     * Draw a 1 pixel wide horizontal line. Args: x1, x2, y, color
     */
    public void drawHorizontalLine(int startX, int endX, int y, int color) {
        if (endX < startX) {
            int var5 = startX;
            startX = endX;
            endX = var5;
        }

        drawRect(startX, y, endX + 1, y + 1, color);
    }

    protected void drawVerticalLine(int x, int startY, int endY, int color) {
        if (endY < startY) {
            int var5 = startY;
            startY = endY;
            endY = var5;
        }

        drawRect(x, startY + 1, x + 1, endY, color);
    }

    /**
     * Draws a rectangle with a vertical gradient between the specified colors (ARGB format). Args : x1, y1, x2, y2,
     * topColor, bottomColor
     */
    public void drawGradientRect(int left, int top, int right, int bottom, int startColor, int endColor) {
        float var7 = (float) (startColor >> 24 & 255) / 255.0F;
        float var8 = (float) (startColor >> 16 & 255) / 255.0F;
        float var9 = (float) (startColor >> 8 & 255) / 255.0F;
        float var10 = (float) (startColor & 255) / 255.0F;
        float var11 = (float) (endColor >> 24 & 255) / 255.0F;
        float var12 = (float) (endColor >> 16 & 255) / 255.0F;
        float var13 = (float) (endColor >> 8 & 255) / 255.0F;
        float var14 = (float) (endColor & 255) / 255.0F;
        GlStateManager.func_179090_x();
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.shadeModel(7425);
        Tessellator var15 = Tessellator.getInstance();
        WorldRenderer var16 = var15.getWorldRenderer();
        var16.startDrawingQuads();
        var16.func_178960_a(var8, var9, var10, var7);
        var16.addVertex((double) right, (double) top, (double) this.zLevel);
        var16.addVertex((double) left, (double) top, (double) this.zLevel);
        var16.func_178960_a(var12, var13, var14, var11);
        var16.addVertex((double) left, (double) bottom, (double) this.zLevel);
        var16.addVertex((double) right, (double) bottom, (double) this.zLevel);
        var15.draw();
        GlStateManager.shadeModel(7424);
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.func_179098_w();
    }

    /**
     * Renders the specified text to the screen. Args : renderer, string, x, y, color
     */
    public void drawString(FontRenderer fontRendererIn, String text, int x, int y, int color) {
        fontRendererIn.func_175063_a(text, (float) x, (float) y, color);
    }

    /**
     * Draws a textured rectangle at the stored z-value. Args: x, y, u, v, width, height
     */
    public void drawTexturedModalRect(int x, int y, int textureX, int textureY, int width, int height) {
        float var7 = 0.00390625F;
        float var8 = 0.00390625F;
        Tessellator var9 = Tessellator.getInstance();
        WorldRenderer var10 = var9.getWorldRenderer();
        var10.startDrawingQuads();
        var10.addVertexWithUV((double) (x + 0), (double) (y + height), (double) this.zLevel, (double) ((float) (textureX + 0) * var7), (double) ((float) (textureY + height) * var8));
        var10.addVertexWithUV((double) (x + width), (double) (y + height), (double) this.zLevel, (double) ((float) (textureX + width) * var7), (double) ((float) (textureY + height) * var8));
        var10.addVertexWithUV((double) (x + width), (double) (y + 0), (double) this.zLevel, (double) ((float) (textureX + width) * var7), (double) ((float) (textureY + 0) * var8));
        var10.addVertexWithUV((double) (x + 0), (double) (y + 0), (double) this.zLevel, (double) ((float) (textureX + 0) * var7), (double) ((float) (textureY + 0) * var8));
        var9.draw();
    }

    public void func_175174_a(float p_175174_1_, float p_175174_2_, int p_175174_3_, int p_175174_4_, int p_175174_5_, int p_175174_6_) {
        float var7 = 0.00390625F;
        float var8 = 0.00390625F;
        Tessellator var9 = Tessellator.getInstance();
        WorldRenderer var10 = var9.getWorldRenderer();
        var10.startDrawingQuads();
        var10.addVertexWithUV((double) (p_175174_1_ + 0.0F), (double) (p_175174_2_ + (float) p_175174_6_), (double) this.zLevel, (double) ((float) (p_175174_3_ + 0) * var7), (double) ((float) (p_175174_4_ + p_175174_6_) * var8));
        var10.addVertexWithUV((double) (p_175174_1_ + (float) p_175174_5_), (double) (p_175174_2_ + (float) p_175174_6_), (double) this.zLevel, (double) ((float) (p_175174_3_ + p_175174_5_) * var7), (double) ((float) (p_175174_4_ + p_175174_6_) * var8));
        var10.addVertexWithUV((double) (p_175174_1_ + (float) p_175174_5_), (double) (p_175174_2_ + 0.0F), (double) this.zLevel, (double) ((float) (p_175174_3_ + p_175174_5_) * var7), (double) ((float) (p_175174_4_ + 0) * var8));
        var10.addVertexWithUV((double) (p_175174_1_ + 0.0F), (double) (p_175174_2_ + 0.0F), (double) this.zLevel, (double) ((float) (p_175174_3_ + 0) * var7), (double) ((float) (p_175174_4_ + 0) * var8));
        var9.draw();
    }

    public void func_175175_a(int p_175175_1_, int p_175175_2_, TextureAtlasSprite p_175175_3_, int p_175175_4_, int p_175175_5_) {
        Tessellator var6 = Tessellator.getInstance();
        WorldRenderer var7 = var6.getWorldRenderer();
        var7.startDrawingQuads();
        var7.addVertexWithUV((double) (p_175175_1_ + 0), (double) (p_175175_2_ + p_175175_5_), (double) this.zLevel, (double) p_175175_3_.getMinU(), (double) p_175175_3_.getMaxV());
        var7.addVertexWithUV((double) (p_175175_1_ + p_175175_4_), (double) (p_175175_2_ + p_175175_5_), (double) this.zLevel, (double) p_175175_3_.getMaxU(), (double) p_175175_3_.getMaxV());
        var7.addVertexWithUV((double) (p_175175_1_ + p_175175_4_), (double) (p_175175_2_ + 0), (double) this.zLevel, (double) p_175175_3_.getMaxU(), (double) p_175175_3_.getMinV());
        var7.addVertexWithUV((double) (p_175175_1_ + 0), (double) (p_175175_2_ + 0), (double) this.zLevel, (double) p_175175_3_.getMinU(), (double) p_175175_3_.getMinV());
        var6.draw();
    }
}
