package net.minecraft.client;

public class ClientBrandRetriever {
    //// = "CL_00001460";

    public static String getClientModName() {
        return "vanilla";
    }
}
