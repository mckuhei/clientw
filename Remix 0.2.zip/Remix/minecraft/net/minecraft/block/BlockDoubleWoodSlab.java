package net.minecraft.block;

public class BlockDoubleWoodSlab extends BlockWoodSlab {
    //// = "CL_00002112";

    public boolean isDouble() {
        return true;
    }
}
