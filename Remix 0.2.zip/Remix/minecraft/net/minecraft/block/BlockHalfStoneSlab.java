package net.minecraft.block;

public class BlockHalfStoneSlab extends BlockStoneSlab {
    //// = "CL_00002108";

    public boolean isDouble() {
        return false;
    }
}
