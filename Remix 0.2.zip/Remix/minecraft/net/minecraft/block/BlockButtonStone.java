package net.minecraft.block;

public class BlockButtonStone extends BlockButton {
    //// = "CL_00000319";

    protected BlockButtonStone() {
        super(false);
    }
}
