package net.minecraft.block;

public class BlockDoubleStoneSlab extends BlockStoneSlab {
    //// = "CL_00002113";

    public boolean isDouble() {
        return true;
    }
}
