package net.minecraft.block;

public class BlockDoubleStoneSlabNew extends BlockStoneSlabNew {
    //// = "CL_00002114";

    public boolean isDouble() {
        return true;
    }
}
