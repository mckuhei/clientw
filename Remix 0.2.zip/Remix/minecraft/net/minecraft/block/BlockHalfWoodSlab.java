package net.minecraft.block;

public class BlockHalfWoodSlab extends BlockWoodSlab {
    //// = "CL_00002107";

    public boolean isDouble() {
        return false;
    }
}
