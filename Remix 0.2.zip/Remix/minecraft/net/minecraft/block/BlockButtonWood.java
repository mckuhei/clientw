package net.minecraft.block;

public class BlockButtonWood extends BlockButton {
    //// = "CL_00000336";

    protected BlockButtonWood() {
        super(true);
    }
}
