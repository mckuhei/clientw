package me.remixclient.client.font;

import java.awt.*;

public class FontManager {

    public static MinecraftFontRenderer clickGuiFont;

    public void loadFonts() {
        clickGuiFont = new MinecraftFontRenderer(new Font("Comfortaa", Font.PLAIN, 20), true, true);
    }
}
