package me.remixclient.client.csgogui;

public class CSGOGuiHelper {
    public static String lastCategory = null;
}
