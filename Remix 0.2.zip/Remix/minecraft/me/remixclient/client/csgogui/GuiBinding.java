package me.remixclient.client.csgogui;

import me.satisfactory.base.module.Module;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiYesNoCallback;
import org.lwjgl.input.Keyboard;

public class GuiBinding
        extends GuiScreen
        implements GuiYesNoCallback {
    private Module mod;
    private int keyBind = 0;
    private GuiScreen prevScreen;

    public GuiBinding(Module m, CSGOGuiScreen prev) {
        this.mod = m;
        this.keyBind = this.mod.getKeybind();
        this.prevScreen = prev;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        super.drawScreen(mouseX, mouseY, partialTicks);
        mc.fontRendererObj.drawString(this.mod.getName(), (float) (width / 2) - mc.fontRendererObj.getStringWidth(this.mod.getName()) / 2.0f, height / 2 - 30, -16777216);
        mc.fontRendererObj.drawString("Current Bind: " + Keyboard.getKeyName((int) this.keyBind), (float) (width / 2) - mc.fontRendererObj.getStringWidth("Current Bind: " + Keyboard.getKeyName((int) this.keyBind)) / 2.0f, height / 2 - 15 - 1, -16777216);
        mc.fontRendererObj.drawString("Press Space to unbind " + this.mod.getName() + "!", (float) (width / 2) - mc.fontRendererObj.getStringWidth("Press Space to unbind " + this.mod.getName() + "!") / 2.0f, height / 2 - 1, -16777216);
        mc.fontRendererObj.drawString("Press Escape to exit!", (float) (width / 2) - mc.fontRendererObj.getStringWidth("Press Escape to exit!") / 2.0f, height / 2 + 15, -1);
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) {
        /* if (keyCode == 1) {
             MiscellaneousUtil.sendClientMessage("Binding process cancelled!");
         } else if (keyCode == 57) {
             this.mod.setKeybind(0);
             MiscellaneousUtil.sendClientMessage("Resetted keybind of module \"" + this.mod.getName() + "\"!");
         } else {
             this.mod.setKeybind(keyCode);
             MiscellaneousUtil.sendClientMessage("Bound module \"" + this.mod.getName() + "\" to key " + Keyboard.getKeyName((int)keyCode) + "!");
             ClientMain.notificationManager.addNotification(new Notification("", "Bound module \"" + this.mod.getName() + "\" to key " + Keyboard.getKeyName((int)keyCode) + "!", 1000));
         }*/
        this.keyBind = keyCode;
        mc.displayGuiScreen(this.prevScreen);
    }
}
