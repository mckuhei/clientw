package me.remixclient.client.csgogui;

import me.remixclient.client.font.MinecraftFontRenderer;
import me.satisfactory.base.Base;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Mode;
import me.satisfactory.base.module.Module;
import me.satisfactory.base.setting.Setting;
import me.satisfactory.base.utils.FontUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.*;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.awt.*;

public class CSGOGuiScreen extends GuiScreen implements GuiYesNoCallback {
    public static String currentCategory = null;
    public static String currentConfig = null;
    public static String currentKeybindConfig = null;
    public static String currentOpenedModule = null;
    public static boolean isModInfoShown = false;
    public static float delta;
    /* The Full Part */
    public static int ScaleX = 248;
    /* The Bottem Part */
    public static int YHeight = 70;
    public static int Bottemheight = 230;
    public static int BarHeight = 25;
    public boolean dragging;
    boolean mouse;
    boolean previousmouse = true;
    boolean Changed = false;
    /* The Full Part */
    boolean AddedMode = false;
    boolean AddedCheck = false;
    boolean AddedSlider = false;
    Color SideColor = new Color(41, 49, 62);
    /* The Bottem Part */
    Color MiddelColor = new Color(229, 229, 229);
    /* The Bar Part */
    Color BarColor = new Color(23, 30, 42);
    Color BorderColor = new Color(23, 30, 42);

    int BorderSize = 2;
    int IconHeight = 30;
    int BarSize = 55;

    /* The Bar Part */
    int endNumber;
    int OtherEndNumb;
    int CircleSize = 16;
    boolean hasDone;
    int width;
    int height;
    int topheight = 30;
    int Add = 1;
    FontUtils fu_default = new FontUtils("Comfortaa", Font.PLAIN, 18);


    @Override
    public void onGuiClosed() {
        if (this.mc.entityRenderer.theShaderGroup != null) {
            this.mc.entityRenderer.theShaderGroup.deleteShaderGroup();
            this.mc.entityRenderer.theShaderGroup = null;
        }
    }


    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {


        Color shadowColor = new Color(0, 0, 0, 0).darker();
        BarHeight = YHeight - BarSize + 5;
        IconHeight = YHeight - BarSize + 17;
        BarSize = 55;
        int shadowOffsetX = 4;
        int shadowOffsetY = 4;
        NotSkidded1:
        {
            NoSkidded2:
            {
                super.drawScreen(mouseX, mouseY, partialTicks);
                ScaledResolution sr = new ScaledResolution(this.mc, this.mc.displayWidth, this.mc.displayHeight);
                width = sr.getScaledWidth();
                height = sr.getScaledHeight();
                YHeight = height / 2 - (Bottemheight / 2);

                if (!Mouse.isButtonDown((int) 0)) {
                    this.previousmouse = false;
                }

                // Gui.drawRect(75, this.topheight+ 8, width - 75, this.topheight +
                // this.topheight+ 8, -1442840576);
                //MiscellaneousUtil.addChatMessage(width / 2 + ScaleX + "");
                Gui.drawRoundedRectTop(width / 2 - ScaleX - shadowOffsetX, BarHeight - shadowOffsetY, width / 2 + ScaleX + shadowOffsetX, BarHeight + BarSize + shadowOffsetY,
                        10, shadowColor.getRGB());
                Gui.drawRoundedRectTop(width / 2 - ScaleX, BarHeight, width / 2 + ScaleX, BarHeight + BarSize,
                        10, BarColor.getRGB());
                // Gui.drawRect(72, this.topheight + this.topheight+ 8, width - 72,
                // this.topheight + this.topheight + 3+ 8, Base.INSTANCE.GetMainColor());
                // Gui.drawRect(72, this.topheight+ 8, 75, this.topheight + this.topheight+ 8,
                // Base.INSTANCE.GetMainColor());
                // Gui.drawRect(width - 72, this.topheight+ 8, width - 75, this.topheight +
                // this.topheight+ 8, Base.INSTANCE.GetMainColor());
                int xCount = width / 2 - ScaleX + 20;
                Category[] iterator = Category.values();
                int n = iterator.length;
                int n2 = 0;

                while (n2 < n) {
                    Category c = iterator[n2];

                    if (!c.name().equalsIgnoreCase("HIDDEN")) {
                        mc.fontRendererObj.drawString("", xCount, IconHeight + 5 + 7, -1);
                        this.mc.getTextureManager()
                                .bindTexture(new ResourceLocation("remix/CSGOIcons/" + c.name() + ".png"));
                        ScaledResolution scaledRes = new ScaledResolution(this.mc, this.mc.displayWidth,
                                this.mc.displayHeight);

                        if (c.name().equals("COMBAT")) {
                            Gui.drawImage(new ResourceLocation("remix/CSGOIcons/" + c.name() + ".png"),xCount + 2, IconHeight - 4, 35, 35);
                        } else if (c.name().equals("PLAYER")) {
                            Gui.drawImage(new ResourceLocation("remix/CSGOIcons/" + c.name() + ".png"),xCount + 5, IconHeight - 4,  35, 35);
                        } else if (c.name().equals("WORLD")) {
                            Gui.drawImage(new ResourceLocation("remix/CSGOIcons/" + c.name() + ".png"),xCount - 1, IconHeight - 6,  40, 40);
                        } else {
                            Gui.drawImage(new ResourceLocation("remix/CSGOIcons/" + c.name() + ".png"),xCount, IconHeight - 8,  45, 45);
                        }

                        try {
                            if (this.isCategoryHovered(xCount - 15, IconHeight - 8,
                                    xCount + (ScaleX + ScaleX) / (Category.values().length - 1) - 21, IconHeight + 40,
                                    mouseX, mouseY) && Mouse.isButtonDown((int) 0)) {
                                currentCategory = c.name();
                            }
                        } catch (Exception e) {
                            System.err.println(e);
                        }
                        if (currentCategory != null && currentCategory.equalsIgnoreCase(c.name())) {
                            Gui.drawRect(xCount - 1, IconHeight + 25 + 15,
                                    xCount + Base.INSTANCE.getFontManager().clickGuiFont.getStringWidth(c.name()) - 1,
                                    (int) YHeight + 10 + 15, SideColor.getRGB());
                            CSGOGuiHelper.lastCategory = currentCategory;
                        }

                        xCount += (ScaleX + ScaleX) / (Category.values().length - 1);
                    }

                    ++n2;
                }

                /*	Base.INSTANCE.getFontManager().clickGuiFont.drawString("", xCount, IconHeight + 5 + 7, -1);
                	this.mc.getTextureManager()
                			.bindTexture(new ResourceLocation("remix/CSGOIcons/" + "CUSTOMIZATION" + ".png"));
                	//ScaledResolution sr = new ScaledResolution(this.mc, this.mc.displayWidth,
                			//this.mc.displayHeight);

                		Gui.drawScaledCustomSizeModalRect(xCount + 2, IconHeight - 4, 0.0f, 0.0f,
                				sr.getScaledWidth(), sr.getScaledHeight(), 35, 35,
                				sr.getScaledWidth(), sr.getScaledHeight());
                		if (this.isCategoryHovered(xCount, IconHeight,
                				xCount + (int) Base.INSTANCE.getFontManager().clickGuiFont.getStringWidth("COMBAT"), IconHeight + IconHeight,
                				mouseX, mouseY) && Mouse.isButtonDown((int) 0)) {
                			currentCategory = "CUSTOMIZATION";
                		}
                		if (currentCategory == null || currentCategory.equalsIgnoreCase("CONFIGS")
                				|| currentCategory.equalsIgnoreCase("HIDDEN"))
                			break block146;
                		if (currentCategory.equalsIgnoreCase("CUSTOMIZATION")) {
                			Gui.drawRect(xCount - 1, IconHeight + 25 + 8,
                					xCount + Base.INSTANCE.getFontManager().clickGuiFont.getStringWidth("Combat") - 1,
                					(int) this.topheight + (int) this.topheight + 8, SideColor.getRGB());
                			CSGOGuiHelper.lastCategory = currentCategory;
                		}

                	*/
                Gui.drawRoundedRectBottem(width / 2 - ScaleX - shadowOffsetX, YHeight + shadowOffsetY, width / 2 + ScaleX + shadowOffsetX, YHeight + Bottemheight + shadowOffsetY,
                        10, shadowColor.getRGB());
                Gui.drawRoundedRectBottem(width / 2 - ScaleX, YHeight, width / 2 + ScaleX, YHeight + Bottemheight,
                        10, MiddelColor.getRGB());
                /* Gui.drawRoundedRectBottemLeft(width / 2 - ScaleX - shadowOffsetX, YHeight - shadowOffsetY, width / 2 - ScaleX + 100 + shadowOffsetX, YHeight + Bottemheight+ shadowOffsetY,
                         10, shadowColor.getRGB());*/
                Gui.drawRoundedRectBottemLeft(width / 2 - ScaleX, YHeight, width / 2 - ScaleX + 100, YHeight + Bottemheight,
                        10, SideColor.getRGB());
                /*Gui.drawRect(width / 2 - ScaleX + 100, YHeight, width / 2 - ScaleX + 100 + BorderSize, YHeight + Bottemheight,
                		BorderColor.getRGB());

                Gui.drawRect(width / 2 - ScaleX, YHeight, width / 2 - ScaleX + BorderSize, YHeight + Bottemheight,
                		BorderColor.getRGB());
                Gui.drawRect(width / 2 - ScaleX, YHeight + Bottemheight - BorderSize, width / 2 + ScaleX, YHeight + Bottemheight,
                		BorderColor.getRGB());
                Gui.drawRect(width / 2 + ScaleX - BorderSize, YHeight,width / 2 + ScaleX, YHeight + Bottemheight,
                		BorderColor.getRGB());*/
                /*Gui.drawRect(width / 2 - ScaleX, YHeight, width / 2 + ScaleX , YHeight + Bottemheight,
                		MiddelColor.getRGB());
                Gui.drawRect(width / 2 - ScaleX, YHeight, width / 2 - ScaleX + BorderSize, YHeight + Bottemheight,
                		BorderColor.getRGB());
                Gui.drawRect(width / 2 - ScaleX, YHeight + Bottemheight - BorderSize, width / 2 + ScaleX, YHeight + Bottemheight,
                		BorderColor.getRGB());
                Gui.drawRect(width / 2 + ScaleX - BorderSize, YHeight,width / 2 + ScaleX, YHeight + Bottemheight,
                		BorderColor.getRGB());
                Base.INSTANCE.uic.draw(mouseX, mouseY);
                */
                // Gui.drawRect(72, this.topheight + this.topheight + 7, width - 72,
                // this.topheight + this.topheight + 10, Base.INSTANCE.GetMainColor());
                // Gui.drawRect(72, height - this.topheight + 3, width - 72, height -
                // this.topheight, Base.INSTANCE.GetMainColor());
                // Gui.drawRect(72, this.topheight + this.topheight + 7, 75, height -
                // this.topheight + 3, Base.INSTANCE.GetMainColor());
                // Gui.drawRect(width - 72, this.topheight + this.topheight + 7, width - 75,
                // height - this.topheight + 3, Base.INSTANCE.GetMainColor());
                int yOffset = YHeight + 15;
                int xOffset = width / 2 - ScaleX + 42;
                /*if (currentCategory.equalsIgnoreCase("CUSTOMIZATION")) {
                }*/

                for (Module m : Base.INSTANCE.getModuleManager().modules.values()) {
//TODO: here is the mod strings
                    if (!m.getCategory().name().equalsIgnoreCase(currentCategory)) {
                        continue;
                    }

                    if (m.isEnabled()) {
                        Base.INSTANCE.getFontManager().clickGuiFont.drawString(m.getName(), xOffset - (Base.INSTANCE.getFontManager().clickGuiFont.getStringWidth(m.getName()) / 2f), yOffset,
                                Color.WHITE.getRGB());
                        // Gui.drawRect(155, yOffset + 4 - 5, 166, yOffset + 15- 5, -1442840576);
                        // Gui.drawRect(157, yOffset + 6- 5, 164, yOffset + 13- 5, new
                        // Color(229,229,229).getRGB());
                    } else {
                        Base.INSTANCE.getFontManager().clickGuiFont.drawString(m.getName(), xOffset - (Base.INSTANCE.getFontManager().clickGuiFont.getStringWidth(m.getName()) / 2f), yOffset,
                                Color.gray.getRGB());
                        // Gui.drawRect(155, yOffset + 4- 5, 166, yOffset + 15- 5, -1442840576);
                    }

                    if (isSettingsButtonHovered(xOffset - (Base.INSTANCE.getFontManager().clickGuiFont.getStringWidth(m.getName()) / 2), yOffset - 2,
                            xOffset + (Base.INSTANCE.getFontManager().clickGuiFont.getStringWidth(m.getName()) / 2),
                            yOffset + Base.INSTANCE.getFontManager().clickGuiFont.getHeight(), mouseX, mouseY)) {
                        if (!this.previousmouse && Mouse.isButtonDown((int) 0)) {
                            m.toggle();
                            this.previousmouse = true;
                            this.mouse = true;
                        }

                        if (!this.previousmouse && Mouse.isButtonDown((int) 1)) {
                            previousmouse = true;
                        }
                    }

                    /*
                     * if (this.isToggleButtonHovered(155, yOffset + 4, mouseX, mouseY)) { if
                     * (!this.previousmouse && Mouse.isButtonDown((int)0)) { this.previousmouse =
                     * true; this.mouse = true; } if (this.mouse) { m.toggle(); this.mouse = false;
                     * } }
                     */
                    if (!Mouse.isButtonDown((int) 0)) {
                        this.previousmouse = false;
                    }

                    if (this.isStringHovered(xOffset, yOffset,
                            xOffset + (int) Base.INSTANCE.getFontManager().clickGuiFont.getStringWidth(m.getName()), yOffset + 9, mouseX, mouseY)
                            && Mouse.isButtonDown((int) 2)) {
                        Minecraft.getMinecraft().displayGuiScreen(new GuiBinding(m, this));
                        return;
                    }

                    if (this.isStringHovered(xOffset, yOffset,
                            xOffset + (int) Base.INSTANCE.getFontManager().clickGuiFont.getStringWidth(m.getName()), yOffset + 9, mouseX, mouseY)
                            && Mouse.isButtonDown((int) 1)) {
                        // Base.INSTANCE.getFontManager().clickGuiFont.drawString(String.valueOf(m.getName()) + ": " +
                        // m.getDescription(), xOffset, height - this.topheight - 15,
                        // fontMod, -1, -16777216);
                        isModInfoShown = true;
                    } else {
                        isModInfoShown = false;
                    }

                    if (Base.INSTANCE.getSettingManager().getSettingsByMod(m) != null) {
                        if (Base.INSTANCE.getModuleManager().hasBooleanVal(m)) {
                            AddedCheck = true;
                        } else {
                            AddedCheck = false;
                        }

                        if (Base.INSTANCE.getModuleManager().hasDoubleValue(m)) {
                            AddedSlider = true;
                        } else {
                            AddedSlider = false;
                        }

                        if (Base.INSTANCE.getModuleManager().hasStringVal(m)) {
                            AddedMode = true;
                        } else {
                            AddedMode = false;
                        }

                        Gui.drawRect(0, 0, 0, 0, -1);
                        GlStateManager.pushMatrix();
                        GL11.glColor4d((double) 1.0, (double) 1.0, (double) 1.0, (double) 1.0);
                        GL11.glDisable((int) GL11.GL_DEPTH_TEST);
                        Gui.drawImage(new ResourceLocation("remix/settingExpand.png"),width / 2 - ScaleX + 100 - 17, yOffset - 6, 16, 16);
                        GL11.glEnable((int) GL11.GL_DEPTH_TEST);
                        GlStateManager.popMatrix();


                        if (this.isSettingsButtonHovered(width / 2 - ScaleX + 100 - 17, yOffset - 2,
                                width / 2 - ScaleX + 100 - 17 + 13, yOffset + 10, mouseX, mouseY)
                                && Mouse.isButtonDown((int) 0)) {
                            currentOpenedModule = m.getName();
                        }

                        if (!currentCategory.equalsIgnoreCase("CONFIGS") && currentOpenedModule != null) {
                            int CheckBoxSettingsOffset = YHeight + 40;
                            int SliderSettingsOffset = YHeight + 40 - 16;
                            int theStart = width / 2 - ScaleX + 100 + 10;

                            for (Setting s : Base.INSTANCE.getSettingManager().getSettingsByMod(m)) {
                                if (!m.getName().equalsIgnoreCase(currentOpenedModule) || isModInfoShown) {
                                    continue;
                                }

                                if (s.isCombo()) {
                                    int ComboOffsetTitle = YHeight + 40 - 17;
                                    int titlewidth = (int) Base.INSTANCE.getFontManager().clickGuiFont.getStringWidth(s.getName());
                                    int halftitlewidth = (int) Base.INSTANCE.getFontManager().clickGuiFont.getStringWidth(s.getName()) / 2;
                                    Gui.drawRect(theStart, ComboOffsetTitle, theStart + 133, ComboOffsetTitle + 14, new Color(23, 30, 42).getRGB());
                                    drawCenteredString(Base.INSTANCE.getFontManager().clickGuiFont, m.getName() + " Mode", theStart + 67,
                                            ComboOffsetTitle + 4, -1);
                                    ComboOffsetTitle += 18;
                                    Gui.drawRect(theStart, ComboOffsetTitle - 5, theStart + 133, endNumber + 2,
                                            new Color(41, 49, 62).getRGB());

                                    for (String mode : s.getOptions()) {
                                       if (s.getParentMod().getMode() == null)
                                            return;

                                        if (mode.equalsIgnoreCase(s.getParentMod().getMode().getName())) {
                                            drawCenteredString(Base.INSTANCE.getFontManager().clickGuiFont, mode,
                                                    theStart + 85 + Base.INSTANCE.getFontManager().clickGuiFont.getStringWidth(mode) / 18 - 20,
                                                    ComboOffsetTitle, Color.white.getRGB());
                                        } else {
                                            drawCenteredString(Base.INSTANCE.getFontManager().clickGuiFont, mode,
                                                    theStart + 85 + Base.INSTANCE.getFontManager().clickGuiFont.getStringWidth(mode) / 18 - 20,
                                                    ComboOffsetTitle, -8750470);
                                        }


                                        if (this.isStringHovered(
                                                theStart + 85 - Base.INSTANCE.getFontManager().clickGuiFont.getStringWidth(mode) / 2 - 20,
                                                ComboOffsetTitle - Base.INSTANCE.getFontManager().clickGuiFont.getHeight() / 2 + 2, theStart + 85 + Base.INSTANCE.getFontManager().clickGuiFont.getStringWidth(mode) / 2 - 18,
                                                ComboOffsetTitle + Base.INSTANCE.getFontManager().clickGuiFont.getHeight() / 2 + 7, mouseX, mouseY)) {
                                            if (!this.previousmouse && Mouse.isButtonDown((int) 0)) {
                                                this.previousmouse = true;
                                                this.mouse = true;
                                            }

                                            if (this.mouse) {
                                                Mode mode111 = null;

                                                try {
                                                    for (Mode m2 : m.getModes()) {
                                                        if (!m2.getName().equalsIgnoreCase(mode)) {
                                                            continue;
                                                        }

                                                        mode111 = m2;
                                                    }

                                                    if (mode == null) {
                                                        continue;
                                                    }

                                                    m.setMode(mode111);
                                                } catch (Exception e10) {
                                                    e10.printStackTrace();
                                                }

                                                s.setValString(mode);
                                                this.mouse = false;
                                            }
                                        }

                                        if (!Mouse.isButtonDown((int) 0)) {
                                            this.previousmouse = false;
                                        }

                                        ComboOffsetTitle += 15;
                                    }

                                    endNumber = ComboOffsetTitle;
                                    /*  Gui.drawRect(theStart, 98, theStart + 3, ComboOffsetTitle + 5,
                                              new Color(23, 30, 42).getRGB());
                                      Gui.drawRect(theStart + 133, 98 - 16, theStart + 133 + 3, ComboOffsetTitle + 5,
                                              new Color(23, 30, 42).getRGB());
                                      Gui.drawRect(theStart, ComboOffsetTitle + 2, theStart + 133, ComboOffsetTitle + 5,
                                              new Color(23, 30, 42).getRGB());*/

                                    if (AddedMode) {
                                        theStart += 167;
                                    }
                                }

                                if (s.isCheck()) {
                                    /* Gui.drawRect(theStart - 3, OtherEndNumb - 2, theStart + 94, OtherEndNumb + 0,
                                             new Color(23, 30, 42).getRGB());
                                    Gui.drawRect(theStart + 95 - 3, 100 - 15, theStart + 96 - 4 + 2, OtherEndNumb,
                                            new Color(23, 30, 42).getRGB());
                                    Gui.drawRect(theStart - 5, 100 - 15, theStart - 3, OtherEndNumb,
                                            new Color(23, 30, 42).getRGB());*/
                                    Gui.drawRect(theStart + 7 - 10, YHeight + 23, theStart + 96 - 4, YHeight + 36,
                                            new Color(23, 30, 42).getRGB());
                                    drawCenteredString(Base.INSTANCE.getFontManager().clickGuiFont, "Settings", theStart + 5 - 8 + 45, YHeight + 27, -1);
                                    Gui.drawRect(theStart - 3, CheckBoxSettingsOffset - 4,
                                            theStart + 96 + 2 - 6, CheckBoxSettingsOffset + 10 + 3,
                                            new Color(41, 49, 62).getRGB());
                                    Base.INSTANCE.getFontManager().clickGuiFont.drawString(s.getName(), theStart + 5 - 6 + 1,
                                            CheckBoxSettingsOffset + 2, -1);
                                    Gui.drawRect(theStart + 79, CheckBoxSettingsOffset + 1 - 2, theStart + 90,
                                            CheckBoxSettingsOffset + 12 - 2, new Color(23, 30, 42).getRGB());
                                    mc.fontRendererObj.drawString("\u2714", (float) (theStart) + 87.7f - 6,
                                            CheckBoxSettingsOffset + 2 - 2,
                                            s.booleanValue() ? Base.INSTANCE.GetMainColor() : -5789785);

                                    if (this.isCheckBoxHovered(theStart - 3, CheckBoxSettingsOffset - 4,
                                            theStart + 96 + 2 - 6, CheckBoxSettingsOffset + 10 + 3, mouseX, mouseY)) {
                                        if (!this.previousmouse && Mouse.isButtonDown((int) 0)) {
                                            this.previousmouse = true;
                                            this.mouse = true;
                                        }

                                        if (this.mouse) {
                                            s.setValBoolean(!s.booleanValue());
                                            this.mouse = false;
                                        }
                                    }

                                    if (!Mouse.isButtonDown((int) 0)) {
                                        this.previousmouse = false;
                                    }

                                    CheckBoxSettingsOffset += 15;
                                    OtherEndNumb = CheckBoxSettingsOffset;
                                }

                                // Gui.drawRect( width / 2 + 5, 80, width / 2 + 96, CheckBoxSettingsOffset,
                                // Color.red.getRGB());
                                /*
                                 * Gui.drawRect( width / 2, 75, width / 2 + 5 - 7, CheckBoxSettingsOffset - 3,
                                 * new Color(23,30,42).getRGB()); Gui.drawRect( width / 2 + 96 + 5, 75, width /
                                 * 2 + 96 + 7, CheckBoxSettingsOffset - 3, new Color(23,30,42).getRGB());
                                 * Gui.drawRect( width / 2, 75, width / 2 + 96 + 5, 75 + 2, new
                                 * Color(23,30,42).getRGB());
                                 */

                                if (s.isSlider()) {
                                    // MiscellaneousUtil.addChatMessage("AddedMode = " + AddedMode + "\n AddedCheck = "
                                    // +AddedCheck + "\n AddedSlider = "+ AddedSlider);
                                    // MiscellaneousUtil.addChatMessage("" + AddedCheck);
                                    if (AddedCheck) {
                                        theStart += 120;
                                    }

                                    //MiscellaneousUtil.addChatMessage(theStart + "");
                                    Gui.drawRect(theStart, SliderSettingsOffset - 1, theStart + 85,
                                            SliderSettingsOffset + 14, new Color(23, 30, 42).getRGB());
                                    Gui.drawRect(theStart, SliderSettingsOffset + 12, theStart + 40 + 45,
                                            SliderSettingsOffset + 28, new Color(41, 49, 62).getRGB());
                                    /* Gui.drawRect(theStart, SliderSettingsOffset, theStart - 38 + 41,
                                             SliderSettingsOffset + 28, new Color(23, 30, 42).getRGB());
                                     Gui.drawRect(theStart + 35 + 50, SliderSettingsOffset, theStart + 38 + 50,
                                             SliderSettingsOffset + 28, new Color(23, 30, 42).getRGB());*/
                                    /* Gui.drawRect(theStart, SliderSettingsOffset + 26, theStart + 38 + 50,
                                             SliderSettingsOffset + 28, new Color(23, 30, 42).getRGB());*/
                                    Base.INSTANCE.getFontManager().clickGuiFont.drawString(s.getName(),
                                            theStart - 7 - Base.INSTANCE.getFontManager().clickGuiFont.getStringWidth(s.getName()) / 2.0f + 50,
                                            SliderSettingsOffset + 2 + 1, -1);
                                    String displayval = "" + (double) Math.round(s.doubleValue() * 100.0) / 100.0;
                                    Base.INSTANCE.getFontManager().clickGuiFont.drawString(displayval,
                                            theStart - 7 - Base.INSTANCE.getFontManager().clickGuiFont.getStringWidth(displayval) / 2.0f + 50,
                                            SliderSettingsOffset + 17, -1);

                                    if ((double) Math.round(s.doubleValue() * 100.0) / 100.0 < s.getMax()) {
                                        Gui.drawRect(theStart + 38 + 50 - 30 + 10 + 3, SliderSettingsOffset + 15,
                                                theStart + 38 + 50 - 21 + 10 + 3, SliderSettingsOffset + 24,
                                                new Color(23, 30, 42).getRGB());
                                    }

                                    if ((double) Math.round(s.doubleValue() * 100.0) / 100.0 > s.getMin()) {
                                        Gui.drawRect(theStart + 6, SliderSettingsOffset + 15, theStart + 15,
                                                SliderSettingsOffset + 24, new Color(23, 30, 42).getRGB());
                                    }

                                    if ((double) Math.round(s.doubleValue() * 100.0) / 100.0 > s.getMin()) {
                                        Base.INSTANCE.getFontManager().clickGuiFont.drawString("<",
                                                theStart + 6 + Base.INSTANCE.getFontManager().clickGuiFont.getStringWidth("<") - 3,
                                                SliderSettingsOffset + 17, -16777216);
                                    }

                                    if ((double) Math.round(s.doubleValue() * 100.0) / 100.0 < s.getMax()) {
                                        Base.INSTANCE.getFontManager().clickGuiFont.drawString(
                                                ">", theStart + 38 + 50 - 19 + 10
                                                        - Base.INSTANCE.getFontManager().clickGuiFont.getStringWidth(">") - 1,
                                                SliderSettingsOffset + 17, -16777216);
                                    }

                                    if (!Mouse.isButtonDown((int) 0)) {
                                        this.previousmouse = false;
                                    }

                                    if (this.isButtonHovered(theStart + 38 + 50 - 30 + 10 + 3, SliderSettingsOffset + 15,
                                            theStart + 38 + 50 - 21 + 10 + 3, SliderSettingsOffset + 24, mouseX, mouseY)) {
                                        if (!this.previousmouse && Mouse.isButtonDown((int) 0)) {
                                            this.previousmouse = true;
                                            this.mouse = true;
                                        }

                                        if (this.mouse
                                                && (double) Math.round(s.doubleValue() * 100.0) / 100.0 < s.getMax()) {
                                            if (Keyboard.isKeyDown((int) 42)) {
                                                if (s.onlyInt()) {
                                                    if (s.doubleValue() + s.getMax() / 10.0 < s.getMax()) {
                                                        s.setValDouble(s.doubleValue() + s.getMax() / 10.0);
                                                    }
                                                } else if (s.doubleValue() + s.getMax() / 10.0 < s.getMax()) {
                                                    s.setValDouble(s.doubleValue() + s.getMax() / 10.0);
                                                }
                                            } else if (s.onlyInt()) {
                                                s.setValDouble(s.doubleValue() + 1.0);
                                            } else {
                                                s.setValDouble(s.doubleValue() + 0.1);
                                            }

                                            this.mouse = false;
                                        }
                                    }

                                    if (this.isButtonHovered(theStart + 6, SliderSettingsOffset + 15, theStart + 15,
                                            SliderSettingsOffset + 24, mouseX, mouseY)) {
                                        if (!this.previousmouse && Mouse.isButtonDown((int) 0)) {
                                            this.previousmouse = true;
                                            this.mouse = true;
                                        }

                                        if (this.mouse && s.doubleValue() * 100.0 / 100.0 > s.getMin()) {
                                            if (Keyboard.isKeyDown((int) 42)) {
                                                if (s.onlyInt()) {
                                                    if (s.doubleValue() - s.getMax() / 10.0 > s.getMin()) {
                                                        s.setValDouble(s.doubleValue() - s.getMax() / 10.0);
                                                    }
                                                } else if (s.doubleValue() - s.getMax() / 10.0 > s.getMin()) {
                                                    s.setValDouble(s.doubleValue() - s.getMax() / 10.0);
                                                }
                                            } else if (s.onlyInt()) {
                                                s.setValDouble(s.doubleValue() - 1.0);
                                            } else {
                                                s.setValDouble(s.doubleValue() - 0.1);
                                            }

                                            this.mouse = false;
                                        }
                                    }

                                    if (!Mouse.isButtonDown((int) 0)) {
                                        this.previousmouse = false;
                                    }

                                    SliderSettingsOffset += 36;

                                    if (AddedCheck) {
                                        theStart -= 120;
                                    }
                                } else {
                                    AddedSlider = false;
                                }
                            } // AddedCheck = false; //Gui.drawRect( width / 2, CheckBoxSettingsOffset - 3,

                            // width / 2 + 102, CheckBoxSettingsOffset - 5, new Color(23,30,42).getRGB());
                        }
                    }

                    // AddedCheck = false;
                    yOffset += 17;
                }

                break NotSkidded1;
            }
        }
    }


    @Override
    public void initGui() {
        if (OpenGlHelper.shadersSupported && this.mc.getRenderViewEntity() instanceof EntityPlayer) {
            if (this.mc.entityRenderer.theShaderGroup != null) {
                this.mc.entityRenderer.theShaderGroup.deleteShaderGroup();
            }
            this.mc.entityRenderer.func_175069_a(new ResourceLocation("shaders/post/blur.json"));
        }
        }

    public boolean isCategoryHovered(int x, int y, int x2, int y2, int mouseX, int mouseY) {
        if (mouseX >= x && mouseX <= x2 && mouseY >= y && mouseY <= y2) {
            return true;
        }

        return false;
    }

    public boolean isStringHovered(float f, int y, float g, int y2, int mouseX, int mouseY) {
        if (mouseX >= f && mouseX <= g && mouseY >= y && mouseY <= y2) {
            return true;
        }

        return false;
    }

    public boolean isStringKeybinConfigHovered(int x, int y, int x2, int y2, int mouseX, int mouseY) {
        if (mouseX >= x && mouseX <= x2 && mouseY >= y && mouseY <= y2) {
            return true;
        }

        return false;
    }

    public boolean isSaveHovered(int x, int y, int x2, int y2, int mouseX, int mouseY) {
        if (mouseX >= x && mouseX <= x2 && mouseY >= y && mouseY <= y2) {
            return true;
        }

        return false;
    }

    public boolean isLoadHovered(int x, int y, int x2, int y2, int mouseX, int mouseY) {
        if (mouseX >= x && mouseX <= x2 && mouseY >= y && mouseY <= y2) {
            return true;
        }

        return false;
    }

    public boolean isDeleteHovered(int x, int y, int x2, int y2, int mouseX, int mouseY) {
        if (mouseX >= x && mouseX <= x2 && mouseY >= y && mouseY <= y2) {
            return true;
        }

        return false;
    }

    public boolean isButtonHovered(float f, int y, float g, int y2, int mouseX, int mouseY) {
        if (mouseX >= f && mouseX <= g && mouseY >= y && mouseY <= y2) {
            return true;
        }

        return false;
    }

    public boolean isUntouchHovered(int x, int y, int x2, int y2, int mouseX, int mouseY) {
        if (mouseX >= x && mouseX <= x2 && mouseY >= y && mouseY <= y2) {
            return true;
        }

        return false;
    }

    public boolean isHovering(int mouseX, int mouseY, int x, int y) {
        return mouseX >= x && mouseY >= y && mouseX <= x + this.width && mouseY < y + this.height;
    }

    public boolean isKeybindSaveHovered(int x, int y, int x2, int y2, int mouseX, int mouseY) {
        if (mouseX >= x && mouseX <= x2 && mouseY >= y && mouseY <= y2) {
            return true;
        }

        return false;
    }

    public boolean isKeybindLoadHovered(int x, int y, int x2, int y2, int mouseX, int mouseY) {
        if (mouseX >= x && mouseX <= x2 && mouseY >= y && mouseY <= y2) {
            return true;
        }

        return false;
    }

    public boolean isKeybindDeleteHovered(int x, int y, int x2, int y2, int mouseX, int mouseY) {
        if (mouseX >= x && mouseX <= x2 && mouseY >= y && mouseY <= y2) {
            return true;
        }

        return false;
    }

    public boolean isCheckBoxHovered(float f, int y, float g, int y2, int mouseX, int mouseY) {
        if (hasDone) {
            return false;
        }

        if (mouseX >= f && mouseX <= g && mouseY >= y && mouseY <= y2) {
            return true;
        }

        return false;
    }

    public boolean isSliderHovered(int x, int y, int x2, int y2, int mouseX, int mouseY) {
        if (mouseX >= x && mouseX <= x2 && mouseY >= y && mouseY <= y2) {
            return true;
        }

        return false;
    }

    public boolean isSettingsButtonHovered(int x, int y, int x2, int y2, int mouseX, int mouseY) {
        if (mouseX >= x && mouseX <= x2 && mouseY >= y && mouseY <= y2) {
            return true;
        }

        return false;
    }

    public boolean isToggleButtonHovered(int x, int y, int mouseX, int mouseY) {
        if (mouseX >= x && mouseX <= x + 11 && mouseY >= y && mouseY <= y + 11) {
            return true;
        }

        return false;
    }

    public void drawCenteredString(FontRenderer fontRendererIn, String text, float f, float g, int color) {
        fontRendererIn.drawString(text, f - (float) (fontRendererIn.getStringWidth(text) / 2), g, color);
    }

    public void drawCenteredString(MinecraftFontRenderer fontRendererIn, String text, int f, int g, int color) {
        fontRendererIn.drawString(text, f - (float) (fontRendererIn.getStringWidth(text) / 2), g, color);
    }
}
