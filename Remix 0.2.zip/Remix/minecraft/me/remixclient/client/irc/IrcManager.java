package me.remixclient.client.irc;

import me.satisfactory.base.utils.MiscellaneousUtil;
import org.jibble.pircbot.IrcException;
import org.jibble.pircbot.PircBot;

import java.io.IOException;

public class IrcManager extends PircBot {
    private static String username;
    private final String IRC_HostName = "irc.freenode.net";
    private final int IRC_HostPort = 6667;
    private final String IRC_ChannelName = "#RemixClient";

    public IrcManager(String username) {
        this.username = username;
    }

    public void connect() {
        this.setAutoNickChange(true);
        this.setName(username);
        this.changeNick(username);
        MiscellaneousUtil.sendInfo("[IRC] Connecting");

        try {
            this.connect(IRC_HostName, IRC_HostPort);
        } catch (IOException | IrcException e) {
            e.printStackTrace();
        }

        MiscellaneousUtil.sendInfo("Joing Room");
        //Base.INSTANCE.addIRCMessage("Attempting to join.");
        this.joinChannel(IRC_ChannelName);
        MiscellaneousUtil.sendInfo("Logged In");
        //Base.INSTANCE.addIRCMessage("Connected.");
    }
}
