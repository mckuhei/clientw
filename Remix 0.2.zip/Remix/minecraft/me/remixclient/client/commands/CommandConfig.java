package me.remixclient.client.commands;

import me.satisfactory.base.Base;
import me.satisfactory.base.command.Command;
import me.satisfactory.base.utils.MiscellaneousUtil;
import me.satisfactory.base.utils.file.FileUtils;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class CommandConfig extends Command {
    public CommandConfig() {
        super("Config", "config");
    }

    public void execute(String[] args) {
        if (args.length != 1) {
            MiscellaneousUtil.sendInfo("An error has occured! Please try .Config <Config>");
        } else {

            if (FileUtils.getConfigFile(args[0]).exists()) {
               /* Base.INSTANCE.getBypassManager().load(args[0]);*/
                MiscellaneousUtil.sendInfo(FileUtils.getConfigFileConf(args[0]).getAbsolutePath());
                MiscellaneousUtil.sendInfo("Successfully loaded the config '" + args[0] + "'");
            } else {

            }
            MiscellaneousUtil.sendInfo("The config '" + args[0] + "' does not exist!");
        }

    }
}