package me.remixclient.client.commands;

import me.satisfactory.base.Base;
import me.satisfactory.base.command.Command;
import me.satisfactory.base.utils.MiscellaneousUtil;

import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class CommandHelp extends Command {
    public CommandHelp() {
        super("Help", "help");
    }

    public void execute(String[] args) {
        Set<String> commandNames = Base.INSTANCE.getCommandManager().commands.values().stream().map(Command::getName).collect(Collectors.toSet());
        String joinedCommands = String.join(", ", commandNames);
        MiscellaneousUtil.sendInfo(joinedCommands);
    }
}