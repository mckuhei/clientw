package me.remixclient.client.commands;

import me.satisfactory.base.Base;
import me.satisfactory.base.command.Command;
import me.satisfactory.base.module.Module;
import me.satisfactory.base.utils.MiscellaneousUtil;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class CommandToggle extends Command {
    public CommandToggle() {
        super("Toggle", "toggle");
    }

    public void execute(String[] args) {
        if (args.length != 1) {
            MiscellaneousUtil.sendInfo("An error has occured! Please try .Toggle <Module>");
        } else {
            Module module = Base.INSTANCE.getModuleManager().getModByName(args[0]);

            if (module != null) {
                module.toggle();
            } else {
                MiscellaneousUtil.sendInfo("Could not find the module " + args[0] + "!");
            }
        }
    }
}