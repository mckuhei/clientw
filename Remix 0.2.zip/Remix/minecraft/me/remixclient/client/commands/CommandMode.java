package me.remixclient.client.commands;

import me.satisfactory.base.Base;
import me.satisfactory.base.command.Command;
import me.satisfactory.base.module.Module;
import me.satisfactory.base.utils.MiscellaneousUtil;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class CommandMode extends Command {
    public CommandMode() {
        super("Mode", "mode");
    }

    public static String replaceLast(String string, String toReplace, String replacement) {
        int pos = string.lastIndexOf(toReplace);

        if (pos > -1) {
            return string.substring(0, pos)
                    + replacement
                    + string.substring(pos + toReplace.length(), string.length());
        } else {
            return string;
        }
    }

    public void execute(String[] args) {
        if (args.length == 1) {
            try {
                Module TheMod = Base.INSTANCE.getModuleManager().getModByName(args[0]);

                if (!TheMod.getModes().isEmpty()) {
                    String Modes = "";

                    for (int i = 0; i < TheMod.getModes().size(); i++) {
                        Modes = Modes + "\"" + TheMod.getModes().get(i).getName() + ", ";
                    }

                    Modes = Modes.replace(" ", "\" ");
                    Modes = replaceLast(Modes, ",", "");
                    Modes = replaceLast(Modes, " ", "");
                    Modes = Modes + ".";
                    MiscellaneousUtil.sendInfo("The " + TheMod.getName() + " has the modes: " + Modes);
                } else {
                    MiscellaneousUtil.sendInfo("The module " + args[0] + " doesn't have any modes!");
                }
            } catch (Exception e) {
                MiscellaneousUtil.sendInfo("Could not the module " + args[0]);
            }
        } else if (args.length != 2) {
            MiscellaneousUtil.sendInfo("An error has occured! Please try .Mode <Module> <Mode>");
        } else {
            try {
                Module TheMod = Base.INSTANCE.getModuleManager().getModByName(args[0]);

                if (!TheMod.getModes().isEmpty()) {
                    String Mode = args[1];

                    for (int i = 0; i < TheMod.getModes().size(); i++) {
                        if (TheMod.getModes().get(i).getName().equalsIgnoreCase(Mode)) {
                            TheMod.setMode(TheMod.getModes().get(i));
                            MiscellaneousUtil.sendInfo("The " + TheMod.getName() + " mode has been set to " + Mode);
                        } else {
                            if (i + 1 == TheMod.getModes().size()) {
                                MiscellaneousUtil.sendInfo("Could not find the mode " + Mode);
                            }
                        }
                    }
                } else {
                    MiscellaneousUtil.sendInfo("The module " + args[0] + " doesn't have any modes!");
                }
            } catch (Exception e) {
                MiscellaneousUtil.sendInfo("Could not the module " + args[0]);
            }
        }
    }
}