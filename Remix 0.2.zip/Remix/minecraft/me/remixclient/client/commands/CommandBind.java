package me.remixclient.client.commands;

import me.satisfactory.base.Base;
import me.satisfactory.base.command.Command;
import me.satisfactory.base.module.Module;
import me.satisfactory.base.utils.MiscellaneousUtil;
import org.lwjgl.input.Keyboard;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class CommandBind extends Command {
    public CommandBind() {
        super("Bind", "bind");
    }

    public void execute(String[] args) {
        if (args.length != 2) {
            MiscellaneousUtil.sendInfo("An error has occured! Please try .Bind <Module> <Key>");
        } else {
            try {
                Module module = Base.INSTANCE.getModuleManager().getModByName(args[0]);
                String keyId = args[1];
                int key = Keyboard.getKeyIndex(keyId.toUpperCase());

                if (module != null) {
                    if (keyId.toUpperCase().equals("NONE")) {
                        MiscellaneousUtil.sendInfo("Cleared the keybind of the module " + module.getName());
                        module.setKeybind(0);
                    } else {
                        if (Keyboard.getKeyIndex(keyId.toUpperCase()) == 0) {
                            MiscellaneousUtil.sendInfo("Could not find the key " + keyId + ".§f Please try .bind <module> <key>");
                        } else {
                            module.setKeybind(key);
                            MiscellaneousUtil.sendInfo(String.format("" + module.getName() + "'s§f keybind as successfully been bound to " + keyId.toString().toUpperCase() + "§f."));
                        }
                    }
                } else {
                    MiscellaneousUtil.sendInfo("Could not find the module " + args[0] + "!");
                }
            } catch (Exception e) {
                System.out.println(e);
                MiscellaneousUtil.sendInfo("Could not find the module " + args[0] + "!");
            }
        }
    }
}