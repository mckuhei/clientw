package me.remixclient.client.modules.combat.killaura;

import me.satisfactory.base.utils.MiscellaneousUtil;
import pw.stamina.causam.scan.method.model.Subscriber;
import me.remixclient.client.modules.combat.Killaura;
import me.satisfactory.base.Base;
import me.satisfactory.base.events.EventMotion;
import me.satisfactory.base.module.Mode;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.item.ItemSword;
import optifine.MathUtils;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class Single extends Mode<Killaura> {
    public Single(Killaura parent) {
        super(parent, "Single");
    }

    @Override
    public void onEnable() {
        this.parent.target = null;
        this.parent.swapping = false;
        this.parent.index = 0;
        this.parent.toAttack.clear();
        super.onEnable();
    }

    @Subscriber
    public void eventMotion(EventMotion event) {
        if (!(mc.currentScreen instanceof GuiChest)) {
            this.parent.toAttack = this.parent.getNear(this.parent.findSettingByName("Range").doubleValue());
            this.parent.toAttack.sort(this.parent.angleComparator);

            if (this.parent.target != null &this.parent.findSettingByName("AutoBlock").booleanValue() && mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof ItemSword && !mc.thePlayer.isBlocking()) {
            }

            if (!this.parent.toAttack.isEmpty() && this.parent.findSettingByName("AutoBlock").booleanValue() && mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof ItemSword && !mc.thePlayer.isBlocking()) {
                mc.playerController.sendUseItem(mc.thePlayer, mc.theWorld, mc.thePlayer.getCurrentEquippedItem());
            }
        }

        boolean crits = Base.INSTANCE.getModuleManager().getModByName("Criticals").isEnabled();
        boolean blocking = mc.thePlayer.isBlocking();

        if (this.parent.target != null && (this.parent.target == null || this.parent.getDistanceSq(this.parent.target) <= MathUtils.square(this.parent.findSettingByName("Range").doubleValue()) && this.parent.qualifies(this.parent.target))) {
            if (this.parent.timer.hasTimeElapsed(1000.0 / (this.parent.findSettingByName("APS").doubleValue() +  MiscellaneousUtil.random(-this.parent.findSettingByName("Random").doubleValue(), this.parent.findSettingByName("Random").doubleValue())), false)) {
                if (this.parent.target != null & this.parent.findSettingByName("AutoBlock").booleanValue() && mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof ItemSword && !mc.thePlayer.isBlocking()) {
                    mc.playerController.onStoppedUsingItem(mc.thePlayer);
                }

                this.parent.attack(crits);

                if (this.parent.target != null & this.parent.findSettingByName("AutoBlock").booleanValue() && mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof ItemSword && !mc.thePlayer.isBlocking()) {
                    mc.thePlayer.setItemInUse(mc.thePlayer.getHeldItem(), mc.thePlayer.getCurrentEquippedItem().getMaxItemUseDuration());
                }

                if (this.parent.target.isDead) {
                    this.parent.target = null;
                }

                this.parent.timer.reset();
            }

            this.parent.swapping = false;
        } else {
            this.parent.target = this.parent.toAttack.isEmpty() ? null : this.parent.toAttack.get(0);
        }
    }
}
