package me.remixclient.client.modules.combat;

import me.satisfactory.base.Base;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.events.EventSendPacket;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import me.satisfactory.base.setting.Setting;
import me.satisfactory.base.utils.MiscellaneousUtil;
import me.satisfactory.base.utils.timer.TimerUtil;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.util.BlockPos;
import org.lwjgl.input.Keyboard;
import pw.stamina.causam.scan.method.model.Subscriber;

import java.util.Arrays;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class Criticals extends Module {
    public Criticals() {
        super("Criticals", Keyboard.KEY_NONE, Category.COMBAT);

    }



    private boolean canCrit() {

        if(!mc.thePlayer.onGround) return false;
        if (Base.INSTANCE.getModuleManager().getModByName("Flight").isEnabled())return false;



        return true;
    }


    @Subscriber
    public void onPacket(EventSendPacket event) {


        if(event.getPacket() instanceof C02PacketUseEntity) {
            C02PacketUseEntity packet = (C02PacketUseEntity) event.getPacket();
            if (packet.getAction() == C02PacketUseEntity.Action.ATTACK) {

                    EntityLivingBase ent = (EntityLivingBase)packet.getEntityFromWorld(this.mc.theWorld);
                    if (packet.getAction() == C02PacketUseEntity.Action.ATTACK) {
                        if (canCrit() && packet.getEntity().hurtResistantTime < 15)
                        {
                            MiscellaneousUtil.sendInfo("crit");
                            mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, false));
                            mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + MiscellaneousUtil.random( 0.03 - 0.003, 0.03 + 0.003), mc.thePlayer.posZ, false));
                            mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + MiscellaneousUtil.random(0.05 - 0.005, 0.05 + 0.005), mc.thePlayer.posZ, false));
                            mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, false));


                        }
                }
            }
        }
    }
}
