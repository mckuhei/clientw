package me.remixclient.client.modules.combat.fastbow;

import pw.stamina.causam.scan.method.model.Subscriber;
import me.remixclient.client.modules.combat.Fastbow;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Mode;
import net.minecraft.item.ItemBow;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class Guardian extends Mode<Fastbow> {
    int counter = 0;

    public Guardian(Fastbow parent) {
        super(parent, "Guardian");
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate eventt) {
        if (mc.thePlayer.onGround && mc.thePlayer.getCurrentEquippedItem() != null
                && mc.thePlayer.getCurrentEquippedItem().getItem() instanceof ItemBow
                && mc.gameSettings.keyBindUseItem.pressed) {
            mc.thePlayer.sendQueue.addToSendQueue(new C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getCurrentItem()));
            int index;
            index = 0;

            while (index < 16) {
                if (!mc.thePlayer.isDead) {
                    mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C06PacketPlayerPosLook(mc.thePlayer.posX, mc.thePlayer.posY + 1.0E-9, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, true));
                }

                ++index;
            }

            mc.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
        }

        if (mc.thePlayer.onGround && mc.thePlayer.getCurrentEquippedItem() != null
                && mc.thePlayer.getCurrentEquippedItem().getItem() instanceof ItemBow
                && mc.gameSettings.keyBindUseItem.pressed) {
            mc.thePlayer.sendQueue.addToSendQueue(new C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getCurrentItem()));

            if (mc.thePlayer.ticksExisted % 2 == 0) {
                mc.thePlayer.setItemInUseCount(12);
                this.counter += 1;

                if (this.counter > 0) {
                    mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY - 0.0D, mc.thePlayer.posZ, mc.thePlayer.onGround));
                    //mc.thePlayer.swingItem();
                    this.counter = 0;
                }

                int index;
                int dist = 20;

                for (index = 0; index < dist; ++index) {
                    mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(
                            mc.thePlayer.posX, mc.thePlayer.posY + 1.0E-12D, mc.thePlayer.posZ,
                            mc.thePlayer.onGround));
                }

                mc.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
            }
        }
    }
}
