package me.remixclient.client.modules.combat;

import pw.stamina.causam.scan.method.model.Subscriber;
import me.satisfactory.base.events.EventMotion;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import org.lwjgl.input.Keyboard;

import java.util.Collection;

/**
 * @author Vladymyr96
 * @since 18/06/2017
 */
public class PotionSaver extends Module {
    private boolean canStop;
    private int goodPotions;
    private int badPotions;

    public PotionSaver() {
        super("PotionSaver", Keyboard.KEY_NONE, Category.COMBAT);
    }

    @Subscriber
    public void EventMotion(EventMotion event) {
        if (event.getType() == 0) {
            Collection<PotionEffect> collection = mc.thePlayer.getActivePotionEffects();
            canStop = !mc.thePlayer.isMoving() && collection.size() > 0 && !mc.thePlayer.isUsingItem() && !mc.thePlayer.isSwingInProgress && !event.isRotating();

            for (PotionEffect potioneffect : collection) {
                Potion potion = Potion.potionTypes[potioneffect.getPotionID()];

                if (potion.isUsable()) {
                    goodPotions++;
                } else if (potion.isBadEffect()) {
                    badPotions++;
                }
            }

            event.setCancelled(shouldStopPotion());

            if (!canStop) {
                goodPotions = 0;
                badPotions = 0;
            }
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        this.canStop = false;
        this.goodPotions = 0;
        this.badPotions = 0;
    }

    public boolean shouldStopPotion() {
        return this.goodPotions >= this.badPotions && this.canStop;
    }
}
