package me.remixclient.client.modules.combat;


import me.remixclient.client.modules.combat.killaura.Single;
import me.remixclient.client.modules.combat.killaura.Switch;
import me.remixclient.client.modules.combat.killaura.Tick;
import me.satisfactory.base.Base;
import me.satisfactory.base.events.EventMotion;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import me.satisfactory.base.setting.Setting;
import me.satisfactory.base.utils.MiscellaneousUtil;
import me.satisfactory.base.utils.aura.AuraUtils;
import me.tojatta.api.utilities.utilities.angle.Angle;
import me.tojatta.api.utilities.utilities.angle.AngleUtility;
import me.tojatta.api.utilities.utilities.vector.impl.Vector3;
import me.satisfactory.base.utils.timer.TimerUtil;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.EntitySlime;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityBat;
import net.minecraft.entity.passive.EntitySquid;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.potion.Potion;
import optifine.MathUtils;
import org.lwjgl.input.Keyboard;
import pw.stamina.causam.scan.method.model.Subscriber;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class Killaura extends Module {
    private final static Random random = new Random();
    public boolean HasRotated, swapping, isAttacking;
    public static Entity target;
    public List<Entity> toAttack = new ArrayList<>(0);
    public int index;
    public Entity en22222 = null;
    public TimerUtil timer = new TimerUtil();

    public Comparator<Entity> angleComparator = Comparator.comparingDouble(e2 -> getClosestEntityTo(e2));

    public Killaura() {
        super("Killaura", Keyboard.KEY_NONE, Category.COMBAT);
        /*CheckBtnSetting players = new CheckBtnSetting("Players", "players");
        CheckBtnSetting animals = new CheckBtnSetting("Animals", "animals");
        CheckBtnSetting AAC = new CheckBtnSetting("AAC", "AACBETA");
        CheckBtnSetting mobs = new CheckBtnSetting("Mobs", "mobs");
        CheckBtnSetting invisibles = new CheckBtnSetting("Invisibles", "invisibles");
         CheckBtnSetting block = new CheckBtnSetting("AutoBlock", "block");
         CheckBtnSetting dura = new CheckBtnSetting("Dura", "dura");
         CheckBtnSetting teams = new CheckBtnSetting("Teams", "teams");
         CheckBtnSetting autoDisable = new CheckBtnSetting("Auto Disable", "autoDisable");

         SliderSetting<Number> aps = new SliderSetting<Number>("APS", ClientSettings.apsBeta, 1.0, 20.0, 0.1, ValueFormat.DECIMAL);
         SliderSetting<Number> range = new SliderSetting<Number>("Range", ClientSettings.rangeBeta, 2, 6.0, 0.25, ValueFormat.DECIMAL);
         SliderSetting<Number> sps = new SliderSetting<Number>("Swap Interval", ClientSettings.sps, 0.1, 20.0, 0.1, ValueFormat.DECIMAL);
         SliderSetting<Number> random = new SliderSetting<Number>("Random", ClientSettings.rnd, 0.1, 3.0, 1, ValueFormat.DECIMAL);

        */
        ArrayList<String> options = new ArrayList<>();
        options.add("Single");
        options.add("Switch");
        options.add("Hypixel");
        options.add("Tick");
        this.addSetting(new Setting("KillauraMode", this, "Single", options));
        this.addSetting(new Setting("APS", this, 13, 1, 20, false));
        this.addSetting(new Setting("Range", this, 4.3, 1, 6, false));
        this.addSetting(new Setting("Swap", this, 80, 1, 500, false));
        this.addSetting(new Setting("Random", this, 1, 0, 3, false));
        this.addSetting(new Setting("rayTrace", this, true));
        this.addSetting(new Setting("Players", this, true));
        this.addSetting(new Setting("Animals", this, false));
        this.addSetting(new Setting("AutoBlock", this, false));
        this.addSetting(new Setting("Mobs", this, false));
        this.addSetting(new Setting("AAC", this, false));
        this.addSetting(new Setting("Invisibles", this, false));
        this.addSetting(new Setting("Dura", this, false));
        this.addSetting(new Setting("Teams", this, false));
        this.addSetting(new Setting("CanBeSeen", this, false));
        this.addSetting(new Setting("Disable", this, false));
        this.addMode(new Single(this));
        this.addMode(new Switch(this));
        this.addMode(new Tick(this));

    }






    public static boolean qualifies(Entity e2) {
        if (e2 instanceof EntityPlayerSP) {
            return false;
        }
        if (Base.INSTANCE.getSettingManager().getSettingByName("CanBeSeen").booleanValue() && !Minecraft.getMinecraft().thePlayer.canEntityBeSeen(e2)) {
            return false;
        }

        if (Base.INSTANCE.getSettingManager().getSettingByName("rayTrace").booleanValue() && target != null && e2 == target) {
            return true;
        }

        if (!(e2 instanceof EntityLivingBase)  || e2.isInvisible() && !Base.INSTANCE.getSettingManager().getSettingByName("Invisibles").booleanValue() || e2.isDead || e2 == Minecraft.getMinecraft().thePlayer  || (e2 instanceof EntityPlayer && Base.INSTANCE.getFriendManager().isFriend((e2.getName()))  || (e2 instanceof EntityPlayer && Base.INSTANCE.getFriendManager().isFriend(e2.getName()) || (Base.INSTANCE.getSettingManager().getSettingByName("Teams").booleanValue() && AuraUtils.isOnTeam((EntityLivingBase)e2))))) {
            return false;
        }
        if (e2 instanceof EntityPlayer && Base.INSTANCE.getSettingManager().getSettingByName("Players").booleanValue()) {
            return true;
        }
        return ((e2 instanceof EntityMob || e2 instanceof EntitySlime || e2 instanceof EntityGhast) && Base.INSTANCE.getSettingManager().getSettingByName("Mobs").booleanValue()) || ((e2 instanceof EntityAnimal || e2 instanceof EntitySquid  || e2 instanceof EntityVillager|| e2 instanceof EntityBat) && Base.INSTANCE.getSettingManager().getSettingByName("Animals").booleanValue() != false);
    }

    public static List<Entity> getNear(double range) {
        List<Entity> list = new ArrayList<>();
        for (Entity e2 : Minecraft.getMinecraft().theWorld.loadedEntityList) {
            if (getDistanceSq(e2) <= MathUtils.square(range) && qualifies(e2)) {
                list.add(e2);
            }
        }
        return list;
    }

    public void attack(boolean crit) {

        if (HasRotated = true) {

            // Timer.timerSpeed = 14f;
            isAttacking = true;

            if (Base.INSTANCE.getModuleManager().getModByName("BloodGFX").isEnabled()) {
                for (double i22 = 0; i22 < target.height; i22 = i22 + 0.2) {
                    mc.effectRenderer.spawnEffectParticle(37, target.posX, target.posY + i22, target.posZ, (random.nextInt(6) - 3) / 5, 0.1, (random.nextInt(6) - 3) / 5, new int[]{Block.getIdFromBlock(Blocks.redstone_block)});
                    mc.effectRenderer.spawnEffectParticle(37, target.posX, target.posY + i22, target.posZ, (random.nextInt(6) - 3) / 5, 0.1, (random.nextInt(6) - 3) / 5, new int[]{Block.getIdFromBlock(Blocks.redstone_block)});
                    mc.effectRenderer.spawnEffectParticle(37, target.posX, target.posY + i22, target.posZ, (random.nextInt(6) - 3) / 5, 0.1, (random.nextInt(6) - 3) / 5, new int[]{Block.getIdFromBlock(Blocks.redstone_block)});
                    mc.effectRenderer.spawnEffectParticle(37, target.posX, target.posY + i22, target.posZ, (random.nextInt(6) - 3) / 5, 0.1, (random.nextInt(6) - 3) / 5, new int[]{Block.getIdFromBlock(Blocks.redstone_block)});
                    mc.effectRenderer.spawnEffectParticle(37, target.posX, target.posY + i22, target.posZ, (random.nextInt(6) - 3) / 5, 0.1, (random.nextInt(6) - 3) / 5, new int[]{Block.getIdFromBlock(Blocks.redstone_block)});
                    mc.effectRenderer.spawnEffectParticle(37, target.posX, target.posY + i22, target.posZ, (random.nextInt(6) - 3) / 5, 0.1, (random.nextInt(6) - 3) / 5, new int[]{Block.getIdFromBlock(Blocks.redstone_block)});
                    mc.effectRenderer.spawnEffectParticle(37, target.posX, target.posY + i22, target.posZ, (random.nextInt(6) - 3) / 5, 0.1, (random.nextInt(6) - 3) / 5, new int[]{Block.getIdFromBlock(Blocks.redstone_block)});
                    mc.effectRenderer.spawnEffectParticle(37, target.posX, target.posY + i22, target.posZ, (random.nextInt(6) - 3) / 5, 0.1, (random.nextInt(6) - 3) / 5, new int[]{Block.getIdFromBlock(Blocks.redstone_block)});
                    mc.effectRenderer.spawnEffectParticle(37, target.posX, target.posY + i22, target.posZ, (random.nextInt(6) - 3) / 5, 0.1, (random.nextInt(6) - 3) / 5, new int[]{Block.getIdFromBlock(Blocks.redstone_block)});
                }
            }

            float sharpLevel = EnchantmentHelper.func_152377_a(mc.thePlayer.getHeldItem(), EnumCreatureAttribute.UNDEFINED);
            boolean vanillaCrit = (mc.thePlayer.fallDistance > 0.0F) && (!mc.thePlayer.onGround)
                    && (!mc.thePlayer.isOnLadder()) && (!mc.thePlayer.isInWater())
                    && (!mc.thePlayer.isPotionActive(Potion.blindness)) && (mc.thePlayer.ridingEntity == null);
            Entity beforeTarget = target;
            Entity toAttack1 = target;

            if (en22222 != null) {
                toAttack1 = en22222;
            }

            if ((Base.INSTANCE.getModuleManager().getModByName("Criticals").isEnabled()) || (vanillaCrit)) {
                mc.thePlayer.onCriticalHit(toAttack1);
            }

            if (sharpLevel > 0.0F) {
                mc.thePlayer.onEnchantmentCritical(toAttack1);
            }

            mc.thePlayer.swingItem();

            if (mc.thePlayer.onGround) {
                if (crit && !vanillaCrit) {
                    // crit();
                }
            }

            if (this.findSettingByName("AutoBlock").booleanValue() && mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof ItemSword && !mc.thePlayer.isBlocking()) {
                mc.thePlayer.stopUsingItem();
                mc.playerController.onStoppedUsingItem(mc.thePlayer);
                mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange());
            }

            // Timer.timerSpeed = 1f;


            mc.getNetHandler().addToSendQueue(new C02PacketUseEntity(toAttack1, C02PacketUseEntity.Action.ATTACK));
            if (this.findSettingByName("AAC").booleanValue()){
                mc.thePlayer.setSprinting(false);

            }
            en22222 = null;
            isAttacking = false;
            target = beforeTarget;
            HasRotated = false;

        }
    }

    public double getClosestEntityTo(Entity target) {


        return mc.thePlayer.getDistanceSqToEntity(target);
    }

    public static double getDistanceSq(Entity target) {
        double xDiff = target.posX - Minecraft.getMinecraft().thePlayer.posX;
        double yDiff = target.posY - Minecraft.getMinecraft().thePlayer.posY;
        double zDiff = target.posZ - Minecraft.getMinecraft().thePlayer.posZ;

        if (yDiff > -0.2) {
            yDiff = target.posY - (Minecraft.getMinecraft().thePlayer.posY + 1.0);
        } else if (yDiff < 0.3) {
            yDiff = target.posY + 1.0 - Minecraft.getMinecraft().thePlayer.posY;
        }

        return xDiff * xDiff + yDiff * yDiff + zDiff * zDiff;
    }



    /*public  void crit() {
    	if (!Base.INSTANCE.getModuleManager().getModByName("Flight").isEnabled()) {
    		if (!mc.thePlayer.onGround) {
    			mc.thePlayer.moveEntity(0.0D, 0.009999999776482582D, 0.0D);
    	        } else {
    	        	mc.thePlayer.motionY = 0.009999999776482582D;
    	        }
    	}
    	else {
    		mc.thePlayer.fallDistance = 0;
    		mc.thePlayer.onGround = true;
    	}
    }*/

    @Subscriber
    public void eventMotion(EventMotion event) {
        if (this.target != null) {
            AngleUtility angleUtility = new AngleUtility(1, 20, 2, 30);
            double AAC1 = this.findSettingByName("AAC").booleanValue() ? MiscellaneousUtil.random(-0.3,0.3) : 0;
            double AAC2 = this.findSettingByName("AAC").booleanValue() ? MiscellaneousUtil.random(-5, 22) : 0;
            Vector3<Double> enemyCoords = new Vector3<>(target.posX + AAC1, target.posY - (target.getEyeHeight() / 3), target.posZ+AAC2);
            Vector3<Double> myCoords = new Vector3<>(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ);
            Angle dstAngle = angleUtility.calculateAngle(enemyCoords, myCoords);
            Angle srcAngle = new Angle(mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch);
            Angle smoothedAngle = angleUtility.smoothAngle(dstAngle, srcAngle);


            if (this.findSettingByName("rayTrace").booleanValue()) {
                en22222 = AuraUtils.getMouseOver( dstAngle.getYaw(), dstAngle.getPitch(),target);

                if (en22222 != null && en22222 != this.target) {
                    MiscellaneousUtil.sendInfo("RayCasted a hit on '" + en22222.getName() + "'");
                    //en22222 = null;
                }
            }

           event.yaw = dstAngle.getYaw();
            event.pitch = dstAngle.getPitch();
            HasRotated = true;

        }
    }

    private enum HitLocation {
        AUTO(0.0),
        HEAD(1.0),
        CHEST(1.5),
        FEET(3.5);

        private double offset;

        HitLocation(double offset) {
            this.offset = offset;
        }

        public double getOffset() {
            return this.offset;
        }
    }
    @Override
    public void onEnable() {
        isAttacking = false;
        HasRotated = false;
        this.target = null;
        this.swapping = false;
        this.index = 0;
        this.toAttack.clear();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        isAttacking = false; //no shitxdddd
        super.onDisable();
    }
}
