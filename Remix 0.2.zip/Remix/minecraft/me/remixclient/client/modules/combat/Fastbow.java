package me.remixclient.client.modules.combat;

import me.remixclient.client.modules.combat.fastbow.Fast;
import me.remixclient.client.modules.combat.fastbow.Guardian;
import me.satisfactory.base.Base;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import me.satisfactory.base.setting.Setting;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class Fastbow extends Module {
    public Fastbow() {
        super("Fastbow", Keyboard.KEY_NONE, Category.COMBAT);
        ArrayList<String> options = new ArrayList<>();
        options.add("Guardian");
        options.add("Fast");
        this.addSetting(new Setting("FastbowMode", this, "Guardian", options));
        this.addMode(new Guardian(this));
        this.addMode(new Fast(this));
    }
}
