package me.remixclient.client.modules.combat;

import me.satisfactory.base.utils.other.InventoryUtils;
import pw.stamina.causam.scan.method.model.Subscriber;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import me.satisfactory.base.setting.Setting;
import me.satisfactory.base.utils.timer.TimerUtil;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import org.lwjgl.input.Keyboard;

/**
 * @author Mees
 * @since 18/06/2017
 */
public final class AutoPotion extends Module {
    public static boolean isPotting;


    private TimerUtil timer = new TimerUtil();
    private int lockedTicks;

    public AutoPotion() {
        super("AutoPotion", Keyboard.KEY_NONE, Category.COMBAT);
        this.addSetting(new Setting("AutopotHealth", this, 6, 1, 10, false));
        this.addSetting(new Setting("AutopotDelay", this, 50, 50, 2000, false));
        this.addSetting(new Setting("HeadPot", this, false));
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate event) {
        if (this.lockedTicks >= 0) {
            --this.lockedTicks;
            int potSlot = InventoryUtils.getPotionFromInventory();

            if (potSlot != -1) {
                if (mc.thePlayer.getHealth() <= this.findSettingByName("AutopotHealth").doubleValue() * 2.0
                        && timer.hasTimeElapsed((long) this.findSettingByName("AutopotDelay").doubleValue(), true)) {
                    mc.thePlayer.motionX = 0;
                    mc.thePlayer.motionZ = 0;
                }
            }
        } else {
            if (lockedTicks < 0) {
                int potSlot2 = InventoryUtils.getPotionFromInventory();

                if (potSlot2 != -1) {
                    if (mc.thePlayer.getHealth() < ((float) this.findSettingByName("AutopotHealth").doubleValue() * 2.0)
                            && timer.hasTimeElapsed((long) this.findSettingByName("AutopotDelay").doubleValue(), true)) {
                        if (InventoryUtils.hotBarHasPots()) {
                            for (int i = 36; i < 45; ++i) {
                                ItemStack stack = mc.thePlayer.inventoryContainer.getSlot(i).getStack();

                                if (stack != null && InventoryUtils.isSplashPot(stack)) {
                                    isPotting = true;

                                    if (this.findSettingByName("HeadPot").booleanValue() && mc.thePlayer.onGround) {
                                        mc.thePlayer.motionY = 0.424f;
                                    }

                                    int oldSlot = mc.thePlayer.inventory.currentItem;
                                    mc.thePlayer.motionX = 0;
                                    mc.thePlayer.motionZ = 0;

                                    if (!this.findSettingByName("HeadPot").booleanValue()) {
                                        mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C06PacketPlayerPosLook(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, 85f, mc.thePlayer.onGround));
                                    } else {
                                        mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C06PacketPlayerPosLook(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, -85f, mc.thePlayer.onGround));
                                    }


                                    mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(i - 36));
                                    mc.thePlayer.motionX = 0;
                                    mc.thePlayer.motionZ = 0;
                                    mc.thePlayer.sendQueue.addToSendQueue(new C08PacketPlayerBlockPlacement(stack));
                                    mc.thePlayer.motionX = 0;
                                    mc.thePlayer.motionZ = 0;
                                    mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(oldSlot));
                                    break;
                                }
                            }

                            isPotting = false;
                        } else {
                            isPotting = true;
                            InventoryUtils.grabPot();
                            isPotting = false;
                        }
                    }
                }
            }
        }
    }


}
