package me.remixclient.client.modules.combat;

import pw.stamina.causam.scan.method.model.Subscriber;
import me.satisfactory.base.events.EventPacketReceive;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import org.lwjgl.input.Keyboard;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class WTap extends Module {
    public WTap() {
        super("WTap", Keyboard.KEY_NONE, Category.COMBAT);
    }

    @Subscriber
    public void readPacket(EventPacketReceive eventPacketReceive) {
        if (mc.theWorld != null && mc.thePlayer != null) {
            if (eventPacketReceive.packet instanceof C02PacketUseEntity) {
                C02PacketUseEntity packet = (C02PacketUseEntity) eventPacketReceive.packet;

                if (packet.getAction() == C02PacketUseEntity.Action.ATTACK && packet.getEntityFromWorld(mc.theWorld) != mc.thePlayer) {
                    if (mc.thePlayer.getFoodStats().getFoodLevel() > 6) {
                        boolean sprint = mc.thePlayer.isSprinting();

                        if (sprint) {
                            mc.thePlayer.setSprinting(false);
                            mc.thePlayer.setSprinting(true);
                        }

                        mc.thePlayer.sendQueue.addToSendQueue(new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.START_SPRINTING));
                        mc.thePlayer.sendQueue.addToSendQueue(new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.STOP_SPRINTING));
                        mc.thePlayer.sendQueue.addToSendQueue(new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.START_SPRINTING));
                    }
                }
            }
        }
    }
}
