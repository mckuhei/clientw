package me.remixclient.client.modules.combat;

import pw.stamina.causam.scan.method.model.Subscriber;
import me.satisfactory.base.Base;
import me.satisfactory.base.events.Event2DRender;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.relations.FriendManager;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import me.satisfactory.base.pathfinder.Node;
import me.satisfactory.base.pathfinder.NodeProcessor;
import me.satisfactory.base.utils.aura.AuraUtils;
import me.satisfactory.base.utils.timer.TimerUtil;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.EntitySlime;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityBat;
import net.minecraft.entity.passive.EntitySquid;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C02PacketUseEntity.Action;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.pathfinding.PathFinder;
import net.minecraft.potion.Potion;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Vec3;
import net.minecraft.world.pathfinder.WalkNodeProcessor;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class TPAura extends Module {
    private final static Random rand = new Random();
    TimerUtil timerInf = new TimerUtil();
    private List<Vec3> positions = new ArrayList<>();
    private List<Vec3> positionsBack = new ArrayList<>();
    private List<Node> triedPaths = new ArrayList<>();
    private EntityLivingBase en = null;
    private boolean HasTPED = false;
    private PathFinder pathFinder = new PathFinder(new WalkNodeProcessor());
    private TimerUtil timer = new TimerUtil();

    public TPAura() {
        super("TPAura", Keyboard.KEY_NONE, Category.COMBAT);
    }

    public boolean qualifies(Entity e2) {
        if (e2 instanceof EntityPlayerSP) {
            return false;
        }

        if (this.findSettingByName("CanBeSeen").booleanValue() && !mc.thePlayer.canEntityBeSeen(e2)) {
            return false;
        }



        if (e2 instanceof EntityVillager) {
            return false;
        }

        if (!(e2 instanceof EntityLivingBase) || e2.isInvisible() && !this.findSettingByName("Invisibles").booleanValue() || e2.isDead || e2 == mc.thePlayer || (e2 instanceof EntityPlayer && FriendManager.isFriend((e2.getName())) || (e2 instanceof EntityPlayer && FriendManager.isFriend(e2.getName()) || (this.findSettingByName("Teams").booleanValue() && mc.thePlayer.isOnSameTeam((EntityLivingBase) e2))))) {
            return false;
        }

        if (e2 instanceof EntityPlayer && this.findSettingByName("Players").booleanValue()) {
            return true;
        }

        return ((e2 instanceof EntityMob || e2 instanceof EntitySlime || e2 instanceof EntityGhast) && this.findSettingByName("Mobs").booleanValue()) || ((e2 instanceof EntityAnimal || e2 instanceof EntitySquid || e2 instanceof EntityBat) && this.findSettingByName("Animals").booleanValue());
    }

    public EntityLivingBase getClosestEntity(float range) {
        EntityLivingBase closestEntity = null;
        float mindistance = range;

        for (Object o : mc.theWorld.loadedEntityList) {
            if (isNotItem(o) && !(o instanceof EntityPlayerSP)) {
                EntityLivingBase en = (EntityLivingBase) o;

                if (!qualifies(en)) {
                    continue;
                }

                if (Minecraft.getMinecraft().thePlayer.getDistanceToEntity(en) < mindistance) {
                    mindistance = Minecraft.getMinecraft().thePlayer.getDistanceToEntity(en);
                    closestEntity = en;
                }
            }
        }

        return closestEntity;
    }

    public boolean isNotItem(Object o) {
        if (!(o instanceof EntityLivingBase)) {
            return false;
        }

        return true;
    }

    public boolean validEntity(EntityLivingBase en) {
        if (en.isEntityEqual(Minecraft.getMinecraft().thePlayer)) {
            return false;
        }

        if (en instanceof EntityPlayer) {
            return true;
        }

        return false;
    }

    public void stopBlock() {
        if (mc.thePlayer.isBlocking()) {
            mc.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(
                    net.minecraft.network.play.client.C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN,
                    EnumFacing.UP));
        }
    }

    public void startBlock() {
        if (mc.thePlayer.isBlocking()) {
            mc.playerController.sendUseItem(mc.thePlayer, mc.theWorld, mc.thePlayer.getHeldItem());
            mc.thePlayer.setItemInUse(mc.thePlayer.getHeldItem(), mc.thePlayer.getHeldItem().getMaxItemUseDuration());
            stopBlock();
        }
    }

    public void putVertex3d(Vec3 vec) {
        GL11.glVertex3d(vec.xCoord, vec.yCoord, vec.zCoord);
    }

    public void drawOutlinedEntityESP(double x, double y, double z, double width, double height, float red,
                                      float green, float blue, float alpha) {
        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glDepthMask(false);
        GL11.glLineWidth(1);
        GL11.glColor4f(red, green, blue, alpha);
        drawOutlinedBoundingBox(new AxisAlignedBB(x - width, y, z - width, x + width, y + height, z + width));
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glDepthMask(true);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();
    }

    public void drawOutlinedBoundingBox(AxisAlignedBB aa) {
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldRenderer = tessellator.getWorldRenderer();
        worldRenderer.startDrawing(3);
        worldRenderer.addVertex(aa.minX, aa.minY, aa.minZ);
        worldRenderer.addVertex(aa.maxX, aa.minY, aa.minZ);
        worldRenderer.addVertex(aa.maxX, aa.minY, aa.maxZ);
        worldRenderer.addVertex(aa.minX, aa.minY, aa.maxZ);
        worldRenderer.addVertex(aa.minX, aa.minY, aa.minZ);
        tessellator.draw();
        worldRenderer.startDrawing(3);
        worldRenderer.addVertex(aa.minX, aa.maxY, aa.minZ);
        worldRenderer.addVertex(aa.maxX, aa.maxY, aa.minZ);
        worldRenderer.addVertex(aa.maxX, aa.maxY, aa.maxZ);
        worldRenderer.addVertex(aa.minX, aa.maxY, aa.maxZ);
        worldRenderer.addVertex(aa.minX, aa.maxY, aa.minZ);
        tessellator.draw();
        worldRenderer.startDrawing(1);
        worldRenderer.addVertex(aa.minX, aa.minY, aa.minZ);
        worldRenderer.addVertex(aa.minX, aa.maxY, aa.minZ);
        worldRenderer.addVertex(aa.maxX, aa.minY, aa.minZ);
        worldRenderer.addVertex(aa.maxX, aa.maxY, aa.minZ);
        worldRenderer.addVertex(aa.maxX, aa.minY, aa.maxZ);
        worldRenderer.addVertex(aa.maxX, aa.maxY, aa.maxZ);
        worldRenderer.addVertex(aa.minX, aa.minY, aa.maxZ);
        worldRenderer.addVertex(aa.minX, aa.maxY, aa.maxZ);
        tessellator.draw();
    }

    public Vec3 getRenderPos(double x, double y, double z) {
        x = x - mc.getRenderManager().renderPosX;
        y = y - mc.getRenderManager().renderPosY;
        z = z - mc.getRenderManager().renderPosZ;
        return new Vec3(x, y, z);
    }

    @Override
    public void onEnable() {
        AuraUtils.targets.clear();
        positions.clear();
        positionsBack.clear();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        AuraUtils.targets.clear();
        positions.clear();
        positionsBack.clear();
        super.onDisable();
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate event) {
        if (timer.hasTimeElapsed(2500, true)) {
            timer.reset();
        }

        AuraUtils.targets.clear();
        en = getClosestEntity(200);

        if (en == null) {
            return;
        }

        if (!AuraUtils.hasEntity(en)) {
            AuraUtils.targets.add(en);
        }

        if (!timerInf.hasTimeElapsed(1000 / 3, true)) {
            mc.timer.timerSpeed = 1f;
            return;
        }

        mc.timer.timerSpeed = 1f;

        for (Vec3 vec : positions) {
            HasTPED = true;
            mc.playerController.onPlayerRightClick(mc.thePlayer, mc.theWorld, null, new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY - 1, mc.thePlayer.posZ), EnumFacing.UP, new Vec3(mc.thePlayer.posX, mc.thePlayer.posY - 1, mc.thePlayer.posZ));
            mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C06PacketPlayerPosLook(vec.xCoord, vec.yCoord,
                    vec.zCoord, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, true));
        }

        if (HasTPED) {
            attack(en);
            HasTPED = false;
        }

        for (Vec3 vec : positionsBack) {
            mc.playerController.onPlayerRightClick(mc.thePlayer, mc.theWorld, null, new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY - 1, mc.thePlayer.posZ), EnumFacing.UP, new Vec3(mc.thePlayer.posX, mc.thePlayer.posY - 1, mc.thePlayer.posZ));
            mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C06PacketPlayerPosLook(vec.xCoord, vec.yCoord,
                    vec.zCoord, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, true));
        }

        updateStages();
    }

    public void updateStages() {
        if (AuraUtils.hasEntity(en)) {
            NodeProcessor processor = new NodeProcessor();
            positions.clear();
            positionsBack.clear();
            processor.getPath(new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ),
                    new BlockPos(en.posX, en.posY, en.posZ));
            triedPaths = processor.triedPaths;

            for (Node node : processor.path) {
                BlockPos pos = node.getBlockpos();
                // sendPacket(new
                // C03PacketPlayer.C04PacketPlayerPosition(node.getBlockpos().getX() + 0.5,
                // node.getBlockpos().getY(), node.getBlockpos().getZ() + 0.5, true));
                positions.add(new Vec3(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5));
                AuraUtils.targets.clear();
            }

            // sendPacket(new C02PacketUseEntity(en, C02PacketUseEntity.Action.ATTACK));
            // Go back!
            for (int i = positions.size() - 1; i > -1; i--) {
                // sendPacket(new
                // C03PacketPlayer.C04PacketPlayerPosition(positions.get(i).xCoord,
                // positions.get(i).yCoord, positions.get(i).zCoord, true));
                positionsBack.add(positions.get(i));
            }
        }
    }

    private void attack(EntityLivingBase en) {
        stopBlock();
        mc.thePlayer.swingItem();
        mc.thePlayer.sendQueue.addToSendQueue(new C02PacketUseEntity(en, Action.ATTACK));
        startBlock();

        if (Base.INSTANCE.getModuleManager().getModByName("BloodGFX").isEnabled()) {
            for (double i22 = 0; i22 < en.height; i22 = i22 + 0.2) {
                mc.effectRenderer.spawnEffectParticle(37, en.posX, en.posY + i22, en.posZ,
                        (this.rand.nextInt(6) - 3) / 5, 0.1, (this.rand.nextInt(6) - 3) / 5,
                        new int[]{Block.getIdFromBlock(Blocks.redstone_block)});
                mc.effectRenderer.spawnEffectParticle(37, en.posX, en.posY + i22, en.posZ,
                        (this.rand.nextInt(6) - 3) / 5, 0.1, (this.rand.nextInt(6) - 3) / 5,
                        new int[]{Block.getIdFromBlock(Blocks.redstone_block)});
                mc.effectRenderer.spawnEffectParticle(37, en.posX, en.posY + i22, en.posZ,
                        (this.rand.nextInt(6) - 3) / 5, 0.1, (this.rand.nextInt(6) - 3) / 5,
                        new int[]{Block.getIdFromBlock(Blocks.redstone_block)});
                mc.effectRenderer.spawnEffectParticle(37, en.posX, en.posY + i22, en.posZ,
                        (this.rand.nextInt(6) - 3) / 5, 0.1, (this.rand.nextInt(6) - 3) / 5,
                        new int[]{Block.getIdFromBlock(Blocks.redstone_block)});
                mc.effectRenderer.spawnEffectParticle(37, en.posX, en.posY + i22, en.posZ,
                        (this.rand.nextInt(6) - 3) / 5, 0.1, (this.rand.nextInt(6) - 3) / 5,
                        new int[]{Block.getIdFromBlock(Blocks.redstone_block)});
                mc.effectRenderer.spawnEffectParticle(37, en.posX, en.posY + i22, en.posZ,
                        (this.rand.nextInt(6) - 3) / 5, 0.1, (this.rand.nextInt(6) - 3) / 5,
                        new int[]{Block.getIdFromBlock(Blocks.redstone_block)});
                mc.effectRenderer.spawnEffectParticle(37, en.posX, en.posY + i22, en.posZ,
                        (this.rand.nextInt(6) - 3) / 5, 0.1, (this.rand.nextInt(6) - 3) / 5,
                        new int[]{Block.getIdFromBlock(Blocks.redstone_block)});
                mc.effectRenderer.spawnEffectParticle(37, en.posX, en.posY + i22, en.posZ,
                        (this.rand.nextInt(6) - 3) / 5, 0.1, (this.rand.nextInt(6) - 3) / 5,
                        new int[]{Block.getIdFromBlock(Blocks.redstone_block)});
                mc.effectRenderer.spawnEffectParticle(37, en.posX, en.posY + i22, en.posZ,
                        (this.rand.nextInt(6) - 3) / 5, 0.1, (this.rand.nextInt(6) - 3) / 5,
                        new int[]{Block.getIdFromBlock(Blocks.redstone_block)});
            }
        }

        float sharpLevel = EnchantmentHelper.func_152377_a(mc.thePlayer.getHeldItem(), en.getCreatureAttribute());
        boolean vanillaCrit = (mc.thePlayer.fallDistance > 0.0F) && (!mc.thePlayer.onGround)
                && (!mc.thePlayer.isOnLadder()) && (!mc.thePlayer.isInWater())
                && (!mc.thePlayer.isPotionActive(Potion.blindness)) && (mc.thePlayer.ridingEntity == null);

        if ((Base.INSTANCE.getModuleManager().getModByName("Criticals").isEnabled()) || (vanillaCrit)) {
            mc.thePlayer.onCriticalHit(en);
        }

        if (sharpLevel > 0.0F) {
            mc.thePlayer.onEnchantmentCritical(en);
        }
    }

    @Subscriber
    public void event2DRender(Event2DRender event2DRender) {
        /*GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glLineWidth(2);
        GL11.glColor4f(0.3f, 1f, 0.3f, 1f);
        GL11.glBegin(GL11.GL_LINE_STRIP);
        int i = 0;
        for (Vec3 vec : positions) {
        	putVertex3d(getRenderPos(vec.xCoord, vec.yCoord, vec.zCoord));
        	i++;
        }
        GL11.glEnd();
        GL11.glColor4f(0.3f, 1f, 0.3f, 1f);
        GL11.glBegin(GL11.GL_LINE_STRIP);
        i = 0;
        for (Vec3 vec : positionsBack) {
        	putVertex3d(getRenderPos(vec.xCoord, vec.yCoord, vec.zCoord));
        	i++;
        }
        GL11.glEnd();
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glPopMatrix();
        GL11.glLineWidth(3);
        for (Vec3 vec : positions) {
        	drawESP(1f, 0.3f, 0.3f, 1f, vec.xCoord, vec.yCoord, vec.zCoord);
        }
        GL11.glLineWidth(1.5f);
        for (Vec3 vec : positionsBack) {
        	drawESP(0.3f, 1f, 0.3f, 1f, vec.xCoord, vec.yCoord, vec.zCoord);
        }*/
    }

    public void drawESP(float red, float green, float blue, float alpha, double x, double y, double z) {
        double xPos = x - mc.getRenderManager().renderPosX;
        double yPos = y - mc.getRenderManager().renderPosY;
        double zPos = z - mc.getRenderManager().renderPosZ;
        drawOutlinedEntityESP(xPos, yPos, zPos, mc.thePlayer.width / 2, mc.thePlayer.height, red, green, blue, alpha);
    }
}
