package me.remixclient.client.modules.combat;

import pw.stamina.causam.scan.method.model.Subscriber;
import me.satisfactory.base.events.EventPacketReceive;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraft.network.play.server.S27PacketExplosion;
import org.lwjgl.input.Keyboard;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class AntiKnockback extends Module {
    public AntiKnockback() {
        super("AntiKnockback", Keyboard.KEY_NONE, Category.COMBAT);
    }

    @Subscriber
    public void readPacket(EventPacketReceive eventPacketReceive) {
        if (eventPacketReceive.packet instanceof S12PacketEntityVelocity) {
            S12PacketEntityVelocity packet = (S12PacketEntityVelocity) eventPacketReceive.packet;

            if (mc.theWorld.getEntityByID(packet.func_149412_c()) == mc.thePlayer) {
             eventPacketReceive.setCancelled(true);
            }
        }

        if (eventPacketReceive.packet instanceof S27PacketExplosion) {
            eventPacketReceive.setCancelled(true);
        }
    }

}
