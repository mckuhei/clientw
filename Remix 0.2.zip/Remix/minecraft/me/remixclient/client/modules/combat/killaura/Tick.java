package me.remixclient.client.modules.combat.killaura;

import pw.stamina.causam.scan.method.model.Subscriber;
import me.remixclient.client.modules.combat.Killaura;
import me.satisfactory.base.Base;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Mode;
import me.satisfactory.base.utils.timer.TimerUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class Tick extends Mode<Killaura> {
    private TimerUtil timer = new TimerUtil();

    public Tick(Killaura parent) {
        super(parent, "Tick");
    }

    public  void attack(Entity target2, boolean crit) {
        mc.thePlayer.swingItem();

        if (crit) {
            crit();
        } else {
            mc.getNetHandler().addToSendQueue(new C03PacketPlayer(true));
        }

        if (mc.thePlayer.isBlocking()) {
            mc.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(
                    C07PacketPlayerDigging.Action.RELEASE_USE_ITEM,
                    new BlockPos(0, 0, 0), EnumFacing.fromAngle(-255.0D)));
        }

        mc.getNetHandler().addToSendQueue(new C02PacketUseEntity(target2, C02PacketUseEntity.Action.ATTACK));
    }

    private  void crit() {
        if (mc.thePlayer.fallDistance <= 0) {
            mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.063D, mc.thePlayer.posZ, false));
            mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, false));
            mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 1.11E-4D, mc.thePlayer.posZ, false));
            mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, false));
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        mc.gameSettings.keyBindUseItem.pressed = false;
        super.onDisable();
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate event) {
        if (mc.thePlayer.isDead) {
            super.onDisable();
        }

        boolean blocking =  this.parent.findSettingByName("AutoBlock").booleanValue() && (mc.thePlayer.getHeldItem() != null ? mc.thePlayer.getHeldItem().getItem() instanceof ItemSword : false)  && !mc.thePlayer.isBlocking();
        this.parent.toAttack = this.parent.getNear(this.parent.findSettingByName("Range").doubleValue());
        this.parent.toAttack.sort(this.parent.angleComparator);

        if (this.parent.target != null) {
            if (blocking) {
                mc.gameSettings.keyBindUseItem.pressed = true;
                mc.playerController.sendUseItem(mc.thePlayer, this.mc.theWorld, mc.thePlayer.inventory.getCurrentItem());
                mc.thePlayer.setItemInUse(mc.thePlayer.getCurrentEquippedItem(), 71999);
            }

            if (timer.hasTimeElapsed(493, true)) {
                mc.thePlayer.swingItem();
                swap(9, mc.thePlayer.inventory.currentItem);
                attack(this.parent.target, false);
                attack(this.parent.target, false);
                attack(this.parent.target, true);
                swap(9, mc.thePlayer.inventory.currentItem);
                attack(this.parent.target, false);
                attack(this.parent.target, true);
                this.parent.target = null;
                mc.gameSettings.keyBindUseItem.pressed = false;
            }
        } else {
            this.parent.target = this.parent.toAttack.isEmpty() ? null : this.parent.toAttack.get(0);
        }
    }

    public void swap(int slot, int hotbarNum) {
        PlayerControllerMP playerController = mc.playerController;
        int windowId = Minecraft.getMinecraft().thePlayer.inventoryContainer.windowId;
        playerController.windowClick(windowId, slot, hotbarNum, 2, Minecraft.getMinecraft().thePlayer);
    }

}
