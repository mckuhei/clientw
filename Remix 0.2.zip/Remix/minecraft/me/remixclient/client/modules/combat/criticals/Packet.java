package me.remixclient.client.modules.combat.criticals;

import me.remixclient.client.modules.combat.Criticals;
import me.remixclient.client.modules.combat.Fastbow;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Mode;
import net.minecraft.item.ItemBow;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C07PacketPlayerDigging.Action;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import pw.stamina.causam.scan.method.model.Subscriber;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class Packet extends Mode<Criticals> {
    public Packet(Criticals parent) {
        super(parent, "Packet");
    }


}
