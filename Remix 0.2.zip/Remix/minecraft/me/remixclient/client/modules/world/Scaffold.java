package me.remixclient.client.modules.world;

import me.satisfactory.base.utils.MiscellaneousUtil;
import pw.stamina.causam.scan.method.model.Subscriber;
import me.remixclient.client.modules.combat.Killaura;
import me.satisfactory.base.events.EventMotion;
import me.satisfactory.base.events.EventSafeWalk;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import me.tojatta.api.utilities.utilities.angle.AngleUtility;
import me.satisfactory.base.utils.timer.TimerUtil;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Vec3;
import org.lwjgl.input.Keyboard;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

/**
 * @author Mees
 * @since 18/06/2017
 */

public class Scaffold extends Module {
    float[] lastKnownRots;
    private BlockData blockData;
    private List<Block> invalid;
    private TimerUtil timerMotion = new TimerUtil();
    private TimerUtil timerr = new TimerUtil();
    private int slot;
    private List<Block> invalidPlayer;


    // Hypixel
    public Scaffold() {
        super("Scaffold", Keyboard.KEY_NONE, Category.WORLD);
        this.invalid = Arrays.asList(Blocks.air, Blocks.water, Blocks.fire, Blocks.flowing_water, Blocks.lava,
                Blocks.flowing_lava);
        this.invalidPlayer = Arrays.asList(Blocks.air, Blocks.water, Blocks.fire, Blocks.flowing_water, Blocks.lava,
                Blocks.flowing_lava, Blocks.anvil, Blocks.chest, Blocks.ender_chest, Blocks.enchanting_table,
                Blocks.web, Blocks.torch, Blocks.redstone_lamp, Blocks.sand, Blocks.cactus, Blocks.ladder,
                Blocks.slime_block, Blocks.tripwire_hook, Blocks.dispenser);
        this.blockData = null;
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        mc.timer.timerSpeed = 1f;
        super.onDisable();
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate e) {
        if ((this.blockData != null) && slot != -1 && mc.inGameHasFocus) {
            if (mc.gameSettings.keyBindJump.pressed)
            {
            	 if ((mc.thePlayer.moveForward != 0 || mc.thePlayer.moveStrafing != 0)) {
            	 }
                mc.thePlayer.motionY = 0.42;
                if(timerMotion.hasTimeElapsed(1500, true)) {
                    mc.thePlayer.motionY = -0.28;
                    timerMotion.reset();
                    if(timerMotion.hasTimeElapsed(2, false)) {
                    	mc.thePlayer.motionY = 0.42;
                    }
                }
            }
            

            mc.rightClickDelayTimer = 4;
            boolean slowPlace = true;
            boolean dohax = mc.thePlayer.inventory.currentItem != slot;

            // mc.thePlayer.sendQueue.addToSendQueue(new
            // C0BPacketEntityAction(mc.thePlayer,C0BPacketEntityAction.Action.START_SNEAKING));
            if (mc.gameSettings.keyBindForward.pressed || mc.gameSettings.keyBindBack.pressed
                    || mc.gameSettings.keyBindLeft.pressed || mc.gameSettings.keyBindRight.pressed
                    || mc.gameSettings.keyBindJump.pressed) {
                if (timerr.hasTimeElapsed(MiscellaneousUtil.random(70, 100), true)) {
                    if (dohax) {
                        mc.thePlayer.setSneaking(true);
                    }

                    mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(slot));
                    mc.thePlayer.sendQueue.addToSendQueue(new C0APacketAnimation());
                    mc.playerController.onPlayerRightClick(mc.thePlayer, mc.theWorld,
                            mc.thePlayer.inventoryContainer.getSlot(36 + slot).getStack(), this.blockData.position,
                            this.blockData.face, new Vec3(this.blockData.position.getX(),
                                    this.blockData.position.getY(), this.blockData.position.getZ()));
                    // timer2.reset();
                    mc.thePlayer.setSneaking(false);

                    if (dohax)
                        mc.thePlayer.sendQueue
                                .addToSendQueue(new C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem));
                }
            }
        }

        // mc.thePlayer.sendQueue.addToSendQueue(new
        // C0BPacketEntityAction(mc.thePlayer,C0BPacketEntityAction.Action.STOP_SNEAKING));
    }


    @Subscriber
    public void onSafeWalk(EventSafeWalk e) {
       // e.setCancelled(true);
    }

    @Subscriber
    public void eventTick(EventMotion e) {

        //mc.timer.timerSpeed = 0.1f;
        int tempSlot = getBlockSlot();
        this.blockData = null;
        this.slot = -1;

        if ((this.mc.thePlayer.getHeldItem() != null) && (!this.mc.thePlayer.isSneaking()) && tempSlot != -1
                && mc.inGameHasFocus) {

            mc.rightClickDelayTimer = 0;
            this.slot = tempSlot;

            BlockPos blockBelow1 = new BlockPos(this.mc.thePlayer.posX, this.mc.thePlayer.posY - 1.0D,
                    this.mc.thePlayer.posZ);


            if (mc.theWorld.getBlockState(blockBelow1).getBlock() == Blocks.air) {
                this.blockData = this.getBlockData(blockBelow1, 1);
            }
            e.pitch = 82.5F;
            if (this.blockData != null) {
                float[] rots = AngleUtility.getAngleBlockpos(new BlockPos(this.blockData.position.getX(), this.blockData.position.getY(),
                        this.blockData.position.getZ()));
                lastKnownRots = rots;

                if (mc.gameSettings.keyBindForward.pressed || mc.gameSettings.keyBindBack.pressed
                        || mc.gameSettings.keyBindLeft.pressed || mc.gameSettings.keyBindRight.pressed
                        || mc.gameSettings.keyBindJump.pressed) {
                    e.yaw = rots[0];
                    e.pitch = 82.5F;
                   /* mc.thePlayer.rotationYaw = rots[0];
                    mc.thePlayer.rotationPitch = rots[1];*/
                    /*
                     * mc.thePlayer.rotationYaw = yaw; mc.thePlayer.rotationPitch = pitch;
                     */
                }
            } else {
                if (lastKnownRots != null) {
                    if (timerr.hasTimeElapsed(MiscellaneousUtil.random(100, 200), true)) {
                        mc.thePlayer.sendQueue.addToSendQueue(new C0APacketAnimation());
                    }

                    e.yaw = lastKnownRots[0];
                    e.pitch = lastKnownRots[1];
                    /*mc.thePlayer.rotationYaw = lastKnownRots[0];
                    mc.thePlayer.rotationPitch = lastKnownRots[1];*/
                }
            }
        }

        int n2 = 0;

        try {
            for (int k = 0; k < 9; ++k) {
                ItemStack stackInSlot3 = mc.thePlayer.inventory.getStackInSlot(k);

                if (stackInSlot3 != null && stackInSlot3.getItem() instanceof ItemBlock) {
                    n2 += stackInSlot3.stackSize;
                }
            }
        } catch (Exception ex2) {
            ex2.printStackTrace();
        }
    }

    private int getBlockSlot() {
        for (int i = 36; i < 45; ++i) {
            ItemStack itemStack = mc.thePlayer.inventoryContainer.getSlot(i).getStack();

            if (itemStack != null && itemStack.getItem() instanceof ItemBlock) {
                if (this.contains(this.invalidPlayer, ((ItemBlock) itemStack.getItem()).getBlock())) {
                    continue;
                }

                return i - 36;
            }
        }

        return -1;
    }

    private boolean contains(List<Block> list, final Block block) {
        return list.stream().anyMatch(new Predicate<Block>() {
            @Override
            public boolean test(Block e) {
                return e.equals(block);
            }
        });
    }

    public BlockData getBlockData(BlockPos pos, double d) {
        return this.mc.theWorld.getBlockState(pos.add(0, 0, d)).getBlock() != Blocks.air ? new BlockData(pos.add(0, 0, d), EnumFacing.NORTH) : (this.mc.theWorld.getBlockState(pos.add(0, 0, -d)).getBlock() != Blocks.air ? new BlockData(pos.add(0, 0, -d), EnumFacing.SOUTH) : (this.mc.theWorld.getBlockState(pos.add(d, 0, 0)).getBlock() != Blocks.air ? new BlockData(pos.add(d, 0, 0), EnumFacing.WEST) : (this.mc.theWorld.getBlockState(pos.add(-d, 0, 0)).getBlock() != Blocks.air ? new BlockData(pos.add(-d, 0, 0), EnumFacing.EAST) : (this.mc.theWorld.getBlockState(pos.add(0, -1, 0)).getBlock() != Blocks.air ? new BlockData(pos.add(0, -1, 0), EnumFacing.UP) : null))));
    }

    public Vec3 getBlockSide(BlockPos pos, EnumFacing face) {
        return face == EnumFacing.NORTH ? new Vec3((double) pos.getX(), (double) pos.getY(), (double) pos.getZ() - 0.5D) : (face == EnumFacing.EAST ? new Vec3((double) pos.getX() + 0.5D, (double) pos.getY(), (double) pos.getZ()) : (face == EnumFacing.SOUTH ? new Vec3((double) pos.getX(), (double) pos.getY(), (double) pos.getZ() + 0.5D) : (face == EnumFacing.WEST ? new Vec3((double) pos.getX() - 0.5D, (double) pos.getY(), (double) pos.getZ()) : new Vec3((double) pos.getX(), (double) pos.getY(), (double) pos.getZ()))));
    }

    public class BlockData {
        public BlockPos position;
        public EnumFacing face;

        public BlockData(BlockPos position, EnumFacing face) {
            this.position = position;
            this.face = face;
        }
    }
}