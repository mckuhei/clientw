package me.remixclient.client.modules.world;

import me.remixclient.client.modules.world.antibot.Hypixel;
import me.remixclient.client.modules.world.antibot.Mineplex;
import me.satisfactory.base.Base;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import me.satisfactory.base.setting.Setting;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;

/**
 * @author Mees
 * @since 18/06/2017
 */

public class AntiBot extends Module {
    public AntiBot() {
        super("AntiBot", Keyboard.KEY_NONE, Category.COMBAT);
        ArrayList<String> options = new ArrayList<>();
        options.add("Hypixel");
        options.add("Mineplex");
        this.addSetting(new Setting("AntibotMode", this, "Hypixel", options));
        this.addMode(new Hypixel(this));
        this.addMode(new Mineplex(this));
    }
}
