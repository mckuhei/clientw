package me.remixclient.client.modules.world;

import pw.stamina.causam.scan.method.model.Subscriber;
import me.satisfactory.base.events.EventMotion;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import me.tojatta.api.utilities.utilities.angle.AngleUtility;
import me.satisfactory.base.utils.timer.TimerUtil;
import net.minecraft.block.Block;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import org.lwjgl.input.Keyboard;

/**
 * @author Mees
 * @since 18/06/2017
 */

public class Fucker extends Module {
    TimerUtil timer = new TimerUtil();

    public Fucker() {
        super("Fucker", Keyboard.KEY_NONE, Category.WORLD);
    }

    public float[] getRotations(BlockPos pos) {
        if (pos == null) {
            return null;
        }

        double diffX = pos.getX() - mc.thePlayer.posX;
        double diffZ = pos.getZ() - mc.thePlayer.posZ;
        double diffY = pos.getY() - mc.thePlayer.getEyeHeight();
        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0 / 3.141592653589793) - 90.0f;
        float pitch = (float) (Math.atan2(diffY, dist) * 180.0 / 3.141592653589793) / (float) dist;
        return new float[]
                {
                        mc.thePlayer.rotationYaw
                                + MathHelper.wrapAngleTo180_float(yaw - mc.getMinecraft().thePlayer.rotationYaw),
                        mc.thePlayer.rotationPitch
                                + MathHelper.wrapAngleTo180_float(pitch - mc.getMinecraft().thePlayer.rotationPitch)
                };
    }

    @Subscriber
    public void eventMotion(EventMotion event) {
        for (int xOffset = -5; xOffset < 6; xOffset += 1) {
            for (int zOffset = -5; zOffset < 6; zOffset += 1) {
                for (int yOffset = 5; yOffset > -5; yOffset -= 1) {
                    double x = mc.thePlayer.posX + xOffset;
                    double y = mc.thePlayer.posY + yOffset;
                    double z = mc.thePlayer.posZ + zOffset;
                    BlockPos pos = new BlockPos(x, y, z);
                    int id = Block.getIdFromBlock(mc.theWorld.getBlockState(pos).getBlock());

                    if (((id == 26 || id == 92) && timer.hasTimeElapsed(50, true))) {
                        event.yaw = (AngleUtility.getAngleBlockpos(pos)[0]);
                        event.pitch = (AngleUtility.getAngleBlockpos(pos)[1]);
                        smashBlock(pos);
                    }
                }
            }
        }
    }


    public void smashBlock(BlockPos pos) {
        mc.thePlayer.sendQueue.addToSendQueue(new C0APacketAnimation());
        mc.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK, pos, EnumFacing.UP));
        mc.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, pos, EnumFacing.UP));
    }
}
