package me.remixclient.client.modules.world.antibot;

import pw.stamina.causam.scan.method.model.Subscriber;
import me.remixclient.client.modules.world.AntiBot;
import me.satisfactory.base.events.EventPacketReceive;
import me.satisfactory.base.module.Mode;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.server.S0CPacketSpawnPlayer;
import net.minecraft.util.BlockPos;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class Mineplex extends Mode<AntiBot> {
    public Mineplex(AntiBot parent) {
        super(parent, "Mineplex");
    }

    public  boolean isReal(EntityPlayer player) {
        for (NetworkPlayerInfo npi : mc.thePlayer.sendQueue.getPlayerInfoMap()) {
            if (npi == null || npi.getGameProfile() == null || player.getGameProfile() == null || !npi.getGameProfile().getId().toString().equals(player.getGameProfile().getId().toString()) || player.getEntityId() > 1000000000 || player.getName().startsWith("\u00a7c")) {
                continue;
            }

            return true;
        }

        return false;
    }

    @Subscriber
    public void onPacket(EventPacketReceive event) {
        if (event.getPacket() instanceof S0CPacketSpawnPlayer) {
            S0CPacketSpawnPlayer packet = (S0CPacketSpawnPlayer) event.getPacket();
            int entityX = packet.getX() / 32;
            int entityY = packet.getY() / 32;
            int entityZ = packet.getZ() / 32;

            if (mc.thePlayer.ticksExisted != 0 && entityY > mc.thePlayer.posY && mc.thePlayer.getDistance((double) entityX, (double) entityY, (double) entityZ) < 20D && !mc.theWorld.getSpawnPoint().equals(new BlockPos(entityX, mc.theWorld.getSpawnPoint().getY(), entityZ))) {
                event.setCancelled(true);
            }
        }
    }
}
