package me.remixclient.client.modules.world.antibot;

import me.satisfactory.base.events.EventPlayerUpdate;
import pw.stamina.causam.scan.method.model.Subscriber;
import me.remixclient.client.modules.world.AntiBot;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Mode;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class Hypixel extends Mode<AntiBot> {
    public Hypixel(AntiBot parent) {
        super(parent, "Hypixel");
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate tick) {
        EntityPlayer ent;

        for (Entity entity : mc.theWorld.getLoadedEntityList()) {
            if (!(entity instanceof EntityPlayer) || (ent = (EntityPlayer) entity) == mc.thePlayer) {
                continue;
            }

            if (ent.isInvisible() && ent.ticksExisted > 105) {
                ent.setInvisible(false);
                mc.theWorld.removeEntity(ent);
            }
        }
    }
}
