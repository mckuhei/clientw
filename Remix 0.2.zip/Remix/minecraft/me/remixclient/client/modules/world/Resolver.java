package me.remixclient.client.modules.world;

import pw.stamina.causam.scan.method.model.Subscriber;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import org.lwjgl.input.Keyboard;

/**
 * @author Mees
 * @since 18/06/2017
 */

public class Resolver extends Module {
    public Resolver() {
        super("Resolver", Keyboard.KEY_NONE, Category.WORLD);
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate tick) {
        if (mc.thePlayer.openContainer != null) {
            if (mc.thePlayer.openContainer instanceof ContainerChest) {
                ContainerChest curr = (ContainerChest) mc.thePlayer.openContainer;

                if (curr.getInventory().isEmpty()) {
                    mc.thePlayer.openContainer = null;
                }

                String[] TheShit = curr.getLowerChestInventory().getDisplayName().getFormattedText().split(" ");
                String TheItem = TheShit[2].replaceAll("§r", "");
                ItemStack item = new ItemStack(Item.getByNameOrId(TheItem));

                if (curr.getInventory().isEmpty()) {
                    mc.displayGuiScreen(null);
                }

                int i = 0;

                while (i < curr.getLowerChestInventory().getSizeInventory()) {
                    if (curr.getLowerChestInventory().getStackInSlot(i) != null) {
                        if (curr.getLowerChestInventory().getStackInSlot(i).getDisplayName().equalsIgnoreCase(item.getDisplayName())) {
                            mc.playerController.windowClick(curr.windowId, i, 0, 1, mc.thePlayer);
                        }
                    }

                    ++i;
                }
            }
        }
    }
}
