package me.remixclient.client.modules.render.esp;

import pw.stamina.causam.scan.method.model.Subscriber;
import me.remixclient.client.modules.render.ESP;
import me.satisfactory.base.events.Event3DRender;
import me.satisfactory.base.module.Mode;
import me.satisfactory.base.utils.Stencil;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.opengl.GL11;

public class Outline extends Mode<ESP> {
    int counter = 0;

    public Outline(ESP parent) {
        super(parent, "Outline");
    }

    @Subscriber
    public void event3DRender(Event3DRender event3DRender) {
        int list = GL11.glGenLists(1);
        Stencil.checkSetupFBO();
        Stencil.getInstance().startLayer();
        GL11.glPushMatrix();
        Stencil.getInstance().setBuffer(true);
        GL11.glNewList(list, GL11.GL_COMPILE);
        GlStateManager.enableLighting();

        for (Object obj : this.mc.theWorld.loadedEntityList) {
            Entity entity = (Entity) obj;

            if ((entity != mc.thePlayer) && ((entity instanceof EntityPlayer))) {
                GL11.glPushMatrix();
                GL11.glDisable(GL11.GL_DEPTH_TEST);
                GL11.glLineWidth(3.5F);
                GL11.glEnable(GL11.GL_BLEND);
                GL11.glEnable(GL11.GL_LINE_SMOOTH);
                GL11.glDisable(GL11.GL_TEXTURE_2D);
                double posX = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * this.mc.timer.renderPartialTicks;
                double posY = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * this.mc.timer.renderPartialTicks;
                double posZ = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * this.mc.timer.renderPartialTicks;
                GL11.glTranslated(posX - RenderManager.renderPosX, posY - RenderManager.renderPosY, posZ - RenderManager.renderPosZ);
                Render entityRender = this.mc.getRenderManager().getEntityRenderObject(entity);

                if (entityRender != null) {
                    float distance = mc.thePlayer.getDistanceToEntity(entity);
                    GlStateManager.disableLighting();
                    //net.minecraft.client.renderer.entity.RendererLivingEntity.renderLayers = false;
                    entityRender.doRender(entity, 0.0D, 0.0D, 0.0D, this.mc.timer.renderPartialTicks, this.mc.timer.renderPartialTicks);
                    //net.minecraft.client.renderer.entity.RendererLivingEntity.renderLayers = true;
                    GlStateManager.enableLighting();
                }

                GL11.glEnable(GL11.GL_TEXTURE_2D);
                GL11.glPopMatrix();
            }
        }

        GlStateManager.disableLighting();
        GL11.glEndList();
        GL11.glPolygonMode(GL11.GL_FRONT_AND_BACK, GL11.GL_LINE);
        GL11.glCallList(list);
        GL11.glPolygonMode(GL11.GL_FRONT_AND_BACK, GL11.GL_POINT);
        GL11.glCallList(list);
        Stencil.getInstance().setBuffer(false);
        GL11.glPolygonMode(GL11.GL_FRONT_AND_BACK, GL11.GL_FILL);
        GL11.glCallList(list);
        Stencil.getInstance().cropInside();
        GL11.glPolygonMode(GL11.GL_FRONT_AND_BACK, GL11.GL_LINE);
        GL11.glCallList(list);
        GL11.glPolygonMode(GL11.GL_FRONT_AND_BACK, GL11.GL_POINT);
        GL11.glCallList(list);
        GL11.glPolygonMode(GL11.GL_FRONT_AND_BACK, GL11.GL_FILL);
        Stencil.getInstance().stopLayer();
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glDeleteLists(list, 1);
        GL11.glPopMatrix();
    }
}