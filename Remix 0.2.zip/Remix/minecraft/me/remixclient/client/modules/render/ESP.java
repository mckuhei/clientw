package me.remixclient.client.modules.render;

import me.remixclient.client.modules.render.esp.Lines;
import me.remixclient.client.modules.render.esp.Outline;
import me.satisfactory.base.Base;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import me.satisfactory.base.setting.Setting;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */
public class ESP extends Module {
    public ESP() {
        super("ESP", Keyboard.KEY_NONE, Category.RENDER);
        ArrayList<String> options = new ArrayList<>();
        options.add("Outline");
        options.add("Lines");
        this.addSetting(new Setting("ESPMode", this, "Outline", options));
        this.addMode(new Outline(this));
        this.addMode(new Lines(this));
    }
}
