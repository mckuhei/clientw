package me.remixclient.client.modules.render;

import pw.stamina.causam.scan.method.model.Subscriber;
import me.remixclient.client.font.UnicodeFontRenderer;
import me.satisfactory.base.Base;
import me.satisfactory.base.events.Event3DRender;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.scoreboard.ScorePlayerTeam;
import optifine.Config;
import optifine.CustomColors;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.text.DecimalFormat;
import java.util.ArrayList;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */
public class Nametags extends Module {
    int[] colorCode = new int[32];
    FontRenderer fontRenderer3 = new UnicodeFontRenderer(new Font("Consolas", Font.PLAIN, 18));

    public Nametags() {
        super("Nametags", Keyboard.KEY_NONE, Category.RENDER);
    }

    public int getColorCode(char p_175064_1_) {
        int index = "0123456789abcdef".indexOf(p_175064_1_);

        if (index >= 0 && index < colorCode.length) {
            int color = colorCode[index];

            if (Config.isCustomColors()) {
                color = CustomColors.getTextColor(index, color);
            }

            return color;
        }

        return 16777215;
    }

    public int getTeamColor(EntityLivingBase entity) {
        String s2;
        int i2 = 16777215;
        ScorePlayerTeam scoreplayerteam = (ScorePlayerTeam) entity.getTeam();

        if (scoreplayerteam != null && (s2 = FontRenderer.getFormatFromString(scoreplayerteam.getColorPrefix())).length() >= 2) {
            i2 = getColorCode(s2.charAt(1));
        }

        return i2;
    }

    public void setColor(Color c) {
        GL11.glColor4d(c.getRed() / 255.0F, c.getGreen() / 255.0F,
                c.getBlue() / 255.0F, c.getAlpha() / 255.0F);
    }

    public long getPing(String name) {
        Minecraft mc = Minecraft.getMinecraft();

        if (mc.getNetHandler().func_175104_a(name) != null) {
            return mc.getNetHandler().func_175104_a(name).getResponseTime();
        }

        return -3L;
    }

    public void drawRect(float left, float top, float right, float bottom, Color color) {
        if (left < right) {
            float var5 = left;
            left = right;
            right = var5;
        }

        if (top < bottom) {
            float var5 = top;
            top = bottom;
            bottom = var5;
        }

        Tessellator var9 = Tessellator.getInstance();
        WorldRenderer var10 = var9.getWorldRenderer();
        GlStateManager.enableBlend();
        GlStateManager.func_179090_x();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        setColor(color);
        var10.startDrawingQuads();
        var10.addVertex(left, bottom, 0.0D);
        var10.addVertex(right, bottom, 0.0D);
        var10.addVertex(right, top, 0.0D);
        var10.addVertex(left, top, 0.0D);
        var9.draw();
        GlStateManager.func_179098_w();
        GlStateManager.disableBlend();
        setColor(Color.WHITE);
    }

    public int getMiddle(int i, int i1) {
        return (i + i1) / 2;
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Subscriber
    public void eventRender3D(Event3DRender e) {
        for (Object i : Minecraft.getMinecraft().theWorld.loadedEntityList) {
            if ((i instanceof EntityPlayer)) {
                EntityPlayer entity = (EntityPlayer) i;

                if ((entity.getName() != Minecraft.getMinecraft().thePlayer.getName()) || (!entity.isInvisible())) {
                    double n = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * this.mc.timer.renderPartialTicks;
                    double pX = n - RenderManager.renderPosX;
                    double n2 = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * this.mc.timer.renderPartialTicks;
                    double pY = n2 - RenderManager.renderPosY;
                    double n3 = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * this.mc.timer.renderPartialTicks;
                    double pZ = n3 - RenderManager.renderPosZ;
                    renderNameTag(entity, entity.getDisplayName().getFormattedText(), pX, pY, pZ);
                }
            }
        }
    }

    public void renderArmor(EntityPlayer player, int x, int y) {
        ItemStack[] items = player.getInventory();
        ItemStack inHand = player.getCurrentEquippedItem();
        ItemStack boots = items[0];
        ItemStack leggings = items[1];
        ItemStack body = items[2];
        ItemStack helm = items[3];
        ItemStack[] stuff = null;

        if (inHand != null) {
            stuff = new ItemStack[]{inHand, helm, body, leggings, boots};
        } else {
            stuff = new ItemStack[]{helm, body, leggings, boots};
        }

        ArrayList<ItemStack> stacks = new ArrayList();
        ItemStack[] array;
        int length = (array = stuff).length;
        ItemStack i;

        for (int j = 0; j < length; j++) {
            i = array[j];

            if ((i != null) && (i.getItem() != null)) {
                stacks.add(i);
            }
        }

        int width = 16 * stacks.size() / 2;
        x -= width;
        GlStateManager.disableDepth();

        for (ItemStack stack : stacks) {
            renderItem(stack, x, y);

            if (stack.getMaxDamage() > 0) {
                GlStateManager.translate(x + 2, y + 1, 0.0F);
                GlStateManager.scale(0.32F, 0.32F, 0.32F);
                GlStateManager.disableDepth();
                GlStateManager.disableLighting();
                setColor(Color.white);
                this.mc.fontRendererObj.drawString("§f" + String.valueOf(stack.getMaxDamage() - stack.getItemDamage()), 10 - this.mc.fontRendererObj.getStringWidth("§f" + String.valueOf(stack.getMaxDamage() - stack.getItemDamage())) / 2, 30.0F, Color.WHITE.getRGB());
                setColor(Color.white);
                GlStateManager.enableLighting();
                GlStateManager.enableDepth();
                GlStateManager.scale(3.125F, 3.125F, 3.125F);
                GlStateManager.translate(-x - 1, -y - 1, 0.0F);
            }

            x += 16;
        }

        GlStateManager.enableDepth();
    }

    public void renderItem(ItemStack stack, int x, int y) {
        EnchantEntry[] enchants = {new EnchantEntry(Enchantment.field_180310_c, "Prot"), new EnchantEntry(Enchantment.thorns, "Th"), new EnchantEntry(Enchantment.field_180314_l, "Sharp"), new EnchantEntry(Enchantment.fireAspect, "Fire"), new EnchantEntry(Enchantment.field_180313_o, "Kb"), new EnchantEntry(Enchantment.unbreaking, "Unb")};
        GlStateManager.pushMatrix();
        GlStateManager.pushMatrix();
        float scale1 = 0.3F;
        GlStateManager.translate(x - 3, y + 10, 0.0F);
        GlStateManager.scale(0.3F, 0.3F, 0.3F);
        GlStateManager.popMatrix();
        RenderHelper.enableGUIStandardItemLighting();
        this.mc.getRenderItem().zLevel = -100.0F;
        GlStateManager.disableDepth();
        this.mc.getRenderItem().renderItemAboveHead(stack, x, y);
        this.mc.getRenderItem().renderItemOverlayIntoGUI(this.mc.fontRendererObj, stack, x, y, null);
        GlStateManager.enableDepth();
        EnchantEntry[] array;
        int length = (array = enchants).length;

        for (int i = 0; i < length; i++) {
            EnchantEntry enchant = array[i];
            int level = EnchantmentHelper.getEnchantmentLevel(enchant.getEnchant().effectId, stack);
            String levelDisplay = "" + level;

            if (level > 10) {
                levelDisplay = "10+";
            }

            if (level > 0) {
                float scale2 = 0.32F;
                GlStateManager.translate(x + 2, y + 1, 0.0F);
                GlStateManager.scale(0.32F, 0.32F, 0.32F);
                GlStateManager.disableDepth();
                GlStateManager.disableLighting();
                setColor(Color.white);
                this.mc.fontRendererObj.drawString("§f" + enchant.getName() + " " + levelDisplay, 20 - this.mc.fontRendererObj.getStringWidth("§f" + enchant.getName() + " " + levelDisplay) / 2, 0.0F, Color.WHITE.getRGB());
                setColor(Color.white);
                GlStateManager.enableLighting();
                GlStateManager.enableDepth();
                GlStateManager.scale(3.125F, 3.125F, 3.125F);
                GlStateManager.translate(-x - 1, -y - 1, 0.0F);
                y += (int) ((this.mc.fontRendererObj.FONT_HEIGHT + 3) * 0.32F);
            }
        }

        this.mc.getRenderItem().zLevel = 0.0F;
        RenderHelper.disableStandardItemLighting();
        GlStateManager.enableAlpha();
        GlStateManager.disableBlend();
        GlStateManager.disableLighting();
        GlStateManager.popMatrix();
    }

    public void renderNameTag(EntityPlayer entity, String tag, double pX, double pY, double pZ) {
        FontRenderer var12 = this.mc.fontRendererObj;
        boolean healthBool = true;

        if (entity.getName().equals(mc.thePlayer.getName())) {
            return;
        }

        pY += (entity.isSneaking() ? 0.5D : 0.7D);
        float var13 = mc.thePlayer.getDistanceToEntity(entity) / 4.0F;

        if (var13 < 1.6F) {
            var13 = 1.6F;
        }

        int color = Base.INSTANCE.GetMainColor();
        Color friendColor = new Color(0, 255, 0);

        if (Base.INSTANCE.getFriendManager().isFriend(entity.getName())) {
            tag = "" + entity.getDisplayName().getFormattedText();
            friendColor = new Color(0, 255, 0);
        }

        // if ((getPing(entity.getName()) < 0L) || ((mc.thePlayer.isOnSameTeam(entity)) && (!((Boolean)this.teams.getValue()).booleanValue()))) {
        //}
        //if (((Boolean)this.ping.getValue()).booleanValue()) {
        //}
        DecimalFormat format = new DecimalFormat("0.##");
        //if (((Boolean)this.distance.getValue()).booleanValue()) {
        // }
        String healthSt = "";
        float health = entity.getHealth() / 1;

        if (health <= entity.getMaxHealth() * 0.25D) {
            healthSt = String.valueOf(healthSt) + "";
        } else if (health <= entity.getMaxHealth() * 0.5D) {
            healthSt = String.valueOf(healthSt) + "";
        } else if (health <= entity.getMaxHealth() * 0.75D) {
            healthSt = String.valueOf(healthSt) + "";
        } else if (health <= entity.getMaxHealth()) {
            healthSt = String.valueOf(healthSt) + "";
        }

        DecimalFormat decimalFormat = new DecimalFormat("0.##");
        tag = String.valueOf(String.valueOf(tag)) + " §4\u2764" + healthSt + "§f " + decimalFormat.format(health) + "";
        RenderManager renderManager = this.mc.getRenderManager();
        float scale = var13;
        scale /= 30.0F;
        scale = (float) (scale * 0.3D);
        GL11.glPushMatrix();
        GL11.glTranslatef((float) pX, (float) pY + 1.4F, (float) pZ);
        GL11.glNormal3f(1.0F, 1.0F, 1.0F);
        GL11.glRotatef(-renderManager.playerViewY, 0.0F, 1.0F, 0.0F);
        GL11.glRotatef(renderManager.playerViewX, 1.0F, 0.0F, 0.0F);
        GL11.glScalef(-scale, -scale, scale);
        GL11.glDisable(GL11.GL_LIGHTING);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        Tessellator var14 = Tessellator.getInstance();
        WorldRenderer var15 = var14.getWorldRenderer();
        int width = mc.fontRendererObj.getStringWidth(tag) / 2;
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        ItemStack[] items = entity.getInventory();

        if (entity.getCurrentEquippedItem() != null || items[0] != null || items[1] != null || items[2] != null || items[3] != null) {
            if (entity.getCurrentEquippedItem() != null && items[0] != null && items[1] != null && items[2] != null && items[3] != null) {
                if (width >= 41) {
                    Gui.drawRect(-width - 4, -(mc.fontRendererObj.FONT_HEIGHT + 1) - 21, width + 6, 2, new Color(22, 22, 22, 255 / 10 * 6).getRGB());
                    //drawRect(width + 6 + 2, -(mc.fontRendererObj.FONT_HEIGHT + 1) - 21, width + 6, 2, new Color(Base.INSTANCE.GetMainColor()));//Right
                    //drawRect(-width - 4, -(mc.fontRendererObj.FONT_HEIGHT + 1) - 21, -width - 6, 2, new Color(Base.INSTANCE.GetMainColor()));//Left
                } else {
                    Gui.drawRect(-41 - 4, -(mc.fontRendererObj.FONT_HEIGHT + 1) - 21, 41 + 6, 2, new Color(22, 22, 22, 255 / 10 * 6).getRGB());
                    //drawRect(41 + 6 + 2, -(mc.fontRendererObj.FONT_HEIGHT + 1) - 21, 41 + 6, 2, new Color(Base.INSTANCE.GetMainColor()));//Right
                    //drawRect(-41 - 4, -(mc.fontRendererObj.FONT_HEIGHT + 1) - 21, -41 - 2, 2, new Color(Base.INSTANCE.GetMainColor()));//Left
                }
            } else {
                if (width >= 35) {
                    Gui.drawRect(-width - 1, -(mc.fontRendererObj.FONT_HEIGHT + 1) - 21, width + 6, 2, new Color(22, 22, 22, 255 / 10 * 6).getRGB());
                    //drawRect(width + 3 + 2, -(mc.fontRendererObj.FONT_HEIGHT + 1) - 21, width + 3, 2, new Color(Base.INSTANCE.GetMainColor()));//Right
                    //drawRect(-width - 1, -(mc.fontRendererObj.FONT_HEIGHT + 1) - 21, -width - 3, 2, new Color(Base.INSTANCE.GetMainColor()));//Left
                } else {
                    Gui.drawRect(-35 - 1, -(mc.fontRendererObj.FONT_HEIGHT + 1) - 21, 35, 2, new Color(22, 22, 22, 255 / 10 * 6).getRGB());
                    //drawRect(35 + 2, -(mc.fontRendererObj.FONT_HEIGHT + 1) - 21, 35, 2, new Color(Base.INSTANCE.GetMainColor()));//Right
                    //drawRect(-35 - 1, -(mc.fontRendererObj.FONT_HEIGHT + 1) - 21, -35 - 2, 2, new Color(Base.INSTANCE.GetMainColor()));//Left
                }
            }
        } else {
            Gui.drawRect(-width - 1, -(mc.fontRendererObj.FONT_HEIGHT + 1) - 21, width + 3, -(fontRenderer3.FONT_HEIGHT + 1) - 7, new Color(22, 22, 22, 255 / 10 * 6).getRGB());
            //drawRect( width + 3 + 2, -(mc.fontRendererObj.FONT_HEIGHT + 1) - 21, width + 3  , -(fontRenderer3.FONT_HEIGHT + 1) - 7, new Color(Base.INSTANCE.GetMainColor()));
            //drawRect(-width - 1 - 2, -(mc.fontRendererObj.FONT_HEIGHT + 1) - 21, -width - 1 , -(fontRenderer3.FONT_HEIGHT + 1) - 7, new Color(Base.INSTANCE.GetMainColor()));//Left
        }

        mc.fontRendererObj.drawString(tag, getMiddle(-width - 2, width + 2) - width + 1, -(fontRenderer3.FONT_HEIGHT - 1) - 20, Color.WHITE.getRGB());
        // if (((entity instanceof EntityPlayer)) && (((Boolean)this.armor.getValue()).booleanValue()))
        //{
        GlStateManager.translate(0.0F, 1.0F, 0.0F);
        renderArmor(entity, 0, -(mc.fontRendererObj.FONT_HEIGHT + 1) - 8);
        GlStateManager.translate(0.0F, -1.0F, 0.0F);
        //  }
        GL11.glPushMatrix();
        GL11.glPopMatrix();
        //GL11.glEnable(GL11.GL_LIGHTING);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GL11.glPopMatrix();
    }

    public class EnchantEntry {
        private Enchantment enchant;
        private String name;

        public EnchantEntry(Enchantment enchant, String name) {
            this.enchant = enchant;
            this.name = name;
        }

        public Enchantment getEnchant() {
            return this.enchant;
        }

        public String getName() {
            return this.name;
        }
    }
}
