package me.remixclient.client.modules.render;

import me.remixclient.client.csgogui.CSGOGuiHelper;
import me.remixclient.client.csgogui.CSGOGuiScreen;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import org.lwjgl.input.Keyboard;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */
public class CSGOGui extends Module {
    public CSGOGui() {
        super("CSGOGui", Keyboard.KEY_NONE, Category.RENDER);
    }

    @Override
    public void onEnable() {
        CSGOGuiScreen.currentCategory = CSGOGuiHelper.lastCategory;
        mc.displayGuiScreen(new CSGOGuiScreen());
    }

    @Override
    public void onDisable() {
        super.toggle();
    }
}
