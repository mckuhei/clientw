package me.remixclient.client.modules.render;

import me.satisfactory.base.Base;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import me.satisfactory.base.setting.Setting;
import org.lwjgl.input.Keyboard;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */
public class ClickGui extends Module {
    public me.satisfactory.base.hero.clickgui.ClickGui clickgui;

    public ClickGui() {
        super("ClickGUI", Keyboard.KEY_RSHIFT, Category.RENDER);
        // ArrayList<String> options = new ArrayList<>();
        //options.add("DefaultOption");
        //options.add("Option2");
        //options.add("Option3");
        //this.addSetting(new Setting("OptionSelector", this, "DefaultOption", options));
        this.addSetting(new Setting("Rainbow", this, false));
        this.addSetting(new Setting("RainbowSpeed", this, 10, 1, 19.99, false));
        //this.addSetting(new Setting("SliderOptionDouble", this, 10, 0, 20, false));
    }

    @Override
    public void onEnable() {
        if (mc.ingameGUI != null) {
            if (this.clickgui == null) {
                this.clickgui = new me.satisfactory.base.hero.clickgui.ClickGui();
            }

            mc.displayGuiScreen(this.clickgui);
        }

    }
    @Override
    public void onDisable() {

        super.toggle();
    }
}
