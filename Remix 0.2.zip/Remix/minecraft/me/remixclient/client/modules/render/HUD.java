package me.remixclient.client.modules.render;

import me.satisfactory.base.setting.Setting;
import me.satisfactory.base.utils.FontUtils;
import me.satisfactory.base.utils.other.BlurUtils;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.util.ResourceLocation;
import pw.stamina.causam.scan.method.model.Subscriber;
import me.satisfactory.base.Base;
import me.satisfactory.base.events.Event2DRender;
import me.satisfactory.base.gui.tabgui.TabGUI;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.StringUtils;
import org.lwjgl.input.Keyboard;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Mees.
 * @since 18/06/2017
 */
public class HUD extends Module {
    public HUD() {
        super("HUD", Keyboard.KEY_NONE, Category.RENDER);
        this.addSetting(new Setting("TabGui", this, true));
        this.addSetting(new Setting("Logo", this, true));
        this.addSetting(new Setting("Arraylist", this, true));

    }
    static FontUtils fu_default = new FontUtils("Comfortaa", Font.PLAIN, 20);
    private static void renderWatermark(FontUtils fu) {
        Gui.drawImage(new ResourceLocation("remix/Remix logo 1.png"),-7, -10, 90, 90);
    }

    private static void renderArrayList(FontUtils fu) {
        int yCount = 2;
        ScaledResolution sc = new ScaledResolution(Minecraft.getMinecraft(), Minecraft.getMinecraft().displayWidth, Minecraft.getMinecraft().displayHeight);
        List<Module> modules = new ArrayList(Base.INSTANCE.getModuleManager().modules.values());
        modules.sort((m0, m1) ->
        {
            String moduleText0 = m0.getName() + (m0.getMode() == null ? "" : " (" + m0.getMode().getName() + ")");
            String moduleText1 = m1.getName() + (m1.getMode() == null ? "" : " (" + m1.getMode().getName() + ")");

            String s0 = StringUtils.stripControlCodes(moduleText0);
            String s1 = StringUtils.stripControlCodes(moduleText1);

            float w1 = fu.getWidth(s0);
            float w2 = fu.getWidth(s1);
            return -Float.compare(w1, w2);
        });

        for (Module m : modules) {
            if (m.isEnabled() && m.getCategory() != Category.HIDDEN) {
                String moduleText = m.getName() + (m.getMode() == null ? "" : " §f(" + m.getMode().getName() + ")");
               //BlurUtils.blurArea(sc.getScaledWidth() - (int)fu.getWidth(moduleText) - 9, yCount - 2, sc.getScaledWidth() + 4, 13, 100);
                Gui.drawRoundedRect(sc.getScaledWidth() - fu.getWidth(moduleText) - 9, yCount - 2, sc.getScaledWidth() + 4, yCount + 10, 2, -1610612736);
                Gui.drawRect(sc.getScaledWidth() - fu.getWidth(moduleText) - 6, yCount + 8, sc.getScaledWidth() - fu.getWidth(moduleText) - 6 - 1, yCount + 0, Base.INSTANCE.GetMainColor());

                fu.drawString(moduleText, sc.getScaledWidth() - fu.getWidth(moduleText) - 3, yCount - 1, Base.INSTANCE.GetMainColor());
                yCount += 12;
            }
        }
    }

    @Subscriber
    public void event2DRender(Event2DRender event2DRender) {
        if (Base.INSTANCE.getSettingManager().getSettingByName("TabGui") != null && Base.INSTANCE.getSettingManager().getSettingByName("TabGui").booleanValue()) {
            TabGUI.render(fu_default);
            TabGUI.init();
        }
        if (Base.INSTANCE.getSettingManager().getSettingByName("Logo").booleanValue()) {
            HUD.renderWatermark(fu_default);
        }
        if (Base.INSTANCE.getSettingManager().getSettingByName("Arraylist").booleanValue()){
            renderArrayList(fu_default);
        }

    }
}
