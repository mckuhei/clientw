package me.remixclient.client.modules.render.esp;

import me.remixclient.client.modules.render.ESP;
import me.satisfactory.base.module.Mode;

public class Lines extends Mode<ESP> {
    int counter = 0;

    public Lines(ESP parent) {
        super(parent, "Lines");
    }
}