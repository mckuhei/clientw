package me.remixclient.client.modules.render;

import pw.stamina.causam.scan.method.model.Subscriber;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import org.lwjgl.input.Keyboard;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */

public class Fullbright extends Module {
    private float gammabefore;

    public Fullbright() {
        super("Fullbright", Keyboard.KEY_NONE, Category.RENDER);
    }

    @Override
    public void onEnable() {
        gammabefore = mc.gameSettings.gammaSetting;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        mc.gameSettings.gammaSetting = gammabefore;
        super.onDisable();
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate tick) {
        mc.gameSettings.gammaSetting = 100;
    }
}
