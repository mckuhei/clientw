package me.remixclient.client.modules.render;

import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import org.lwjgl.input.Keyboard;

/**
 * @author Mees.
 * @since 18/06/2017
 */

public class AntiCopyright extends Module {
    public AntiCopyright() {
        super("AntiCopyright", Keyboard.KEY_NONE, Category.RENDER);
    }
}
