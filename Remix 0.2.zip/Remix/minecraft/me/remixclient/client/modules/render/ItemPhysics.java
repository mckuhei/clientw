package me.remixclient.client.modules.render;

import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import org.lwjgl.input.Keyboard;

public class ItemPhysics extends Module {
    public ItemPhysics() {
        super("ItemPhysics", Keyboard.KEY_NONE, Category.RENDER);
    }
}
