package me.remixclient.client.modules.player;

import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import org.lwjgl.input.Keyboard;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */

public class NoSwing extends Module {
    public NoSwing() {
        super("NoSwing", Keyboard.KEY_NONE, Category.PLAYER);
    }
}
