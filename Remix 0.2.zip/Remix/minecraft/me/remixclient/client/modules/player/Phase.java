package me.remixclient.client.modules.player;

import me.remixclient.client.modules.player.phase.Guardian;
import me.remixclient.client.modules.player.phase.HCF;
import me.remixclient.client.modules.player.phase.Virtue;
import me.satisfactory.base.Base;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import me.satisfactory.base.setting.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;

/**
 * @author Mees
 * @since 18/06/2017
 */

public class Phase extends Module {
    public Phase() {
        super("Phase", Keyboard.KEY_NONE, Category.PLAYER);
        ArrayList<String> options = new ArrayList<>();
        options.add("HCF");
        options.add("Guardian");
        options.add("Virtue");
        this.addSetting(new Setting("PhaseMode", this, "HCF", options));
        this.addMode(new HCF(this));
        this.addMode(new Guardian(this));
        this.addMode(new Virtue(this));
    }

    public boolean isInsideBlock() {
        if (mc.thePlayer != null && mc.theWorld != null) {
            for (int x = MathHelper.floor_double(mc.thePlayer.boundingBox.minX); x < MathHelper
                    .floor_double(mc.thePlayer.boundingBox.maxX) + 1; x++) {
                for (int y = MathHelper.floor_double(mc.thePlayer.boundingBox.minY); y < MathHelper
                        .floor_double(mc.thePlayer.boundingBox.maxY) + 1; y++) {
                    for (int z = MathHelper.floor_double(mc.thePlayer.boundingBox.minZ); z < MathHelper
                            .floor_double(mc.thePlayer.boundingBox.maxZ) + 1; z++) {
                        Block block = mc.theWorld.getBlockState(new BlockPos(x, y, z)).getBlock();
                        AxisAlignedBB boundingBox;

                        if ((block != null) && (!(block instanceof BlockAir))
                                && ((boundingBox = block.getCollisionBoundingBox(mc.theWorld, new BlockPos(x, y, z),
                                mc.theWorld.getBlockState(new BlockPos(x, y, z)))) != null)
                                && (mc.thePlayer.boundingBox.intersectsWith(boundingBox))) {
                            return true;
                        }
                    }
                }
            }
        }

        return false;
    }
}
