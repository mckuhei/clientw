package me.remixclient.client.modules.player.phase;

import pw.stamina.causam.scan.method.model.Subscriber;
import me.remixclient.client.modules.player.Phase;
import me.satisfactory.base.events.EventBBSet;
import me.satisfactory.base.events.EventMove;
import me.satisfactory.base.events.EventPushOutOfBlocks;
import me.satisfactory.base.module.Mode;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */
public class Virtue extends Mode<Phase> {
    public Virtue(Phase parent) {
        super(parent, "Virtue");
    }

    @Subscriber
    public void blockPush(EventPushOutOfBlocks event) {
        if (this.parent.isInsideBlock() && this.mc.thePlayer.isSneaking()) {
            event.setCancelled(true);
        }
    }

    @Subscriber
    public void eventBBSet(EventBBSet event) {
        if (event.getBoundingBox() != null && mc.thePlayer != null) {
            if (event.getBoundingBox().maxY > this.mc.thePlayer.boundingBox.minY && this.mc.thePlayer.isSneaking()) {
                event.setBoundingBox(null);
            }
        }
    }

    @Subscriber
    public void eventMove(EventMove tick) {
        if (this.parent.isInsideBlock() && this.mc.thePlayer.isSneaking()) {
            this.mc.thePlayer.boundingBox.offsetAndUpdate((double) this.mc.thePlayer.movementInput.moveForward * 2.6 * Math.cos(Math.toRadians(this.mc.thePlayer.rotationYaw + 90.0f)) + (double) this.mc.thePlayer.movementInput.moveStrafe * 2.6 * Math.sin(Math.toRadians(this.mc.thePlayer.rotationYaw + 90.0f)), 0.0, (double) this.mc.thePlayer.movementInput.moveForward * 2.6 * Math.sin(Math.toRadians(this.mc.thePlayer.rotationYaw + 90.0f)) - (double) this.mc.thePlayer.movementInput.moveStrafe * 2.6 * Math.cos(Math.toRadians(this.mc.thePlayer.rotationYaw + 90.0f)));
        }
    }
}
