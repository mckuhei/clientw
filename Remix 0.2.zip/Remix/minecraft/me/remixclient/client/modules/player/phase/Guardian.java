package me.remixclient.client.modules.player.phase;

import me.satisfactory.base.utils.MiscellaneousUtil;
import pw.stamina.causam.scan.method.model.Subscriber;
import me.remixclient.client.modules.player.Phase;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Mode;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.potion.Potion;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */
public class Guardian extends Mode<Phase> {
    int counter = 0;

    public Guardian(Phase parent) {
        super(parent, "Guardian");
    }

    public  float getDirection() {
        float yaw = mc.thePlayer.rotationYawHead;
        float forward = mc.thePlayer.moveForward;
        float strafe = mc.thePlayer.moveStrafing;
        yaw += (forward < 0.0F ? 180 : 0);

        if (strafe < 0.0F) {
            yaw += (forward == 0.0F ? 90 : forward < 0.0F ? -45 : 45);
        }

        if (strafe > 0.0F) {
            yaw -= (forward == 0.0F ? 90 : forward < 0.0F ? -45 : 45);
        }

        return yaw * 0.017453292F;
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        mc.timer.timerSpeed = 1;
        super.onDisable();
    }



    @Subscriber
    public void onUpdate(EventPlayerUpdate tick) {
        mc.thePlayer.hurtTime = 5;
        mc.timer.timerSpeed = 0.3f;

        if (mc.gameSettings.keyBindForward.pressed || mc.gameSettings.keyBindBack.pressed || mc.gameSettings.keyBindLeft.pressed || mc.gameSettings.keyBindRight.pressed) {
            mc.thePlayer.motionX = 0;
            mc.thePlayer.motionZ = 0;
            double speed = MiscellaneousUtil.getBaseMoveSpeed();
            mc.thePlayer.onGround = false;
            mc.thePlayer.setSpeed(speed);
            mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, false));
            final float yaw = mc.thePlayer.rotationYaw;
            mc.thePlayer.boundingBox.offsetAndUpdate(0.7 * Math.cos(Math.toRadians(yaw + 450.0f)), 0.0, 0.7 * Math.sin(Math.toRadians(yaw + 450.0f)));
        } else {
            mc.thePlayer.motionX = 0;
            mc.thePlayer.motionZ = 0;
        }
    }
}
