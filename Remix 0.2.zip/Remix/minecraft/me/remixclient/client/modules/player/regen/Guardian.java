package me.remixclient.client.modules.player.regen;

import pw.stamina.causam.scan.method.model.Subscriber;
import me.remixclient.client.modules.player.Regen;
import me.satisfactory.base.Base;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Mode;
import net.minecraft.network.play.client.C03PacketPlayer;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */
public class Guardian extends Mode<Regen> {
    public Guardian(Regen parent) {
        super(parent, "Guardian");
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate tick) {
        if (mc.thePlayer.getHealth() < 10.0f && !mc.thePlayer.isDead && mc.thePlayer.getFoodStats().getFoodLevel() > 17 && mc.thePlayer.onGround) {
            mc.thePlayer.onGround = false;

            for (int i = 0; i < this.parent.findSettingByName("RegenPackets").doubleValue(); ++i) {
                mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX,
                        mc.thePlayer.posY - 0.0000000000000000000001, mc.thePlayer.posZ, mc.thePlayer.onGround));
            }
        }
    }
}
