package me.remixclient.client.modules.player.regen;

import pw.stamina.causam.scan.method.model.Subscriber;
import me.remixclient.client.modules.player.Regen;
import me.satisfactory.base.Base;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Mode;
import net.minecraft.network.play.client.C03PacketPlayer;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */
public class Packet extends Mode<Regen> {
    int counter = 0;

    public Packet(Regen parent) {
        super(parent, "Packet");
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate tick) {
        if (!mc.thePlayer.capabilities.isCreativeMode && mc.thePlayer.getFoodStats().getFoodLevel() > 17
                && mc.thePlayer.getHealth() < mc.thePlayer.getMaxHealth() && mc.thePlayer.getHealth() != 0) {
            for (int i = 0; i < this.parent.findSettingByName("RegenPackets").doubleValue(); i++) {
                mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer());
            }
        }
    }
}
