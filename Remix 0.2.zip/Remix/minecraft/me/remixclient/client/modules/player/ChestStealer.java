package me.remixclient.client.modules.player;

import pw.stamina.causam.scan.method.model.Subscriber;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import me.satisfactory.base.setting.Setting;
import me.satisfactory.base.utils.timer.TimerUtil;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.item.ItemStack;

import org.lwjgl.input.Keyboard;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */

public class ChestStealer extends Module {
    TimerUtil timer2 = new TimerUtil();

    public ChestStealer() {
        super("ChestStealer", Keyboard.KEY_NONE, Category.PLAYER);
        this.addSetting(new Setting("DelayChestStealer", this, 150, 0, 1000, false));
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate tick) {

        if (mc.thePlayer.openContainer != null) {
            if (mc.thePlayer.openContainer instanceof ContainerChest) {
                ContainerChest container = (ContainerChest) mc.thePlayer.openContainer;
                if (isChestEmpty())
    				mc.thePlayer.closeScreen();
                if (container.getInventory().isEmpty()) {
                    mc.thePlayer.openContainer = null;
                }

                if (!container.getLowerChestInventory().getName().equals("Game Menu") && !container.getLowerChestInventory().getName().contains("Play")) {
                    int i = 0;

                    while (i < container.getLowerChestInventory().getSizeInventory()) {
                        if (container.getLowerChestInventory().getStackInSlot(i) != null && timer2.hasTimeElapsed(this.findSettingByName("DelayChestStealer").doubleValue(), false)) {
                            mc.playerController.windowClick(container.windowId, i, 0, 1, mc.thePlayer);
                            timer2.reset();
                        }

                        ++i;
                    }

                    if (container.getInventory().isEmpty()) {
                    	mc.thePlayer.closeScreen();
                    }
                }
            }
        }
    }
    private boolean isChestEmpty() {
    	 if (mc.thePlayer.openContainer != null) {
             if (mc.thePlayer.openContainer instanceof ContainerChest) {
                 ContainerChest container = (ContainerChest) mc.thePlayer.openContainer;
		for (int index = 0; index <= container.getLowerChestInventory().getSizeInventory(); index++) {
			ItemStack stack = container.getLowerChestInventory().getStackInSlot(index);
			if (stack != null)
				return false;
		}
             }
    	 }
   

		return true;
	}
}