package me.remixclient.client.modules.player;

import net.minecraft.network.play.client.C03PacketPlayer;
import pw.stamina.causam.scan.method.model.Subscriber;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import org.lwjgl.input.Keyboard;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */

public class Nofall extends Module {
    public Nofall() {
        super("Nofall", Keyboard.KEY_NONE, Category.PLAYER);
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate event) {
if (mc.thePlayer.fallDistance >= 3) {
    event.onGround = true;
    mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer(true));
    mc.thePlayer.fallDistance = 0;
}
    }
}
