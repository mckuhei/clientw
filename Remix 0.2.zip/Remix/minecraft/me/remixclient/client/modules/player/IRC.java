package me.remixclient.client.modules.player;

import pw.stamina.causam.scan.method.model.Subscriber;
import me.remixclient.client.irc.IrcManager;
import me.satisfactory.base.Base;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import org.lwjgl.input.Keyboard;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */

public class IRC extends Module {
    IrcManager irc = Base.INSTANCE.ircManager;

    public IRC() {
        super("IRC", Keyboard.KEY_NONE, Category.PLAYER);
    }

    @Override
    public void onDisable() {
        mc.rightClickDelayTimer = 4;
        super.onDisable();
    }

    @Override
    public void onToggle() {
        Base.INSTANCE.addIRCMessage("Use '@Message' to chat");
        Base.INSTANCE.addIRCMessage("You will be know as: §3" + Base.INSTANCE.ircManager.getNick());
    }

    @Subscriber
    private void onUpdate(EventPlayerUpdate event) {
        if (Base.INSTANCE.ircManager.newMessages()) {
            Base.INSTANCE.ircManager.getUnreadLines().forEach(irc ->
            {
                Base.INSTANCE.addIRCMessage(irc.getSender() + ": " + irc.getLine());
                irc.setRead(true);
            });
        }
    }
}
