package me.remixclient.client.modules.player;

import me.remixclient.client.modules.player.regen.Guardian;
import me.remixclient.client.modules.player.regen.Packet;
import me.satisfactory.base.Base;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import me.satisfactory.base.setting.Setting;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */

public class Regen extends Module {
    public Regen() {
        super("Regen", Keyboard.KEY_NONE, Category.PLAYER);
        ArrayList<String> options = new ArrayList<>();
        options.add("Packet");
        options.add("Guardian");
        this.addSetting(new Setting("RegenMode", this, "Packet", options));
        this.addSetting(new Setting("RegenPackets", this, 100, 10, 1000, false));
        this.addMode(new Packet(this));
        this.addMode(new Guardian(this));
    }
}
