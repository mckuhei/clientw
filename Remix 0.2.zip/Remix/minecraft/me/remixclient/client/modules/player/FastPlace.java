package me.remixclient.client.modules.player;

import pw.stamina.causam.scan.method.model.Subscriber;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import org.lwjgl.input.Keyboard;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */

public class FastPlace extends Module {
    public FastPlace() {
        super("FastPlace", Keyboard.KEY_NONE, Category.PLAYER);
    }

    @Override
    public void onEnable() {
        mc.rightClickDelayTimer = 1;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        mc.rightClickDelayTimer = 4;
        super.onDisable();
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate tick) {
        mc.rightClickDelayTimer = 1;
    }
}
