package me.remixclient.client.modules.player;

import pw.stamina.causam.scan.method.model.Subscriber;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import me.satisfactory.base.setting.Setting;
import me.satisfactory.base.utils.timer.TimerUtil;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.*;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import org.lwjgl.input.Keyboard;

import java.util.Iterator;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */

public class InvCleaner extends Module {
    TimerUtil timer = new TimerUtil();
    private int slots;

    private double numberIdkWillfigureout;
    private boolean someboolean;

    public InvCleaner() {
        super("InvCleaner", Keyboard.KEY_NONE, Category.PLAYER);
        this.addSetting(new Setting("CleanSpeed", this, 50, 0, 500, false));
    }

    public static boolean isItemBad(ItemStack item) {
        return (item != null) && ((item.getItem().getUnlocalizedName().contains("TNT"))
                || (item.getItem().getUnlocalizedName().contains("stick"))
                || (item.getItem().getUnlocalizedName().contains("egg"))
                || (item.getItem().getUnlocalizedName().contains("string"))
                || (item.getItem().getUnlocalizedName().contains("flint"))
                || (item.getItem().getUnlocalizedName().contains("compass"))
                || (item.getItem().getUnlocalizedName().contains("feather"))
                || (item.getItem().getUnlocalizedName().contains("map"))
                || (item.getItem().getUnlocalizedName().contains("bucket"))
                || (item.getItem().getUnlocalizedName().contains("chest"))
                || (item.getItem().getUnlocalizedName().contains("snowball"))
                || (item.getItem().getUnlocalizedName().contains("dye"))
                || (item.getItem().getUnlocalizedName().contains("web"))
                || (item.getItem().getUnlocalizedName().contains("gold_ingot"))
                || (item.getItem().getUnlocalizedName().contains("arrow"))
                || (item.getItem().getUnlocalizedName().contains("leather"))
                || (item.getItem().getUnlocalizedName().contains("wheat"))
                || (item.getItem().getUnlocalizedName().contains("fish"))
                || (item.getItem().getUnlocalizedName().contains("enchant"))
                || (item.getItem().getUnlocalizedName().contains("exp")) || ((item.getItem() instanceof ItemPickaxe))
                || ((item.getItem() instanceof ItemTool)) || ((item.getItem() instanceof ItemArmor))
                || ((item.getItem() instanceof ItemSword)) || ((item.getItem() instanceof ItemBow))
                || ((item.getItem().getUnlocalizedName().contains("potion")) && (isBadPotion(item))));
    }

    public static boolean isBadPotion(ItemStack itemStack) {
        if (itemStack == null) {
            return false;
        }

        if (!(itemStack.getItem() instanceof ItemPotion)) {
            return false;
        }

        ItemPotion itemPotion = (ItemPotion) itemStack.getItem();
        Iterator iterator = itemPotion.getEffects(itemStack).iterator();
        PotionEffect potionEffect;

        do {
            if (!iterator.hasNext()) {
                return false;
            }

            Object pObj = iterator.next();
            potionEffect = (PotionEffect) pObj;

            if (potionEffect.getPotionID() == Potion.poison.getId()) {
                return true;
            }

            if (potionEffect.getPotionID() == Potion.moveSlowdown.getId()) {
                return true;
            }

            if (potionEffect.getEffectName() == null) {
                return true;
            }
        }
        while (potionEffect.getPotionID() != Potion.harm.getId());

        return true;
    }

    private static double getEnchantmentOnSword(ItemStack itemStack) {
        if (itemStack == null) {
            return 0.0D;
        }

        if (!(itemStack.getItem() instanceof ItemSword)) {
            return 0.0D;
        }

        ItemSword itemSword = (ItemSword) itemStack.getItem();
        return EnchantmentHelper.getEnchantmentLevel(Enchantment.field_180314_l.effectId, itemStack)
                + itemSword.func_150931_i();
    }

    @Override
    public void onEnable() {
        slots = 9;
        numberIdkWillfigureout = getEnchantmentOnSword(mc.thePlayer.getHeldItem());
        super.onEnable();
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate tick) {
        if ((slots >= 45) && (!someboolean)) {
            slots = 9;
            return;
        }

        if (someboolean) {
            if (timer.hasTimeElapsed(
                    (long) this.findSettingByName("CleanSpeed").doubleValue(), true)
                    || mc.thePlayer.inventoryContainer.getSlot(slots).getStack() == null) {
                mc.playerController.windowClick(0, -999, 0, 0, mc.thePlayer);
                mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem));
                mc.playerController.syncCurrentPlayItem();
                someboolean = false;
            }

            return;
        }

        numberIdkWillfigureout = getEnchantmentOnSword(mc.thePlayer.getHeldItem());
        ItemStack stack = mc.thePlayer.inventoryContainer.getSlot(slots).getStack();


        if ((isItemBad(stack)) && (getEnchantmentOnSword(stack) <= numberIdkWillfigureout)
                && (stack != mc.thePlayer.getHeldItem())) {
            mc.playerController.windowClick(0, slots, 0, 0, mc.thePlayer);
            someboolean = true;
        }

        slots += 1;
    }
}
