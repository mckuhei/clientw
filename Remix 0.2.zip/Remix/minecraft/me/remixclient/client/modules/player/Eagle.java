package me.remixclient.client.modules.player;

import pw.stamina.causam.scan.method.model.Subscriber;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.BlockPos;
import org.lwjgl.input.Keyboard;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */

public class Eagle extends Module {
    public Eagle() {
        super("Eagle", Keyboard.KEY_NONE, Category.PLAYER);
    }

    @Override
    public void onDisable() {
        mc.rightClickDelayTimer = 4;

        if (!Keyboard.isKeyDown(this.mc.gameSettings.keyBindSneak.getKeyCode())) {
            mc.gameSettings.keyBindSneak.pressed = false;
        }

        super.onDisable();
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate event) {
        mc.rightClickDelayTimer = 0;

        try {
            if ((mc.thePlayer.isCollided) && ((mc.thePlayer.getCurrentEquippedItem().getItem() instanceof ItemBlock))) {
                if (mc.theWorld.getBlockState(new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY - 1.0D, mc.thePlayer.posZ)).getBlock() == Blocks.air) {
                    mc.gameSettings.keyBindSneak.pressed = true;
                } else {
                    mc.gameSettings.keyBindSneak.pressed = false;
                }
            }
        } catch (Exception localException) {
        }
    }
}
