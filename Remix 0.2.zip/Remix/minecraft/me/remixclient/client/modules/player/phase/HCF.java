package me.remixclient.client.modules.player.phase;

import pw.stamina.causam.scan.method.model.Subscriber;
import me.remixclient.client.modules.player.Phase;
import me.satisfactory.base.events.EventBBSet;
import me.satisfactory.base.events.EventMove;
import me.satisfactory.base.module.Mode;
import net.minecraft.network.play.client.C03PacketPlayer;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */
public class HCF extends Mode<Phase> {
    int counter = 0;

    public HCF(Phase parent) {
        super(parent, "HCF");
    }

    @Subscriber
    public void eventBBSet(EventBBSet event) {
        if (event.getBoundingBox() != null && event.getBoundingBox().maxY > this.mc.thePlayer.boundingBox.minY && this.mc.thePlayer.isSneaking()) {
            event.setBoundingBox(null);
        }
    }

    @Subscriber
    public void eventMove(EventMove tick) {
        if (this.parent.isInsideBlock() && mc.thePlayer.isSneaking()) {
            mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, false));
            final float yaw = mc.thePlayer.rotationYaw;
            mc.thePlayer.boundingBox.offsetAndUpdate(0.7 * Math.cos(Math.toRadians(yaw + 450.0f)), 0.0, 0.7 * Math.sin(Math.toRadians(yaw + 450.0f)));
        }

        if (this.parent.isInsideBlock()) {
            return;
        }

        double multiplier = 0.2D;
        double mx = Math.cos(Math.toRadians(mc.thePlayer.rotationYaw + 90.0F));
        double mz = Math.sin(Math.toRadians(mc.thePlayer.rotationYaw + 90.0F));
    }
}
