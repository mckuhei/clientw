package me.remixclient.client.modules.movement.longjump;

import me.satisfactory.base.events.EventPlayerUpdate;
import pw.stamina.causam.scan.method.model.Subscriber;
import me.remixclient.client.modules.movement.Longjump;
import me.satisfactory.base.module.Mode;
import net.minecraft.block.Block;
import net.minecraft.block.BlockStairs;
import net.minecraft.util.BlockPos;

import me.satisfactory.base.events.EventTick;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class Guardian extends Mode<Longjump> {

    public Guardian(Longjump parent) {
        super(parent, "Guardian");
    }


    public  Block getBlock(BlockPos pos) {
        return mc.theWorld.getBlockState(pos).getBlock();
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate event) {
        BlockPos belowPlayerPos =
                new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY - 1D, mc.thePlayer.posZ);
        Block block = getBlock(belowPlayerPos);

        if ((mc.thePlayer.moveForward != 0.0f || mc.thePlayer.moveStrafing != 0.0f) && !(block instanceof BlockStairs)) {
            if (mc.thePlayer.onGround) {
                mc.thePlayer.motionX = 0.0;
                mc.thePlayer.motionZ = 0.0;
                mc.thePlayer.setSpeed(9.5);
                mc.thePlayer.motionY = 0.4;
            } else {
                mc.thePlayer.motionY += 0.03;
                mc.thePlayer.setSpeed((float) Math.sqrt(mc.thePlayer.motionX * mc.thePlayer.motionX + mc.thePlayer.motionZ * mc.thePlayer.motionZ));
            }
        } else {
            mc.thePlayer.motionX = 0.0;
            mc.thePlayer.motionZ = 0.0;
        }
    }

}
