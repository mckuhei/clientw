package me.remixclient.client.modules.movement.longjump;

import pw.stamina.causam.scan.method.model.Subscriber;
import me.remixclient.client.modules.movement.Longjump;
import me.satisfactory.base.events.EventMove;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Mode;
import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.util.MovementInput;

import java.math.BigDecimal;
import java.math.RoundingMode;
import me.satisfactory.base.events.EventTick;
/**
 * @author Mees
 * @since 18/06/2017
 */
public class Hypixel extends Mode<Longjump> {
    int jumps = 0;
    private double speed;
    private int stage;
    private double moveSpeed;
    private double lastDist;
    private double Meme1;
    private int Meme2;
    private int airTicks;
    private int groundTicks;
    private float Meme3;
    private int Meme4;

    public Hypixel(Longjump parent) {
        super(parent, "Hypixel");
    }

    public  void damagePlayer() {
        for (int index = 0; index < 60; ++index) {
            mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.06, mc.thePlayer.posZ, false));
            mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, false));
        }

        mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.1, mc.thePlayer.posZ, false));
    }

    public  double round(double value, int places) {
        if (places < 0) {
            throw new IllegalArgumentException();
        }

        BigDecimal bd = new BigDecimal(value);
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }

    @Override
    public void onEnable() {
        this.moveSpeed = getBaseMoveSpeed();
        speed = 1;
        groundTicks = 8;
        mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY - 0.001, mc.thePlayer.posZ);
        mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.001, mc.thePlayer.posZ);
        this.stage = 0;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate event) {
        // MiscellaneousUtil.addChatMessage(""+groundTicks);
        double xDist = mc.thePlayer.posX - mc.thePlayer.prevPosX;
        double zDist = mc.thePlayer.posZ - mc.thePlayer.prevPosZ;
        this.lastDist = Math.sqrt(xDist * xDist + zDist * zDist);
    }

    @Subscriber
    public void eventMove(EventMove event) {
        if (mc.thePlayer.onGround == false) {
            this.moveSpeed = getBaseMoveSpeed() / 2;
        }

        MovementInput movementInput = mc.thePlayer.movementInput;
        float forward = movementInput.moveForward;
        float strafe = movementInput.moveStrafe;
        float yaw = Minecraft.getMinecraft().thePlayer.rotationYaw;
        double round = round(mc.thePlayer.posY - (int) mc.thePlayer.posY, 3);

        if ((this.stage == 1) && ((mc.thePlayer.moveForward != 0.0F) || (mc.thePlayer.moveStrafing != 0.0F))) {
            this.stage = 2;
            this.moveSpeed = (1.38D * getBaseMoveSpeed() - 0.01D) / 1.6;
        } else if (this.stage == 2) {
            this.stage = 3;
            event.x = 0.0;
            event.z = 0.0;
            mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY - 0.001, mc.thePlayer.posZ);
            mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.001, mc.thePlayer.posZ);
            mc.thePlayer.motionY = 0.423D;
            event.y = 0.423D;
            this.moveSpeed *= 2.149D;
        } else if (this.stage == 3) {
            this.stage = 4;
            double difference = 0.66D * (this.lastDist - getBaseMoveSpeed());
            this.moveSpeed = (this.lastDist - difference) * 1.95;
        } else {
            if ((mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer,
                    mc.thePlayer.boundingBox.offset(0.0D, mc.thePlayer.motionY, 0.0D)).size() > 0)
                    || (mc.thePlayer.isCollidedVertically)) {
                this.stage = 1;
            }

            this.moveSpeed = (this.lastDist - this.lastDist / 159.0D);

            if (mc.thePlayer.motionY < 0.1) {
                mc.thePlayer.motionY -= 0.005;
            }
        }

        this.moveSpeed = Math.max(this.moveSpeed, getBaseMoveSpeed());

        if ((forward == 0.0F) && (strafe == 0.0F)) {
            event.x = 0.0D;
            event.z = 0.0D;
        } else if (forward != 0.0F) {
            if (strafe >= 1.0F) {
                yaw += (forward > 0.0F ? -45 : 45);
                strafe = 0.0F;
            } else if (strafe <= -1.0F) {
                yaw += (forward > 0.0F ? 45 : -45);
                strafe = 0.0F;
            }

            if (forward > 0.0F) {
                forward = 1.0F;
            } else if (forward < 0.0F) {
                forward = -1.0F;
            }
        }

        double mx = Math.cos(Math.toRadians(yaw + 90.0F));
        double mz = Math.sin(Math.toRadians(yaw + 90.0F));
        event.x = (forward * this.moveSpeed * mx + strafe * this.moveSpeed * mz);
        event.z = (forward * this.moveSpeed * mz - strafe * this.moveSpeed * mx);

        if (mc.thePlayer.fallDistance > 1.0) {
            event.x = 0;
            event.z = 0;
        }
    }

    private double getBaseMoveSpeed() {
        double baseSpeed = 0.2873D;

        if (mc.thePlayer.isPotionActive(Potion.moveSpeed)) {
            int amplifier = mc.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier();
            baseSpeed *= (1.0D + 0.2D * (amplifier + 1));
        }

        return baseSpeed;
    }
}
