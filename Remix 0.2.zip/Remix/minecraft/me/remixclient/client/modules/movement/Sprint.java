package me.remixclient.client.modules.movement;

import me.satisfactory.base.events.EventTick;
import pw.stamina.causam.scan.method.model.Subscriber;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import me.satisfactory.base.setting.Setting;
import org.lwjgl.input.Keyboard;

/**
 * @author Mees
 * @since 18/06/2017
 */

public class Sprint extends Module {
    public Sprint() {
        super("Sprint", Keyboard.KEY_NONE, Category.MOVE);
        this.addSetting(new Setting("MultiDir", this, true));
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate tick) {

        if (mc.thePlayer != null && mc.theWorld != null) {
            boolean oneOfTheKeys = (mc.gameSettings.keyBindForward.pressed || mc.gameSettings.keyBindBack.pressed || mc.gameSettings.keyBindLeft.pressed || mc.gameSettings.keyBindRight.pressed);
            mc.thePlayer.setSprinting(((mc.gameSettings.keyBindForward.pressed || (this.findSettingByName("MultiDir").booleanValue() && oneOfTheKeys))) && !mc.thePlayer.isSneaking());
        }
    }
}
