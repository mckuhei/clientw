package me.remixclient.client.modules.movement;

import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import org.lwjgl.input.Keyboard;

/**
 * @author Mees
 * @since 18/06/2017
 */

public class InvMove extends Module {
    public InvMove() {
        super("InvMove", Keyboard.KEY_NONE, Category.MOVE);
    }
}
