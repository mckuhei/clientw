package me.remixclient.client.modules.movement;

import me.remixclient.client.modules.movement.speed.*;
import me.satisfactory.base.Base;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import me.satisfactory.base.setting.Setting;
import me.satisfactory.base.utils.MiscellaneousUtil;
import me.satisfactory.base.utils.timer.TimerUtil;
import net.minecraft.potion.Potion;
import org.lwjgl.input.Keyboard;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;

/**
 * @author Mees
 * @since 18/06/2017
 */

public class Speed extends Module {
    public static double speed;
    public static int stage;
    public static double moveSpeed;
    public static TimerUtil timer = new TimerUtil();
    public static double x;
    public static double z;
    public static float ground = 0.0F;
    public static int ticks;

    public Speed() {
        super("Speed", Keyboard.KEY_NONE, Category.MOVE);
        ArrayList<String> options = new ArrayList<>();
        options.add("BHop");
        options.add("Lowhop");
        options.add("Hypixel");
        options.add("Mineplex");
        options.add("GuardianHop");
        options.add("Mineman");
        options.add("AAC");
        options.add("DEV");
        this.addSetting(new Setting("SpeedMode", this, "BHop", options));
        this.addMode(new BHop(this));
        this.addMode(new Lowhop(this));
        this.addMode(new Hypixel(this));
        this.addMode(new Mineplex(this));
        this.addMode(new GuardianHop(this));
        this.addMode(new Mineman(this));
        this.addMode(new AAC(this));
        this.addMode(new DEV(this));
    }

    public double round(double value, int places) {
        if (places < 0) {
            throw new IllegalArgumentException();
        }

        BigDecimal bd = new BigDecimal(value);
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }



    @Override
    public void onEnable() {
        timer.reset();
        this.moveSpeed = MiscellaneousUtil.getBaseMoveSpeed();
        speed = 1;
        this.stage = 2;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        mc.timer.timerSpeed = 1.0F;
        mc.thePlayer.speedInAir = 0.02F;
        timer.reset();
        this.moveSpeed = MiscellaneousUtil.getBaseMoveSpeed();
        speed = 1;
        this.stage = 2;
        super.onDisable();
    }
}
