package me.remixclient.client.modules.movement.speed;

import me.satisfactory.base.events.EventTick;
import pw.stamina.causam.scan.method.model.Subscriber;
import me.remixclient.client.modules.movement.Speed;
import me.satisfactory.base.Base;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Mode;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class Mineman extends Mode<Speed> {
    public Mineman(Speed parent) {
        super(parent, "Mineman");
    }

    @Override
    public void onDisable() {
        mc.thePlayer.setSpeed(0);
        super.onDisable();
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate event) {
        if (!Base.INSTANCE.getModuleManager().getModByName("Flight").isEnabled()) {
            if ((mc.thePlayer.moveForward != 0 || mc.thePlayer.moveStrafing != 0) && mc.thePlayer.onGround) {
                mc.thePlayer.setSpeed(1.4);
                mc.timer.timerSpeed = 0.3f;
            } else {
                mc.thePlayer.setSpeed(0);
                mc.timer.timerSpeed = 1f;
            }
        }
    }
}