package me.remixclient.client.modules.movement;

import pw.stamina.causam.scan.method.model.Subscriber;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.util.BlockPos;
import org.lwjgl.input.Keyboard;

/**
 * @author Mees
 * @since 18/06/2017
 */

public class NoSlowDown extends Module {
    public NoSlowDown() {
        super("NoSlowDown", Keyboard.KEY_NONE, Category.MOVE);
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate event) {
        if (mc.thePlayer.isMoving() && mc.thePlayer.isUsingItem()) {
            mc.thePlayer.sendQueue.addToSendQueue(new C08PacketPlayerBlockPlacement(new BlockPos(0, 0, 0), 255, mc.thePlayer.inventory.getCurrentItem(), 0.0F, 0.0F, 0.0F));
        }
    }
}
