package me.remixclient.client.modules.movement;

import me.remixclient.client.modules.movement.longjump.*;
import me.satisfactory.base.Base;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import me.satisfactory.base.setting.Setting;
import net.minecraft.potion.Potion;
import org.lwjgl.input.Keyboard;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;

/**
 * @author Mees
 * @since 18/06/2017
 */

public class Longjump extends Module {
    public Longjump() {
        super("Longjump", Keyboard.KEY_NONE, Category.MOVE);
        ArrayList<String> options = new ArrayList<>();
        options.add("NCP");
        options.add("Guardian");
        options.add("Hypixel");
        options.add("Cubecraft");
        options.add("Mineplex");
        this.addSetting(new Setting("LongjumpMode", this, "NCP", options));
        this.addMode(new NCP(this));
        this.addMode(new Guardian(this));
        this.addMode(new Hypixel(this));
        this.addMode(new Cubecraft(this));
        this.addMode(new Mineplex(this));
    }

    public  double round(double value, int places) {
        if (places < 0) {
            throw new IllegalArgumentException();
        }

        BigDecimal bd = new BigDecimal(value);
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }


}
