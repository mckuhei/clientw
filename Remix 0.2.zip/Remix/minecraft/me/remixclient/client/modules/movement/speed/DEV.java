package me.remixclient.client.modules.movement.speed;

import java.util.List;

import me.remixclient.client.modules.movement.Speed;
import me.satisfactory.base.Base;
import me.satisfactory.base.events.EventMotion;
import me.satisfactory.base.events.EventMove;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Mode;
import me.satisfactory.base.utils.Helper;
import me.satisfactory.base.utils.MiscellaneousUtil;
import me.satisfactory.base.utils.timer.TimerUtil;
import net.minecraft.util.MovementInput;
import optifine.MathUtils;
import pw.stamina.causam.scan.method.model.Subscriber;

public class DEV extends Mode<Speed> {
    public double moveSpeed;
    private int stage = 1;
    private double lastDist;
    public DEV(Speed parent) {
        super(parent, "DEV");
    }
    @Override
    public void onEnable() {
        if (mc.thePlayer != null) {
            this.moveSpeed = MiscellaneousUtil.getBaseMoveSpeed();
        }

        this.lastDist = 0.0;
        stage = 1;
        super.onEnable();
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate e) {
        double xDist = this.mc.thePlayer.posX - this.mc.thePlayer.prevPosX;
        double zDist = this.mc.thePlayer.posZ - this.mc.thePlayer.prevPosZ;
        this.lastDist = Math.sqrt(xDist * xDist + zDist * zDist);
    }


    @Subscriber
    public void eventMove(EventMove event) {
        if (!Base.INSTANCE.getModuleManager().getModByName("Flight").isEnabled()) {
        	
            List collidingList = mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer, mc.thePlayer.boundingBox.offset(0.0, -0.56, 0.0));

            if (collidingList.size() > 0 && MathUtils.roundToPlace(mc.thePlayer.posY - (int) mc.thePlayer.posY, 3) == MathUtils.roundToPlace(0.55, 3)) {
                // event.setY(mc.thePlayer.motionY = -0.4);
            }

            if (stage == 1 && mc.thePlayer.isCollidedVertically && (mc.thePlayer.moveForward != 0.0f || mc.thePlayer.moveStrafing != 0.0f)) {

            } else if (stage == 2 && (mc.thePlayer.onGround||mc.thePlayer.isCollidedVertically) && (mc.thePlayer.moveForward != 0.0f || mc.thePlayer.moveStrafing != 0.0f)) {
              //  mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY - 0.001, mc.thePlayer.posZ);
            	mc.thePlayer.posY -= 0.1;
                event.setY(mc.thePlayer.motionY = 0.399475);
                mc.timer.timerSpeed = 1.0f;
                this.moveSpeed *= 2.1499999;
            } else if (stage == 3) {
                mc.timer.timerSpeed = 1f;
                final double difference = 0.72 * (this.lastDist - MiscellaneousUtil.getBaseMoveSpeed());
                this.moveSpeed = this.lastDist - difference;
            } else {
                mc.timer.timerSpeed = 1f;
              //  collidingList = mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer, mc.thePlayer.boundingBox.offset(0.0, mc.thePlayer.motionY, 0.0));

                if ((collidingList.size() > 0 || mc.thePlayer.isCollidedVertically) && stage > 0) {
                    if (2 * MiscellaneousUtil.getBaseMoveSpeed() - 0.01 > this.moveSpeed) {
                        stage = 1;
                    } else {
                        stage = ((mc.thePlayer.moveForward != 0.0f || mc.thePlayer.moveStrafing != 0.0f) ? 1 : 0);
                    }
                }

                this.moveSpeed = this.lastDist - this.lastDist / 159.0;
            }

            if (stage > 8) {
                // this.moveSpeed = 1 * this.parent.getBaseMoveSpeed() - 0.01;
            }

            //this.moveSpeed = Math.max(this.moveSpeed, this.parent.getBaseMoveSpeed());
            if (stage > 0) {
                setMoveSpeed(event, this.moveSpeed);
            }

            if (mc.thePlayer.moveForward != 0.0f || mc.thePlayer.moveStrafing != 0.0f) {
                ++stage;
            }
        }
    }

    public void setMoveSpeed(EventMove event, double speed) {
        MovementInput movementInput = mc.thePlayer.movementInput;
        double forward = movementInput.moveForward;
        double strafe = movementInput.moveStrafe;
        float yaw = mc.thePlayer.rotationYaw;

        if ((forward == 0.0D) && (strafe == 0.0D)) {
            event.x = 0.0D;
            event.x = 0.0D;
        } else {
            if (forward != 0.0D) {
                if (strafe > 0.0D) {
                    yaw += (forward > 0.0D ? -45 : 45);
                } else if (strafe < 0.0D) {
                    yaw += (forward > 0.0D ? 45 : -45);
                }

                strafe = 0.0D;

                if (forward > 0.0D) {
                    forward = 1.0D;
                } else if (forward < 0.0D) {
                    forward = -1.0D;
                }
            }

            event.x = (forward * speed * Math.cos(Math.toRadians(yaw + 90.0F)) + strafe * speed * Math.sin(Math.toRadians(yaw + 90.0F)));
            event.z = (forward * speed * Math.sin(Math.toRadians(yaw + 90.0F)) - strafe * speed * Math.cos(Math.toRadians(yaw + 90.0F)));
        }
    }
}
