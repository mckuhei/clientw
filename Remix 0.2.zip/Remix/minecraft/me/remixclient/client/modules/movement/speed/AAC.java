package me.remixclient.client.modules.movement.speed;

import me.remixclient.client.modules.movement.Speed;
import me.satisfactory.base.module.Mode;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class AAC extends Mode<Speed> {
    public AAC(Speed parent) {
        super(parent, "AAC");
    }
}
