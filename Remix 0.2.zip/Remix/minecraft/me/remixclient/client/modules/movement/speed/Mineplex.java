package me.remixclient.client.modules.movement.speed;

import me.satisfactory.base.events.EventTick;
import me.satisfactory.base.utils.MiscellaneousUtil;
import pw.stamina.causam.scan.method.model.Subscriber;
import me.remixclient.client.modules.movement.Speed;
import me.satisfactory.base.Base;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Mode;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class Mineplex extends Mode<Speed> {
    public Mineplex(Speed parent) {
        super(parent, "Mineplex");
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate event) {
        if (!Base.INSTANCE.getModuleManager().getModByName("Flight").isEnabled()) {
            if (mc.thePlayer.moveForward != 0 || mc.thePlayer.moveStrafing != 0) {
            	
                if (mc.thePlayer.onGround) {
                	mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.1, mc.thePlayer.posZ);
                	mc.thePlayer.posY -= 0.1;
                    //mc.thePlayer.motionY = 0.4;
                    //mc.thePlayer.setSpeed(MiscellaneousUtil.getBaseMoveSpeed() * 1.6);
                } 
            } else {
                mc.thePlayer.motionX = 0;
                mc.thePlayer.motionZ = 0;
            }
        }
    }
}
