package me.remixclient.client.modules.movement.longjump;

import me.satisfactory.base.utils.Helper;
import me.satisfactory.base.utils.MiscellaneousUtil;
import pw.stamina.causam.scan.method.model.Subscriber;
import me.remixclient.client.modules.movement.Longjump;
import me.satisfactory.base.Base;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Mode;
import net.minecraft.block.Block;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C00PacketKeepAlive;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C07PacketPlayerDigging.Action;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.network.play.client.C18PacketSpectate;
import net.minecraft.potion.Potion;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

import java.math.BigDecimal;
import java.math.RoundingMode;
import me.satisfactory.base.events.EventTick;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class Mineplex extends Mode<Longjump> {
public int counter = 0;
    public Mineplex(Longjump parent) {
        super(parent, "Mineplex");
    }



    @Subscriber
    public void onUpdate(EventPlayerUpdate event) {
    	counter++;
        if(counter ==1) {
        	mc.thePlayer.sendQueue.addToSendQueue((Packet) new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.STOP_SLEEPING));
        }
        else  if(counter ==2) {
        	mc.thePlayer.sendQueue.addToSendQueue(new C00PacketKeepAlive());
        	counter = 0;
        }
        if ((mc.thePlayer.moveForward != 0.0f || mc.thePlayer.moveStrafing != 0.0f)) {
            mc.thePlayer.motionY += 0.03;
            this.setMoveSpeed(0.3, (float) 2);

            if (mc.thePlayer.isCollidedVertically) {
                mc.thePlayer.motionY = 0.39968;

                
            }
        }
        
    }
    public static void setMoveSpeed(double moveSpeed, float forw) {
        float forward = Helper.player().movementInput.moveForward;
        float strafe = Helper.player().movementInput.moveStrafe;
        float yaw = Helper.player().rotationYaw;
        if (forward == 0.0 && strafe == 0.0) {
            Helper.player().motionX = 0.0;
            Helper.player().motionZ = 0.0;
        }
        else {
            if (forward != 0.0) {
                if (strafe > 0.0f) {
                    yaw += ((forward > 0.0) ? -45 : 45);
                }
                else if (strafe < 0.0f) {
                    yaw += ((forward > 0.0) ? 45 : -45);
                }
                strafe = 0.0f;
                if (forward > 0.0f) {
                    forward = forw * 0.5f;
                }
                else if (forward < 0.0f) {
                    forward = -forw * 0.5f;
                }
            }
            final double xDist = forward * moveSpeed * Math.cos(Math.toRadians(yaw + 90.0f)) + strafe * moveSpeed * Math.sin(Math.toRadians(yaw + 90.0f));
            final double zDist = forward * moveSpeed * Math.sin(Math.toRadians(yaw + 90.0f)) - strafe * moveSpeed * Math.cos(Math.toRadians(yaw + 90.0f));
           Helper.player().motionX = xDist;
           Helper.player().motionZ = zDist;
        }
    }

}
