package me.remixclient.client.modules.movement.speed;

import me.satisfactory.base.utils.MiscellaneousUtil;
import pw.stamina.causam.scan.method.model.Subscriber;
import me.remixclient.client.modules.movement.Speed;
import me.satisfactory.base.Base;
import me.satisfactory.base.events.EventMove;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Mode;
import net.minecraft.util.MovementInput;

import java.util.List;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class Lowhop extends Mode<Speed> {
    private  int stage;
    private double moveSpeed;
    private double lastDist;

    public Lowhop(Speed parent) {
        super(parent, "Lowhop");
    }

    @Override
    public void onEnable() {
        if (mc.thePlayer != null) {
            this.moveSpeed = MiscellaneousUtil.getBaseMoveSpeed();
        }

        this.lastDist = 0.0D;
        stage = 1;
        super.onEnable();
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate e) {
        double xDist = this.mc.thePlayer.posX - this.mc.thePlayer.prevPosX;
        double zDist = this.mc.thePlayer.posZ - this.mc.thePlayer.prevPosZ;
        this.lastDist = Math.sqrt(xDist * xDist + zDist * zDist);
    }

    @Subscriber
    public void eventMove(EventMove event) {
        if (!Base.INSTANCE.getModuleManager().getModByName("Flight").isEnabled()) {
            if ((mc.thePlayer.moveForward == 0.0F) && (mc.thePlayer.moveStrafing == 0.0F)) {
                this.moveSpeed = MiscellaneousUtil.getBaseMoveSpeed();

            }
            if (this.parent.round(mc.thePlayer.posY - (int) mc.thePlayer.posY, 3) == this.parent.round(0.4D, 3)) {
                event.y = 0.31D;
                mc.timer.timerSpeed = 2;
            } else if (this.parent.round(mc.thePlayer.posY - (int) mc.thePlayer.posY, 3) == this.parent.round(0.71D, 3)) {
                event.y = 0.04D;
            } else if (this.parent.round(mc.thePlayer.posY - (int) mc.thePlayer.posY, 3) == this.parent.round(0.75D, 3)) {
                event.y = -0.2D;
            }
            List collidingList = this.mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer, mc.thePlayer.boundingBox.offset(0.0D, -0.56D, 0.0D));
            if ((collidingList.size() > 0) && (this.parent.round(mc.thePlayer.posY - (int) mc.thePlayer.posY, 3) == this.parent.round(0.55D, 3))) {
                event.y = -0.13D;
            }
            if ((stage == 1) && (mc.thePlayer.isCollidedVertically) && ((mc.thePlayer.moveForward != 0.0F) || (mc.thePlayer.moveStrafing != 0.0F))) {
                this.moveSpeed = (1.89D * MiscellaneousUtil.getBaseMoveSpeed() + 0.05D);
            }
            if ((stage == 2) && (mc.thePlayer.isCollidedVertically) && ((mc.thePlayer.moveForward != 0.0F) || (mc.thePlayer.moveStrafing != 0.0F))) {
                event.y = 0.4D;
                mc.timer.timerSpeed = 3;
                this.moveSpeed = MiscellaneousUtil.getBaseMoveSpeed() * 1.8;
            } else if (stage == 3) {
                mc.timer.timerSpeed = 1;
                double difference = 0.66D * (this.lastDist -MiscellaneousUtil.getBaseMoveSpeed());
                this.moveSpeed = (this.lastDist - difference);
            } else {
                collidingList = this.mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer, mc.thePlayer.boundingBox.offset(0.0D, mc.thePlayer.motionY, 0.0D));
                if (((collidingList.size() > 0) || (mc.thePlayer.isCollidedVertically)) && (stage > 0)) {
                    if (1.35D * MiscellaneousUtil.getBaseMoveSpeed() - 0.1D > this.moveSpeed) {
                        stage = 0;
                    } else {
                        stage = (mc.thePlayer.moveForward != 0.0F) || (mc.thePlayer.moveStrafing != 0.0F) ? 1 : 0;
                    }
                }
                this.moveSpeed = (this.lastDist - this.lastDist / 159.0D);
            }
            if (stage > 8) {
                this.moveSpeed = MiscellaneousUtil.getBaseMoveSpeed();
            }
            this.moveSpeed = Math.max(this.moveSpeed, MiscellaneousUtil.getBaseMoveSpeed());
            if (stage > 0) {
                setMoveSpeed(event, this.moveSpeed);
            }
            if ((mc.thePlayer.moveForward != 0.0F) || (mc.thePlayer.moveStrafing != 0.0F)) {
                stage += 1;
            }
        }
    }

    public void setMoveSpeed(EventMove event, double speed) {
        MovementInput movementInput = mc.thePlayer.movementInput;
        double forward = movementInput.moveForward;
        double strafe = movementInput.moveStrafe;
        float yaw = mc.thePlayer.rotationYaw;
        if ((forward == 0.0D) && (strafe == 0.0D)) {
            event.x = 0.0D;
            event.x = 0.0D;
        } else {
            if (forward != 0.0D) {
                if (strafe > 0.0D) {
                    yaw += (forward > 0.0D ? -45 : 45);
                } else if (strafe < 0.0D) {
                    yaw += (forward > 0.0D ? 45 : -45);
                }
                strafe = 0.0D;
                if (forward > 0.0D) {
                    forward = 1.0D;
                } else if (forward < 0.0D) {
                    forward = -1.0D;
                }
            }
            event.x = (forward * speed * Math.cos(Math.toRadians(yaw + 90.0F)) + strafe * speed * Math.sin(Math.toRadians(yaw + 90.0F)));
            event.z = (forward * speed * Math.sin(Math.toRadians(yaw + 90.0F)) - strafe * speed * Math.cos(Math.toRadians(yaw + 90.0F)));
        }
    }
}
