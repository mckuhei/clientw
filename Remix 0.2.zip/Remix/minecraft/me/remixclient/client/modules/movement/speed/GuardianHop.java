package me.remixclient.client.modules.movement.speed;

import me.satisfactory.base.events.EventTick;
import pw.stamina.causam.scan.method.model.Subscriber;
import me.remixclient.client.modules.movement.Speed;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Mode;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class GuardianHop extends Mode<Speed> {
    public GuardianHop(Speed parent) {
        super(parent, "GuardianHop");
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate event) {
        if ((mc.gameSettings.keyBindForward.pressed || mc.gameSettings.keyBindBack.pressed || mc.gameSettings.keyBindLeft.pressed || mc.gameSettings.keyBindRight.pressed) && !mc.getMinecraft().gameSettings.keyBindJump.pressed) {
            if ((mc.thePlayer.moveStrafing == 0.0F) && (mc.thePlayer.moveForward == 0.0F)) {
                mc.thePlayer.motionX = 0.0D;
                mc.thePlayer.motionZ = 0.0D;
            }

            if ((mc.thePlayer.onGround) && (mc.thePlayer.isMoving())) {
                mc.thePlayer.setSpeed(1.2000001276837158D);
                mc.thePlayer.motionY = 0.4255D;
            }

            mc.thePlayer.setSpeed((float) Math.sqrt(mc.thePlayer.motionX * mc.thePlayer.motionX + mc.thePlayer.motionZ * mc.thePlayer.motionZ));
        }
    }
}
