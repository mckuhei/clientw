package me.remixclient.client.modules.movement.speed;

import me.satisfactory.base.utils.MiscellaneousUtil;
import pw.stamina.causam.scan.method.model.Subscriber;
import me.remixclient.client.modules.movement.Speed;
import me.satisfactory.base.Base;
import me.satisfactory.base.events.EventMove;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Mode;
import net.minecraft.util.MovementInput;
import me.satisfactory.base.events.EventTick;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class BHop extends Mode<Speed> {
    public double moveSpeed;
    public boolean canStep;
    private int level = 1;
    private double lastDist;
    private double[] values = {0.08D, 0.09316090325960147D, 1.35D, 2.149D, 0.66D};

    public BHop(Speed parent) {
        super(parent, "BHop");
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate e) {
        double xDist = mc.thePlayer.posX - mc.thePlayer.prevPosX;
        double zDist = mc.thePlayer.posZ - mc.thePlayer.prevPosZ;
        this.lastDist = Math.sqrt(xDist * xDist + zDist * zDist);
    }

    @Subscriber
    public void eventMove(EventMove event) {
        if (!Base.INSTANCE.getModuleManager().getModByName("Flight").isEnabled()) {
            if (mc.thePlayer.isSneaking()) {
                return;
            }

            if (mc.thePlayer.onGround) {
                this.level = 2;
            }

            if (this.parent.round(mc.thePlayer.posY - (int) mc.thePlayer.posY, 3) == this.parent.round(0.138D, 3)) {
                mc.thePlayer.motionY -= 0.1D;
                mc.thePlayer.posY -= event.y -= this.values[1];
            }

            if ((this.level != 1) || ((mc.thePlayer.moveForward == 0.0F) && (mc.thePlayer.moveStrafing == 0.0F))) {
                if (this.level == 2) {
                    this.level = 3;

                    if ((mc.thePlayer.moveForward != 0.0F) || (mc.thePlayer.moveStrafing != 0.0F)) {
                        event.y = (mc.thePlayer.motionY = 0.4D);
                        moveSpeed *= this.values[3];
                    }
                } else if (this.level == 3) {
                    this.level = 4;
                    double difference = this.values[4] * (this.lastDist - MiscellaneousUtil.getBaseMoveSpeed());
                    moveSpeed = this.lastDist - difference;
                } else {
                    if ((mc.thePlayer.onGround) && ((mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer, mc.thePlayer.boundingBox.offset(0.0D, mc.thePlayer.motionY, 0.0D)).size() > 0) || (mc.thePlayer.isCollidedVertically))) {
                        this.level = 1;
                    }

                    moveSpeed = this.lastDist - this.lastDist / 159.0D;
                }
            } else {
                this.level = 2;
                moveSpeed = this.values[2] * MiscellaneousUtil.getBaseMoveSpeed();
            }

            moveSpeed = Math.max(moveSpeed, MiscellaneousUtil.getBaseMoveSpeed()) * 0.975D;
            MovementInput movementInput = mc.thePlayer.movementInput;
            float forward = movementInput.moveForward;
            float strafe = movementInput.moveStrafe;
            float yaw = mc.thePlayer.rotationYaw;

            if ((forward == 0.0F) && (strafe == 0.0F)) {
                event.x = 0.0D;
                event.z = 0.0D;
            } else if (forward != 0.0F) {
                if (strafe > 0.0F) {
                    yaw += (forward > 0.0F ? -45 : 45);
                } else if (strafe < 0.0F) {
                    yaw += (forward > 0.0F ? 45 : -45);
                }

                strafe = 0.0F;

                if (forward > 0.0F) {
                    forward = 1.0F;
                } else if (forward < 0.0F) {
                    forward = -1.0F;
                }
            }

            double mx = Math.cos(Math.toRadians(yaw + 90.0F));
            double mz = Math.sin(Math.toRadians(yaw + 90.0F));
            event.x = (forward * moveSpeed * mx + strafe * moveSpeed * mz);
            event.z = (forward * moveSpeed * mz - strafe * moveSpeed * mx);
            canStep = true;
            mc.thePlayer.stepHeight = 0.6F;

            if ((forward == 0.0F) && (strafe == 0.0F)) {
                event.x = 0.0D;
                event.z = 0.0D;
            }
        }
    }
}
