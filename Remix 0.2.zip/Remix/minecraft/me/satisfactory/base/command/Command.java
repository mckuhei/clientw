package me.satisfactory.base.command;

import net.minecraft.client.Minecraft;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */
public class Command {
    protected static Minecraft mc = Minecraft.getMinecraft();
    /**
     * Command's name.
     */
    private String name;
    /**
     * Command's usage.
     */
    private String usage;
    /**
     * Command's prefix.
     */
    private String prefix;

    public Command(String name, String usage) {
        this.name = name;
        this.usage = usage;
    }

    /**
     * Gets the current command name.
     *
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the current command usage.
     *
     * @return usage
     */
    public String getUsage() {
        return usage;
    }

    /**
     * Gets the general command prefix.
     *
     * @return prefix
     */
    public String getPrefix() {
        return prefix;
    }

    /**
     * Changes the command general prefix.
     *
     * @param prefix
     */
    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    /**
     * Executes the command.
     *
     * @param args
     */
    public void execute(String[] args) {
    }
}
