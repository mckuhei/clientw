package me.satisfactory.base.command;

import me.remixclient.client.commands.*;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */
public class CommandManager {
    public final Map<String, Command> commands;

    public CommandManager() {
        this.commands = new HashMap<>();
        /**
         * Commands
         */
        addCommand(new CommandBind());
        addCommand(new CommandConfig());
        addCommand(new CommandFriend());
        addCommand(new CommandHelp());
        addCommand(new CommandMode());
        addCommand(new CommandIRC());
        addCommand(new CommandToggle());
    }

    /**
     * Method to add a command to the current map.
     *
     * @param command
     */
    private void addCommand(Command command) {
        this.commands.put(command.getName(), command);
    }

    /**
     * Gets the selected command by name.
     *
     * @param name command's name
     * @return command
     */
    public Command getCommand(String name) {
        return commands.get(name);
    }
}
