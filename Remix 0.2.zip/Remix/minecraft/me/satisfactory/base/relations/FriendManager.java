package me.satisfactory.base.relations;

import net.minecraft.client.Minecraft;

import java.util.ArrayList;
import java.util.regex.Pattern;

/**
 * @author Mees
 * @since 19/06/2017
 */
public class FriendManager {
    private static final Pattern patternControlCode = Pattern.compile("(?i)\\u00A7[0-9A-FK-OR]");
    public static ArrayList<Friend> friendsList = new ArrayList<>();


    public static void addFriend(String name, String alias) {
        friendsList.add(new Friend(name, alias));
    }

    public static void addFriendNoAlias(String name) {
        friendsList.add(new Friend(name, name));
    }

    public static String getAliasName(String name) {
        String alias = "";

        for (Friend friend : friendsList) {
            if (friend.getName().equalsIgnoreCase(stripControlCodes(name))) {
                alias = friend.getAlias();
                break;
            }
        }

        if ((Minecraft.getMinecraft().thePlayer != null) && (Minecraft.getMinecraft().thePlayer.getGameProfile().getName() == name)) {
            return name;
        }

        return alias;
    }

    public static void removeFriend(String name) {
        for (Friend friend : friendsList) {
            if (friend.getName().equalsIgnoreCase(name)) {
                friendsList.remove(friend);
                break;
            }
        }
    }

    public static String replaceText(String text) {
        for (Friend friend : friendsList) {
            if (text.contains(friend.getName())) {
                text = friend.getAlias();
            }
        }

        return text;
    }

    public static boolean isFriend(String name) {
        boolean isFriend = false;

        for (Friend friend : friendsList) {
            if (friend.getName().equalsIgnoreCase(stripControlCodes(name))) {
                isFriend = true;
                break;
            }
        }

        if (Minecraft.getMinecraft().thePlayer.getGameProfile().getName() == name) {
            isFriend = true;
        }

        return isFriend;
    }

    public static ArrayList<Friend> getFriendsList() {
        return friendsList;
    }

    public static String stripControlCodes(String s) {
        return patternControlCode.matcher(s).replaceAll("");
    }
}