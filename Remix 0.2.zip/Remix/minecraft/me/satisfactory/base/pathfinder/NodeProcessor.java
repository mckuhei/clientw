package me.satisfactory.base.pathfinder;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.util.BlockPos;

import java.util.ArrayList;
import java.util.Collections;

public class NodeProcessor {
    public ArrayList<Node> path = new ArrayList<Node>();
    public ArrayList<Node> triedPaths = new ArrayList<Node>();

    public static Block getBlock(BlockPos pos) {
        return Minecraft.getMinecraft().theWorld.getBlockState(pos).getBlock();
    }

    private ArrayList<Node> getNeighbors(Node node) {
        ArrayList<Node> neighbors = new ArrayList<Node>();
        BlockPos b1 = node.getBlockpos();
        BlockPos b2 = node.getBlockpos();
        b1 = b1.add(1, 1, 1);
        b2 = b2.add(-1, -1, -1);
        neighbors.add(createNode(b1.offsetUp()));
        neighbors.add(createNode(b1.offsetDown()));
        neighbors.add(createNode(b1.offsetEast()));
        neighbors.add(createNode(b1.offsetWest()));
        neighbors.add(createNode(b2.offsetUp()));
        neighbors.add(createNode(b2.offsetDown()));
        neighbors.add(createNode(b2.offsetEast()));
        neighbors.add(createNode(b2.offsetWest()));
        neighbors.add(createNode(b1.offsetNorth()));
        neighbors.add(createNode(b1.offsetSouth()));

        for (BlockPos pos : BlockPos.getAllInBox(b1, b2)) {
            if (pos.equals(node.getBlockpos())) {
                continue;
            }

            if (pos.getX() > node.getBlockpos().getX() && pos.getZ() > node.getBlockpos().getZ()) {
                continue;
            }

            if (pos.getX() < node.getBlockpos().getX() && pos.getZ() < node.getBlockpos().getZ()) {
                continue;
            }

            if (pos.getX() > node.getBlockpos().getX() && pos.getZ() > node.getBlockpos().getZ()) {
                continue;
            }

            if (pos.getX() > node.getBlockpos().getX() && pos.getZ() < node.getBlockpos().getZ()) {
                continue;
            }

            neighbors.add(createNode(pos));
        }

        return neighbors;
    }

    public void getPath(BlockPos start, BlockPos finish) {
        Node startNode = createNode(start);
        Node endNode = createNode(finish);
        ArrayList<Node> openNodes = new ArrayList<Node>();
        ArrayList<Node> closedNodes = new ArrayList<Node>();
        openNodes.clear();
        openNodes.add(startNode);
        int count = 0;

        while (openNodes.size() > 0) {
            Node currentNode = openNodes.get(0);
            //System.out.println(openNodes.size());
            //System.out.println("Size: " + openNodes.size());
            double minFCost = 100000;

            for (int i = 1; i < openNodes.size(); i++) {
                double FCost = openNodes.get(i).getF_Cost(currentNode, endNode);

                if (FCost < minFCost) {
                    minFCost = FCost;
                    currentNode = openNodes.get(i);
                }
            }

            openNodes.clear();
            openNodes.remove(currentNode);
            closedNodes.add(currentNode);
            triedPaths.add(currentNode);

            if (currentNode.getBlockpos().equals(endNode.getBlockpos()))   //path has been found
            {
                endNode.parent = currentNode;
                retracePath(startNode, endNode);
                return;
            }

            for (Node neighbor : getNeighbors(currentNode)) {
                if (isNodeClosed(neighbor, closedNodes)) {
                    continue;
                }

                double hCost = currentNode.getH_Cost(endNode);

                if (hCost >= neighbor.getH_Cost(endNode) || !isNodeClosed(neighbor, openNodes)) {
                    neighbor.parent = currentNode;

                    if (!isNodeClosed(neighbor, openNodes)) {
                        openNodes.add(neighbor);
                    }
                }
            }
        }
    }

    private boolean isNodeClosed(Node node, ArrayList<Node> nodes) {
        for (Node n : nodes) {
            if (n.getBlockpos().equals(node.getBlockpos())) {
                return true;
            }
        }

        return false;
    }

    private void retracePath(Node startNode, Node endNode) {
        ArrayList<Node> path = new ArrayList<Node>();
        Node currentNode = endNode;

        while (!currentNode.equals(startNode)) {
            path.add(currentNode);
            currentNode = currentNode.parent;
        }

        Collections.reverse(path);
        this.path = path;
    }

    public Node createNode(BlockPos pos) {
        return new Node(getBlock(pos).getMaterial() == Material.air && getBlock(pos.offsetUp()).getMaterial() == Material.air && getBlock(pos.offsetUp()).getMaterial() == Material.air, pos);
    }
}
