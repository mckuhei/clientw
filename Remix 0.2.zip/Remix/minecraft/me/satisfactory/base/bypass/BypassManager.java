package me.satisfactory.base.bypass;

import me.satisfactory.base.Base;
import me.satisfactory.base.module.Mode;
import me.satisfactory.base.setting.Setting;
import me.satisfactory.base.utils.file.FileUtils;

import java.io.File;
import java.util.List;

public class BypassManager {


    public static void create() {
        File CoolDir = new File(FileUtils.getConfigDir(), "Configs");

        if (!CoolDir.exists()) {
            CoolDir.mkdir();
        }
    }

    public static void load(String confname) {
        File CoolDir = new File(FileUtils.getConfigDir(), "Configs");

        if (!CoolDir.exists()) {
            CoolDir.mkdir();
        }

        List<String> fileContent = FileUtils.read(FileUtils.getConfigFileConf(confname));

        for (String line : fileContent) {
            try {
                String[] split = line.split(":");
                String name = split[0];
                String value = split[1];
                String whatitis = split[2];

                for (Setting m : Base.INSTANCE.getSettingManager().settings) {
                    if (!name.equalsIgnoreCase(m.getName())) {
                        continue;
                    }

                    if (whatitis.equalsIgnoreCase("Double")) {
                        m.setValDouble(Double.parseDouble(value));
                        // MiscellaneousUtil.addChatMessage(name + " " + value + " double");
                    }

                    if (whatitis.equalsIgnoreCase("String")) {
                        Mode mode = null;

                        try {
                            for (Mode m2 : m.getParentMod().getModes()) {
                                if (!m2.getName().equalsIgnoreCase(value)) {
                                    continue;
                                }

                                mode = m2;
                            }

                            if (mode == null) {
                                continue;
                            }

                            m.getParentMod().setMode(mode);
                        } catch (Exception e10) {
                            e10.printStackTrace();
                        }
                    }

                    if (whatitis.equalsIgnoreCase("Boolean")) {
                        m.setValBoolean(Boolean.valueOf(value));
                        //  MiscellaneousUtil.addChatMessage(name + " " + value + " boolean");
                    }
                }
            } catch (Exception split) {
                System.err.println(split);
            }
        }
    }

    public static File getConfigFile(final String name) {
        final File file = new File(FileUtils.getConfigDir(), String.format("", name));

        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return file;
    }
}
