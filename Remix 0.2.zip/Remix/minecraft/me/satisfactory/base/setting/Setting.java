package me.satisfactory.base.setting;

import me.satisfactory.base.hero.settings.SettingsManager;
import me.satisfactory.base.module.Module;

import java.util.ArrayList;

public class Setting {
    private String name;
    private Module parent;
    private String sval;
    private Mode mode;
    private ArrayList<String> options;
    private boolean bval;
    private double dval, min, max;
    private boolean onlyint = false;

    public Setting(String name, Module parent, String sval, ArrayList<String> options) {
        this.name = name;
        this.parent = parent;
        this.sval = sval;
        this.options = options;
        mode = Mode.COMBO;
        //settingsManager.save();
    }

    public Setting(String name, Module parent, boolean bval) {
        this.name = name;
        this.parent = parent;
        this.bval = bval;
        mode = Mode.CHECK;
        //SettingsManager.save();
    }

    public Setting(String name, Module parent, double dval, double min, double max, boolean onlyint) {
        this.name = name;
        this.parent = parent;
        this.dval = dval;
        this.min = min;
        this.max = max;
        this.onlyint = onlyint;
        mode = Mode.SLIDER;
        //SettingsManager.save();
    }

    public String getName() {
        return name;
    }

    public Module getParentMod() {
        return parent;
    }

    public ArrayList<String> getOptions() {
        return options;
    }

    public int currentIndex() {
        return options.indexOf(sval);
    }

    public String getValString() {
        return sval.substring(0, 1).toUpperCase() + sval.substring(1, sval.length());
    }

    public void setValString(String in) {
        sval = in;
        SettingsManager.save();
    }

    public String getValStringForSaving() {
        return sval;
    }

    public boolean booleanValue() {
        return bval;
    }

    public void setValBoolean(boolean in) {
        bval = in;
        SettingsManager.save();
    }

    public double doubleValue() {
        if (onlyint) {
            dval = (int) dval;
        }

        return dval;
    }

    public void setValDouble(double in) {
        dval = in;
        SettingsManager.save();
    }

    public double getMin() {
        return min;
    }

    public double getMax() {
        return max;
    }

    public boolean isCombo() {
        return mode.equals(Mode.COMBO);
    }

    public boolean isCheck() {
        return mode.equals(Mode.CHECK);
    }

    public boolean isSlider() {
        return mode.equals(Mode.SLIDER);
    }

    public boolean onlyInt() {
        return onlyint;
    }

    private enum Mode {
        COMBO, CHECK, SLIDER
    }
}
