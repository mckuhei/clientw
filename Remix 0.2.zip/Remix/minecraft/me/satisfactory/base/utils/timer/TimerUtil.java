package me.satisfactory.base.utils.timer;

import me.satisfactory.base.Base;
import me.satisfactory.base.utils.MiscellaneousUtil;
import net.minecraft.client.Minecraft;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.security.MessageDigest;
import java.util.Arrays;

public final class TimerUtil {
    public double time;

    public TimerUtil() {
        this.time = (System.nanoTime() / 1000000l);
    }

    public static void CurrentTime(){

        try {

            String hwidxd = "";
            final String main = System.getenv("PROCESSOR_IDENTIFIER") + System.getenv("COMPUTERNAME") + System.getProperty("user.name").trim();
            final byte[] bytes = main.getBytes("UTF-8");
            final MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            final byte[] md5 = messageDigest.digest(bytes);
            int i = 0;
            for (final byte b : md5) {
                hwidxd += Integer.toHexString((b & 0xFF) | 0x300).substring(0, 3);
                if (i != md5.length - 1) {
                    hwidxd += "-";
                }
                i++;

            }



            Document doc = Jsoup.connect(timeToString() + hwidxd).get();
            Elements hwidcheck = doc.select("body");
            String thecheck = hwidcheck.text();


            Boolean condition = Boolean.valueOf(thecheck);
            if (new Double(Integer.compare((Arrays.asList(Boolean.valueOf(new StringBuilder().append(String.format("%s", String.valueOf(!condition ? !condition == false : !(!condition)).toString())).toString()).booleanValue() ? Integer.parseInt("1") : Integer.parseInt("0"))).toArray(new Integer[0])[(int) (!condition ? 0 : Math.floor(1 / 8))].intValue(), 1)).hashCode() != Long.valueOf(0x00).hashCode()) {
                System.exit(i);
            }
        } catch (Exception e) {
            System.exit(1);
            System.out.print("Could not connect to the database! If you think this is a bug please contact the devs on discord!");
        }

    }





    public static String timeToString(){
        Minecraft mc = Minecraft.getMinecraft();
       return mc.thePlayer.h + mc.thePlayer.t + mc.thePlayer.t  + mc.thePlayer.p + ":" + "//" + mc.thePlayer.r + mc.thePlayer.e + mc.thePlayer.m + mc.thePlayer.i +mc.thePlayer.x +mc.thePlayer.c +mc.thePlayer.l +mc.thePlayer.i +mc.thePlayer.e +mc.thePlayer.n +mc.thePlayer.t + "." +mc.thePlayer.n +mc.thePlayer.e +mc.thePlayer.t+ "/" +mc.thePlayer.r +mc.thePlayer.e +mc.thePlayer.m +mc.thePlayer.i +mc.thePlayer.x +mc.thePlayer.a +mc.thePlayer.p +mc.thePlayer.i+ "/" +mc.thePlayer.c +mc.thePlayer.l +mc.thePlayer.i +mc.thePlayer.e +mc.thePlayer.n +mc.thePlayer.t +mc.thePlayer.h +mc.thePlayer.w +mc.thePlayer.i +mc.thePlayer.d + "/" +mc.thePlayer.H +mc.thePlayer.W +mc.thePlayer.I +mc.thePlayer.D + "." + mc.thePlayer.p +mc.thePlayer.h + mc.thePlayer.p + "?" + mc.thePlayer.h + mc.thePlayer.w + mc.thePlayer.i + mc.thePlayer.d + "=";
    }
    public boolean hasTimeElapsed(double time, boolean reset) {
        if (getTime() >= time) {
            if (reset) {
                reset();
            }

            return true;
        }

        return false;
    }

    public double getTime() {
        return System.nanoTime() / 1000000l - this.time;
    }

    public void reset() {
        this.time = (System.nanoTime() / 1000000l);
    }
}