package me.satisfactory.base.utils.items;

import net.minecraft.client.Minecraft;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class ItemUtils {
    public static int getItem(int id2) {
        int index = 9;

        while (index < 45) {
            ItemStack item = Minecraft.getMinecraft().thePlayer.inventoryContainer.getSlot(index).getStack();

            if (item != null && Item.getIdFromItem(item.getItem()) == id2) {
                return index;
            }

            ++index;
        }

        return -1;
    }
}
