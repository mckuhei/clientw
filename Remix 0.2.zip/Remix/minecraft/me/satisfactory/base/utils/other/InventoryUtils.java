package me.satisfactory.base.utils.other;

import net.minecraft.client.Minecraft;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

public class InventoryUtils {
    static Minecraft mc = Minecraft.getMinecraft();


    public static void grabPot() {
        for (int i = 9; i < 36; ++i) {
            ItemStack stack = mc.thePlayer.inventoryContainer.getSlot(i).getStack();

            if (stack != null && isSplashPot(stack)) {
                mc.playerController.windowClick(mc.thePlayer.openContainer.windowId, i, 1,2, mc.thePlayer);
                break;
            }
        }
    }

    public static boolean hotBarHasPots() {
        for (int i = 36; i < 45; ++i) {
            ItemStack stack = mc.thePlayer.inventoryContainer.getSlot(i).getStack();

            if (stack != null && isSplashPot(stack)) {
                return true;
            }
        }

        return false;
    }

    public static  int getPotionFromInventory() {
        int pot = -1;

        for (int i = 1; i < 45; ++i) {
            if (mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                ItemStack is = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
                Item item = is.getItem();

                if (item instanceof ItemPotion) {
                    ItemPotion potion = (ItemPotion) item;

                    if (potion.getEffects(is) != null) {
                        for (PotionEffect effect : potion.getEffects(is)) {
                            if (effect.getPotionID() == Potion.heal.id && ItemPotion.isSplash(is.getItemDamage())) {
                                pot = i;
                            }
                        }
                    }
                }
            }
        }

        return pot;
    }

    public static  boolean isSplashPot(ItemStack stack) {
        if (stack != null && stack.getItem() instanceof ItemPotion) {
            ItemPotion potion = (ItemPotion) stack.getItem();

            if (ItemPotion.isSplash(stack.getItemDamage())) {
                for (Object o : potion.getEffects(stack)) {
                    PotionEffect effect = (PotionEffect) o;

                    if (effect.getPotionID() == Potion.heal.getId()) {
                        return true;
                    }
                }
            }
        }

        return false;
    }
}
