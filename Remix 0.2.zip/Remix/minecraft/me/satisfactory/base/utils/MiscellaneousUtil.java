package me.satisfactory.base.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.potion.Potion;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;
import optifine.MathUtils;

import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class MiscellaneousUtil {

    public static void addChatMessage(String str) {
        Object chat = new ChatComponentText(str);

        if (str != null) {
            Minecraft.getMinecraft().ingameGUI.getChatGUI().printChatMessage((IChatComponent) chat);
        }
    }

    public static void sendInfo(String str) {
        addChatMessage("§2[" + "Remix" + "]: §f" + str);
    }

    public static double random(double min, double max) {
        Random random = new Random();
        return min + (random.nextDouble() * (max - min));
    }

    public static double getBaseMoveSpeed() {
        double baseSpeed = 0.2873D;

        if (Minecraft.getMinecraft().thePlayer.isPotionActive(Potion.moveSpeed)) {
            int amplifier = Minecraft.getMinecraft().thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier();
            baseSpeed *= (1.0D + 0.2D * (amplifier + 1));
        }

        return baseSpeed;
    }
}