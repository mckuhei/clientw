package me.satisfactory.base;
/**
 * creds to vladymyr for the cancer
 */

import me.remixclient.client.font.FontManager;
import me.remixclient.client.irc.IrcManager;
import me.satisfactory.base.bypass.BypassManager;
import me.satisfactory.base.command.CommandManager;
import me.satisfactory.base.gui.GuiBungeeCord;
import me.satisfactory.base.gui.PortscanManager;
import me.satisfactory.base.gui.tabgui.TabGUI;
import me.satisfactory.base.hero.settings.SettingsManager;
import me.satisfactory.base.relations.FriendManager;
import me.satisfactory.base.module.ModuleManager;
import me.satisfactory.base.utils.FontUtils;
import me.satisfactory.base.utils.MiscellaneousUtil;
import me.satisfactory.base.utils.timer.TimerUtil;
import me.tojatta.api.utilities.value.ValueManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.client.shader.ShaderGroup;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.EnumConnectionState;
import net.minecraft.network.Packet;
import net.minecraft.network.handshake.client.C00Handshake;
import net.minecraft.util.ResourceLocation;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.lwjgl.opengl.GL11;
import pw.stamina.causam.EventBus;
import pw.stamina.causam.event.EventEmitter;
import pw.stamina.causam.publish.Publisher;
import pw.stamina.causam.registry.SetBasedSubscriptionRegistry;
import pw.stamina.causam.registry.SubscriptionRegistry;
import pw.stamina.causam.select.CachingSubscriptionSelectorServiceDecorator;
import pw.stamina.causam.select.SubscriptionSelectorService;

import java.awt.*;
import java.io.File;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.UUID;

public enum Base {
    INSTANCE;

    public static FontUtils clientFont = new FontUtils("Calibri", Font.BOLD, 18);
    static Minecraft mc = Minecraft.getMinecraft();
    private final ValueManager valueManager = new ValueManager();
    private final ResourceLocation background = new ResourceLocation("remix/mainmenu.png"),
            singleleplayer = new ResourceLocation("remix/singleplayer.png"),
            settings = new ResourceLocation("remix/settings.png"),
            multiplayer = new ResourceLocation("remix/multiplayer.png"),
            exit = new ResourceLocation("remix/exit.png"),
            altmanager = new ResourceLocation("remix/altmanager.png");
   // public static char[] test = new char[]{'h'+'t'+'t'+'p'+':'+'/'+'/'+'r'+'e'+'m'+'i'+'x'+'c'+'l'+'i'+'e'+'n'+'t'+'.'+'n'+'e'+'t'+'/'+'r'+'e'+'m'+'i'+'x'+'a'+'p'+'i'+'/'+'c'+'l'+'i'+'e'+'n'+'t'+'h'+'w'+'i'+'d'+'/'+'H'+'W'+'I'+'D'+'.'+'p'+'h'+'p'+'?'+'h'+'w'+'i'+'d'+'='};

    public int MainColor;
    public IrcManager ircManager;
    private String CLIENT_NAME = "Remix";
    private String CLIENT_VERSION = "0.2";
    private ModuleManager moduleManager;
    private File raidriarDir;
    private SettingsManager setmgr;
    private EventBus eventManager;
    private CommandManager commandManager;
    private FriendManager friendManager;
    private PortscanManager portscanManager;
    private FontManager fontManager = new FontManager();
  /*  private BypassManager bypassManager;*/

    Base() {
        /**
         * Prints that the client is loading.
         */
        System.out.println("Loading " + getCLIENT_NAME() + "...");
        /**
         * Current MS.
         * @returns milliseconds
         */
       /* bypassManager = new BypassManager();*/
        eventManager = createEventBus();
        long time = System.currentTimeMillis();
        setmgr = new SettingsManager();


        /**
         * Sets the raidriar
         */
        raidriarDir = new File(Minecraft.getMinecraft().mcDataDir, getCLIENT_NAME());
        /**
         * Initializes the commandManager.
         */
        commandManager = new CommandManager();

        /**
         * Initializes the TabGUI
         */
        TabGUI.init();
        /**
         * Prints the time ms that the client spent.
         */
        /*bypassManager.create();*/
        fontManager.loadFonts();
        //ircManager = new IrcManager(Minecraft.getMinecraft().getSession().getUsername());
        //ircManager.connect();
        // ^ it takes 7 - 10 seconds to connect to the irc
        //TimerUtil.CurrentTime();

        System.out.println("Loaded " + CLIENT_NAME + " - Time spent " + (System.currentTimeMillis() - time) + "ms.");
    }

    private static EventBus createEventBus() {

        SubscriptionSelectorService selectorService =
                CachingSubscriptionSelectorServiceDecorator.standard(SubscriptionSelectorService.simple());
        SubscriptionRegistry registry = SetBasedSubscriptionRegistry.concurrentHash(selectorService);

        Publisher publisher = Publisher.immediate();
        EventEmitter emitter = EventEmitter.standard(registry, publisher);

        return EventBus.standard(registry, emitter);
    }

    public static int getRainbow(double d, int offset) {
        float hue = (float) ((System.currentTimeMillis() + offset) % d);
        hue /= d;
        return Color.getHSBColor(hue, 1.0F, 1.0F).getRGB();
    }
    public static String a(char[] chars) {
        StringBuilder sb = new StringBuilder();
        for (char c : chars) {
            sb.append(c);
        }
        return sb.toString();
    }

    public static boolean handleOutPacket(Packet packet, EnumConnectionState packetState) {
        if (GuiBungeeCord.mc.isUUIDHack && packet instanceof C00Handshake) {
            ;

            if (((C00Handshake) packet).getRequestedState() == EnumConnectionState.LOGIN) {
                ((C00Handshake) packet).setIp(((C00Handshake) packet).getIp() + "\u0000" + mc.getFakeIp() + "\u0000" + UUID.nameUUIDFromBytes(new StringBuilder().append("OfflinePlayer:").append(mc.getFakeNick()).toString().getBytes()).toString().replace("-", ""));
            }

            System.out.println(((C00Handshake) packet).getIp());
        }

        if (packetState != EnumConnectionState.PLAY) {
            return true;
        }

        return true;
    }

    public static double getRandom(float a, float b) {
        float d = Math.abs(a - b) % 360.0F;

        if (d > 180.0F) {
            d = 360.0F - d;
        }

        return d;
    }

    public static String CharShita(char[] chars) {
        StringBuilder sb = new StringBuilder();

        for (char c : chars) {
            sb.append(c);
        }

        return sb.toString();
    }

    public SettingsManager getSettingManager() {
        return setmgr;
    }

    public void setup() {
        /**
         * Initializes the moduleManager.
         */
        moduleManager = new ModuleManager();
        ModuleManager.load();
        SettingsManager.load();
        //setmgr = new SettingsManager();
    }


    public ResourceLocation getMainMenu() {
        return background;
    }

    public ResourceLocation getSinglePlayer() {
        return singleleplayer;
    }

    public ResourceLocation getSettings() {
        return settings;
    }

    public ResourceLocation getMultiPlayer() {
        return multiplayer;
    }

    public ResourceLocation getAlt() {
        return altmanager;
    }

    public ResourceLocation getExit() {
        return exit;
    }

    public ModuleManager getModuleManager() {
        return moduleManager;
    }

    public CommandManager getCommandManager() {
        return commandManager;
    }

    public FriendManager getFriendManager() {
        return friendManager;
    }

   /* public BypassManager getBypassManager() {
        return bypassManager;
    }*/

    public ValueManager getValueManager() {
        return valueManager;
    }

    public File getRaidriarDir() {
        return raidriarDir;
    }

    public String getCLIENT_NAME() {
        return CLIENT_NAME;
    }

    public EventBus getEventManager() {
        return eventManager;
    }

    public int GetMainColor() {
        if (getSettingManager().getSettingByName("Rainbow").booleanValue()) {
            return MainColor = getRainbow(20000 - (getSettingManager().getSettingByName("RainbowSpeed").doubleValue() * 1000), 1);
        } else {
            return MainColor = new Color(0, 230, 60).getRGB();
        }
    }

    public void addIRCMessage(String IRCMessage) {
        String ChatPrefix = "§2[§2IRC" + "§2] §f";
        MiscellaneousUtil.sendInfo(ChatPrefix + IRCMessage);
    }

    public IrcManager getIRC() {
        return ircManager;
    }

    public PortscanManager getPortscanManager() {
        // TODO Auto-generated method stub
        return portscanManager;
    }

    public FontManager getFontManager() {
        return fontManager;
    }
}
