package me.satisfactory.base.gui.tabgui;

import me.remixclient.client.modules.render.HUD;
import me.satisfactory.base.Base;
import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import me.satisfactory.base.utils.FontUtils;
import me.satisfactory.base.utils.MiscellaneousUtil;
import me.satisfactory.base.utils.other.BlurUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.util.ResourceLocation;

import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Mees
 * @since 22/06/2017
 */
public class TabGUI {
    public static int baseCategoryWidth;
    private static int baseCategoryHeight;
    private static int baseModWidth;
    private static Section section = Section.CATEGORY;
    private static int categoryTab = 0;
    private static int modTab = 0;
    private static int categoryPosition = 15;
    private static int categoryTargetPosition = 14;
    private static int modPosition = 15;
    private static int modTargetPosition = 14;
    private static boolean transitionQuickly;
    private static long lastUpdateTime;


    public static void init() {
        int highestWidth = 0;

        for (Category category : Category.values()) {
            if (category != Category.HIDDEN) {
                String name = (category.name());
                int stringWidth = getStringWidth(name) + 5;
                highestWidth = Math.max(stringWidth, highestWidth);
            }
        }

        baseCategoryWidth = highestWidth + 18;
        baseCategoryHeight = (Category.values().length - 1) * 15 - 7;
    }

    public static void renderString(String string, int x, int y, int color) {
        Minecraft.getMinecraft().fontRendererObj.drawString(string, (float) x, (float) y - 1, color);
    }

    public static int getStringWidth(String string) {
        return Minecraft.getMinecraft().fontRendererObj.getStringWidth(string);
    }

    public static void render(FontUtils fu) {
        //MiscellaneousUtil.addChatMessage(""+categoryTab);
        updateBars();
        int extraheight = Base.INSTANCE.getSettingManager().getSettingByName("Logo").booleanValue() ? 55 : 0;
        //BlurUtils.blurArea(1, 13 + extraheight, 1 + baseCategoryWidth, 16 + extraheight + 16,100);

        GuiIngame.drawRoundedRect(1, 13 + extraheight, 2 + baseCategoryWidth, 16 + baseCategoryHeight+ extraheight,3, -1610612736);
        GuiIngame.drawRect(1 +2.5f, categoryPosition - 1+ extraheight + 3, 1 + 4, categoryPosition + 15+ extraheight -3, Base.INSTANCE.GetMainColor());
        GuiIngame.drawRoundedRect(2f, categoryPosition + extraheight + 3 - 3, 2 + baseCategoryWidth - 1, categoryPosition + 15+ extraheight -3 + 2, 3, 0x10FFFFFF);
        int yPos = Minecraft.getMinecraft().fontRendererObj.FONT_HEIGHT + 7;
        Gui.drawImage(new ResourceLocation("remix/CSGOIcons/COMBAT.png"),baseCategoryWidth - 12, 17 + extraheight, 9, 9);
        Gui.drawImage(new ResourceLocation("remix/CSGOIcons/EXPLOITS.png"),baseCategoryWidth - 14, 30 + extraheight, 12, 12);
        Gui.drawImage(new ResourceLocation("remix/CSGOIcons/MOVE.png"),baseCategoryWidth - 15, 43 + extraheight, 13, 13);
        Gui.drawImage(new ResourceLocation("remix/CSGOIcons/PLAYER.png"),baseCategoryWidth - 12, 59 + extraheight, 9, 9);
        Gui.drawImage(new ResourceLocation("remix/CSGOIcons/WORLD.png"),baseCategoryWidth - 12, 73 + extraheight, 10, 10);
        Gui.drawImage(new ResourceLocation("remix/CSGOIcons/RENDER.png"),baseCategoryWidth - 12, 86 + extraheight, 11, 11);
        for (Category category : Category.values()) {
            if (category != Category.HIDDEN) {
                String name1 = (category.name().toLowerCase());
                String name = name1.substring(0, 1).toUpperCase() + name1.substring(1);
                if (category.equals(Category.values()[categoryTab])) {

                        fu.drawString(name, (int) 5.0 + 3, yPos + extraheight, -1);

                }
                else{
                    fu.drawString(name, (int) 5.0, yPos + extraheight, -1);

                }
                yPos += 14;
            }
        }
        if (section == Section.MODS) {
           // BlurUtils.blurArea(baseCategoryWidth + 4, categoryPosition - 1+ extraheight, baseModWidth,  (getModsInCategory(Category.values()[categoryTab]).size() * 14) + 1+ extraheight, 100);
            GuiIngame.drawRoundedRect(baseCategoryWidth + 4, categoryPosition - 1+ extraheight, baseCategoryWidth + baseModWidth + 10, categoryPosition + getModsInCategory(Category.values()[categoryTab]).size() * 14 + 1+ extraheight,3, -1610612736);
            GuiIngame.drawRect(baseCategoryWidth + 3 + 4, modPosition - 1+ extraheight + 3, baseCategoryWidth + 3 + 4 + 1, modPosition + 15+ extraheight-3, Base.INSTANCE.GetMainColor());

            //  MiscellaneousUtil.sendInfo((baseCategoryWidth + 3 + 4) - (baseCategoryWidth + 3 + 4 + 1) + " ");
            yPos = categoryPosition + 3;

            for (int i = 0; i < getModsInCategory(Category.values()[categoryTab]).size(); i++) {
                Module mod = getModsInCategory(Category.values()[categoryTab]).get(i);
                String name = mod.getName();
                if (getModsInCategory(Category.values()[categoryTab]).get(modTab).equals(mod)) {
                    fu.drawString(name, (int) (baseCategoryWidth + 14.0), yPos - 1 + extraheight, mod.isEnabled() ? -1 : -4210753);
                }
                else{
                    fu.drawString(name, (int) (baseCategoryWidth + 9.0), yPos - 1 + extraheight, mod.isEnabled() ? -1 : -4210753);

                }
                yPos += 14;
            }
        }
    }

    public static void keyPress(int key) {
        if (section == Section.CATEGORY) {
            switch (key) {
                case Keyboard.KEY_RIGHT:
                    int highestWidth = 0;

                    for (Module module : getModsInCategory(Category.values()[categoryTab])) {
                        String name = (module.getName().toLowerCase());
                        int stringWidth = Minecraft.getMinecraft().fontRendererObj.getStringWidth(name);
                        highestWidth = Math.max(stringWidth, highestWidth);
                    }

                    baseModWidth = highestWidth + 6;
                    modTargetPosition = modPosition = categoryTargetPosition;
                    modTab = 0;
                    section = Section.MODS;
                    break;

                case Keyboard.KEY_DOWN:
                    categoryTab += 1;
                    categoryTargetPosition += 14;

                    if (categoryTab <= Category.values().length - 2) {
                        break;
                    }

                    transitionQuickly = true;
                    categoryTargetPosition = 14;
                    categoryTab = 0;
                    break;

                case Keyboard.KEY_UP:
                    categoryTab -= 1;
                    categoryTargetPosition -= 14;

                    if (categoryTab >= 0) {
                        break;
                    }

                    transitionQuickly = true;
                    categoryTargetPosition = 14 + (Category.values().length - 2) * 14;
                    categoryTab = Category.values().length - 2;
            }
        } else if (section == Section.MODS) {
            switch (key) {
                case Keyboard.KEY_LEFT:
                    section = Section.CATEGORY;
                    break;

                case Keyboard.KEY_RIGHT:
                    Module mod = getModsInCategory(Category.values()[categoryTab]).get(modTab);
                    mod.toggle();
                    break;

                case Keyboard.KEY_DOWN:
                    modTab += 1;
                    modTargetPosition += 14;

                    if (modTab > getModsInCategory(Category.values()[categoryTab]).size() - 1) {
                        transitionQuickly = true;
                        modTargetPosition = categoryTargetPosition;
                        modTab = 0;
                    }

                    break;

                case Keyboard.KEY_UP:
                    modTab -= 1;
                    modTargetPosition -= 14;

                    if (modTab < 0) {
                        transitionQuickly = true;
                        modTargetPosition = categoryTargetPosition
                                + (getModsInCategory(Category.values()[categoryTab]).size() - 1) * 14;
                        modTab = getModsInCategory(Category.values()[categoryTab]).size() - 1;
                    }

                    break;
            }
        }
    }

    public static void updateBars() {
        long timeDifference = System.currentTimeMillis() - lastUpdateTime;
        lastUpdateTime = System.currentTimeMillis();
        int increment = transitionQuickly ? 100 : 20;
        increment = Math.max(1, Math.round(increment * timeDifference / 100L));

        if (categoryPosition < categoryTargetPosition) {
            categoryPosition += increment;

            if (categoryPosition >= categoryTargetPosition) {
                categoryPosition = categoryTargetPosition;
                transitionQuickly = false;
            }
        } else if (categoryPosition > categoryTargetPosition) {
            categoryPosition -= increment;

            if (categoryPosition <= categoryTargetPosition) {
                categoryPosition = categoryTargetPosition;
                transitionQuickly = false;
            }
        }

        if (modPosition < modTargetPosition) {
            modPosition += increment;

            if (modPosition >= modTargetPosition) {
                modPosition = modTargetPosition;
                transitionQuickly = false;
            }
        } else if (modPosition > modTargetPosition) {
            modPosition -= increment;

            if (modPosition <= modTargetPosition) {
                modPosition = modTargetPosition;
                transitionQuickly = false;
            }
        }
    }

    public static List<Module> getModsInCategory(Category Category) {
        List<Module> modList = new ArrayList<Module>();

        for (Module mod : getSortedModuleArray()) {
            if (mod.getCategory() == Category && Category != me.satisfactory.base.module.Category.HIDDEN) {
                modList.add(mod);
            }
        }

        return modList;
    }

    public static List<Module> getSortedModuleArray() {
        final List<Module> list = new ArrayList<Module>();

        for (final Module mod : Base.INSTANCE.getModuleManager().modules.values()) {
            list.add(mod);
        }

        list.sort((m1, m2) ->
        {
            final String s1 = m1.getName();
            final String s2 = m2.getName();
            final int cmp = getStringWidth(s2)
                    - getStringWidth(s1);
            return (cmp != 0) ? cmp : s2.compareTo(s1);
        });
        return list;
    }

    public static int baseCategoryHeight() {
        return baseCategoryHeight;
    }

    public static int baseCategoryWidth() {
        return baseCategoryWidth;
    }

    private enum Section {
        CATEGORY("CATEGORY", 0), MODS("MODS", 1);

        Section(String s, int n) {
        }
    }
}