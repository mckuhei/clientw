package me.satisfactory.base.gui;

import net.minecraft.client.gui.*;
import net.minecraft.client.multiplayer.ServerData;

import java.awt.*;

public class GuiServerFinder
        extends GuiScreen {
    private GuiServers gui;
    private String renderString;
    private String status;
    private String serverspinged;
    private GuiTextField field_1;

    public GuiServerFinder(GuiServers gui) {
        this.gui = gui;
        ServerFinderHelper.initOrStop();
        this.updateString("");
        this.updateStatus(false);
        this.serverspinged = "0";
    }

    static /* synthetic */ void access$0(GuiServerFinder guiServers_Scanner, String string) {
        guiServers_Scanner.renderString = string;
    }

    public void initGui() {
        this.field_1 = new GuiTextField(100, GuiServerFinder.mc.fontRendererObj, width / 2 - 50, height / 2 - 25, 100, 20);
        this.field_1.setText("ServerIp");
        this.field_1.setFocused(true);
        this.buttonList.add((Object) new GuiButton(1, width / 2 - 45, height / 2 + 45, 40, 20, "\u00a72Scan"));
        this.buttonList.add((Object) new GuiButton(0, width / 2 - 20, height / 2 + 70, 40, 20, "\u00a71Back"));
        this.buttonList.add((Object) new GuiButton(3, width / 2 + 5, height / 2 + 45, 40, 20, "\u00a7cStop"));
        super.initGui();
    }

    public void updateScreen() {
        if (ServerFinderHelper.isScanning()) {
            this.serverspinged = String.valueOf((int) ServerFinderHelper.ipsScanned);
            this.updateStatus(true);
        }

        if (ServerFinderHelper.isScannComplet()) {
            this.updateStatus(false);
            int i = 0;

            while (i != ServerFinderHelper.getScannedIps().size()) {
                ServerData s = (ServerData) ServerFinderHelper.getScannedIps().get(i);
                GuiMultiplayer.savedServerList.servers.add(new ServerData("\u00a7bServer #" + (i + 1) + " \u00a78| \u00a7c" + s.serverIP + "\u00a7r", s.serverIP));
                ++i;
            }

            GuiMultiplayer.savedServerList.saveServerList();
            GuiMultiplayer.savedServerList.loadServerList();
            mc.displayGuiScreen((GuiScreen) GuiServers.gui);
            GuiMultiplayer.refreshServerList();
        }

        super.updateScreen();
    }

    protected void actionPerformed(GuiButton button) {
        switch (button.id) {
            case 3: {
                ServerFinderHelper.ips.clear();
                int i = 0;

                while (i != ServerFinderHelper.getScannedIps().size()) {
                    ServerData s = (ServerData) ServerFinderHelper.getScannedIps().get(i);
                    GuiMultiplayer.savedServerList.servers.add(new ServerData("\u00a7bServer #" + (i + 1) + " \u00a78| \u00a7c" + s.serverIP + "\u00a7r", s.serverIP));
                    ++i;
                }

                ServerFinderHelper.initOrStop();
                GuiMultiplayer.savedServerList.saveServerList();
                GuiMultiplayer.savedServerList.loadServerList();
                mc.displayGuiScreen((GuiScreen) GuiServers.gui);
                GuiMultiplayer.refreshServerList();
                break;
            }

            case 1: {
                if (this.field_1.getText().trim().isEmpty()) {
                    this.updateString("\u00a7cPlease enter an IP!");
                    this.updateStatus(false);
                } else if (ServerFinderHelper.start((String) this.field_1.getText().trim())) {
                    this.updateString("Started");
                    this.updateStatus(true);
                } else {
                    this.updateString("\u00a7cInvalid IP/Domain!");
                    this.updateStatus(false);
                }

                this.serverspinged = "0";
                break;
            }

            case 0: {
                ServerFinderHelper.ips.clear();
                int i = 0;

                while (i != ServerFinderHelper.getScannedIps().size()) {
                    ServerData s = (ServerData) ServerFinderHelper.getScannedIps().get(i);
                    GuiMultiplayer.savedServerList.servers.add(new ServerData("\u00a7bServer #" + (i + 1) + " \u00a78| \u00a7c" + s.serverIP + "\u00a7r", s.serverIP));
                    ++i;
                }

                ServerFinderHelper.initOrStop();
                GuiMultiplayer.savedServerList.saveServerList();
                GuiMultiplayer.savedServerList.loadServerList();
                mc.displayGuiScreen((GuiScreen) this.gui);
                GuiMultiplayer.refreshServerList();
                break;
            }
        }

        super.actionPerformed(button);
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawDefaultBackground();
        this.field_1.drawTextBox();
        GuiServerFinder.drawCenteredString((FontRenderer) GuiServerFinder.mc.fontRendererObj, (String) ("Working: " + ServerFinderHelper.ipsWorking), (int) (width / 2), (int) (height / 2 - 80), (int) Color.GREEN.getRGB());
        GuiServerFinder.drawCenteredString((FontRenderer) GuiServerFinder.mc.fontRendererObj, (String) ("Pinged: " + this.serverspinged), (int) (width / 2), (int) (height / 2 - 70), (int) Color.GREEN.getRGB());
        GuiServerFinder.drawCenteredString((FontRenderer) GuiServerFinder.mc.fontRendererObj, (String) ("Status: " + this.status), (int) (width / 2), (int) (height / 2 - 60), (int) Color.GREEN.getRGB());
        GuiServerFinder.drawCenteredString((FontRenderer) GuiServerFinder.mc.fontRendererObj, (String) this.renderString, (int) (width / 2), (int) (height / 2 - 50), (int) Color.GREEN.getRGB());
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        this.field_1.mouseClicked(mouseX, mouseY, mouseButton);
        super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    protected void keyTyped(char typedChar, int keyCode) {
        this.field_1.textboxKeyTyped(typedChar, keyCode);
        super.keyTyped(typedChar, keyCode);
    }

    public void updateStatus(boolean online) {
        this.status = online ? "\u00a7aOnline" : "\u00a7cOffline";
    }

    public void updateString(String s) {
        this.renderString = s;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(2000);
                    GuiServerFinder.access$0(GuiServerFinder.this, "");
                } catch (InterruptedException interruptedException) {
                    // empty catch block
                }
            }
        }).start();
    }
}
