package me.satisfactory.base.gui.Buttons;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;

import java.awt.*;

public class Checkbox
        extends GuiScreen {
    private int x;
    private int y;
    private int width;
    private int height;
    private boolean value;

    public Checkbox(int x, int y, int width, int height, boolean value) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.value = value;
    }

    public void valueChanged(boolean value) {
    }

    public void drawScreen(Color color) {
        GuiScreen.drawOutline(color.getRGB(), this.x, this.y, this.width + this.x, this.height + this.y);

        if (this.value) {
            Gui.drawRect(this.x, this.y, this.width + this.x, this.height + this.y - 1, Color.GREEN.getRGB());
        }
    }

    public void mouseClicked(int mouseX, int mouseY) {
        boolean hovered;
        boolean bl = hovered = mouseX >= this.x && mouseY >= this.y && mouseX < this.x + this.width && mouseY < this.y + this.height;

        if (hovered) {
            this.value = !this.value;
            this.valueChanged(this.value);
        }
    }

    public void drawBoxString(String string, Color color) {
        Checkbox.drawCenteredString(Checkbox.mc.fontRendererObj, string, this.x - this.width - Checkbox.mc.fontRendererObj.getStringWidth(string) / 2, this.y, color.getRGB());
    }

    public boolean isChecked() {
        return this.value;
    }

    public void setChecked(boolean value) {
        this.value = value;
    }
}
