package me.satisfactory.base.gui;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.concurrent.*;

public class PortscanManager {
    public static ArrayList<Integer> ports = new ArrayList<>();
    static int openPorts = 0;
    public boolean isChecking = false;
    ;
    public boolean AlwaysTrue = true;
    ExecutorService es;
    private Integer Scanned_Ports = Integer.valueOf(0);

    public PortscanManager() {
        this.Scanned_Ports = 0;
    }

    public void onStop() {
        isChecking = false;

        try {
            this.es.shutdownNow();
        } catch (Exception e) {
        }
    }

    public String GetInfo() {
        return "Scanned ports: " + this.Scanned_Ports + "/65535!";
    }

    public String GetName() {
        return "Portscan";
    }

    public Future<Boolean> portIsOpen(ExecutorService es2, final String ip2, final int port, final int timeout) {
        return es2.submit(new Callable<Boolean>() {
            @Override
            public Boolean call() {
                try {
                    Socket socket = new Socket();
                    socket.connect(new InetSocketAddress(ip2, port), timeout);
                    socket.close();
                    System.out.println("Discovered open port: " + port);
                    Object object = ports;

                    synchronized (object) {
                        ports.add(port);
                    }

                    object = PortscanManager.this.Scanned_Ports;

                    synchronized (object) {
                        Integer n = PortscanManager.this.Scanned_Ports;
                        Integer n2 = PortscanManager.this.Scanned_Ports = PortscanManager.this.Scanned_Ports + 1;
                    }

                    return true;
                } catch (Exception ex) {
                    synchronized (PortscanManager.this.Scanned_Ports) {
                        Integer localInteger1 = PortscanManager.this.Scanned_Ports;
                        Integer localInteger2 = PortscanManager.this.Scanned_Ports = Integer.valueOf(PortscanManager.this.Scanned_Ports.intValue() + 1);
                    }
                }

                return Boolean.valueOf(false);
            }
        });
    }

    public void Portscan(String ServerIP, int startport, int endport, int timeoutt, int botamount) {
        openPorts = 0;
        ports.clear();
        this.es = Executors.newFixedThreadPool(botamount);
        String serverIP = ServerIP;
        String ip2 = serverIP.split(":")[0];
        int timeout = timeoutt;
        ArrayList<Future<Boolean>> futures = new ArrayList<Future<Boolean>>();

        for (int port = startport; port <= endport; ++port) {
            futures.add(this.portIsOpen(this.es, ip2, port, 2000));
        }

        this.es.shutdown();

        for (Future f2 : futures) {
            try {
                isChecking = true;

                if (!((Boolean) f2.get()).booleanValue()) {
                    continue;
                }

                ++openPorts;
            } catch (InterruptedException e) {
                isChecking = false;
                e.printStackTrace();
            } catch (ExecutionException e2) {
                isChecking = false;
                e2.printStackTrace();
            }
        }

        System.out.println("There are " + openPorts + " open ports on host " + ip2 + " (probed with a timeout of " + 2000 + "ms)");
    }
}