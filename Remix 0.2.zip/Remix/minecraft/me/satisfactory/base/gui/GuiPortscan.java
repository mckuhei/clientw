package me.satisfactory.base.gui;

import me.satisfactory.base.Base;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.multiplayer.GuiConnecting;
import net.minecraft.client.multiplayer.ServerAddress;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Keyboard;

import java.net.InetAddress;

public class GuiPortscan extends GuiScreen {
    private GuiScreen before;
    private GuiTextField emailField;
    private GuiTextField SPORT;
    private GuiTextField EPORT;
    private String status = "Waiting";
    private String serverIP;

    public GuiPortscan(GuiScreen before) {
        this.before = before;
    }

    @Override
    public void initGui() {
        Keyboard.enableRepeatEvents(true);
        GuiButton crackBtn = new GuiButton(0, this.width / 2 - 100, this.height / 2 + 22, 200, 20, "Scan!");
        this.buttonList.add(crackBtn);
        this.buttonList.add(new GuiButton(1, this.width / 2 - 100, this.height / 2 + 44, 200, 20, "Back"));
        emailField = new GuiTextField(2, this.fontRendererObj, this.width / 2 - 100, this.height / 2 - 70, 200, 20);
        emailField.setMaxStringLength(254);
        emailField.setFocused(true);
        SPORT = new GuiTextField(33, this.fontRendererObj, this.width / 2 - 100, this.height / 2 - 70 + 52, 98, 20);
        SPORT.setMaxStringLength(5);
        SPORT.setText("25500");
        EPORT = new GuiTextField(44, this.fontRendererObj, this.width / 2 - 100 + 102, this.height / 2 - 70 + 52, 98,
                20);
        EPORT.setMaxStringLength(5);
        EPORT.setText("26000");
    }

    @Override
    protected void actionPerformed(GuiButton button) {
        int id = button.id;

        if (button.enabled) {
            if (id == 0) {
                status = "Scanning";
                PortscanManager.ports.clear();
                serverIP = emailField.getText();
                String ip2 = serverIP.split(":")[0];

                try {
                    ServerData p_i1181_3_ = new ServerData("", ip2);
                    ;
                    InetAddress inetaddress = InetAddress.getByName(ip2);
                    ServerAddress serveraddress = ServerAddress.func_78860_a(p_i1181_3_.serverIP);
                    Base.INSTANCE.getPortscanManager().Portscan(serveraddress.getIP(), Integer.parseInt(SPORT.getText()), Integer.parseInt(EPORT.getText()), 500, 250);

                    if (PortscanManager.ports != null) {
                        if (!PortscanManager.ports.isEmpty() && mc.currentScreen == this) {
                            for (int i = 0; i < PortscanManager.ports.size(); i++) {
                                mc.displayGuiScreen(new GuiConnecting(this, mc, inetaddress.getHostAddress(), Base.INSTANCE.getPortscanManager().ports.get(i)));
                            }
                        }
                    } else {
                    }
                } catch (Exception e) {
                    System.err.print(e);
                }

                status = "Done Scanning!";
                super.actionPerformed(button);
                return;
            }

            if (id == 1) {
                this.mc.displayGuiScreen(before);
            }

            if (id == 2) {
                Base.INSTANCE.getPortscanManager().onStop();
                Base.INSTANCE.getPortscanManager().isChecking = false;
                super.actionPerformed(button);
                return;
            }
        }

        super.actionPerformed(button);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        GlStateManager.scale(4, 4, 1);
        GlStateManager.scale(0.5, 0.5, 1);
        drawCenteredString(fontRendererObj, "PortScan", this.width / 2 / 2, (this.height / 2 - 100 - 25) / 2, 0xffffffff);
        GlStateManager.scale(0.5, 0.5, 1);
        drawString(fontRendererObj, "Status: " + status, this.width - fontRendererObj.getStringWidth("Status: " + status) - 10, (this.height / 100) + 10, 0xffffffff);
        drawCenteredString(fontRendererObj, "§cTries every Port of the a Server IP.", this.width / 2 / 1, (this.height / 2 - 100) / 1, 0xffffffff);
        drawString(fontRendererObj, "§7Server IP:", this.width / 2 - 100, (this.height / 2 - 11) - 73 / 1, 0xffffffff);
        drawString(fontRendererObj, "§7Port range:", this.width / 2 - 100, (this.height / 2 - 11) - 20 / 1, 0xffffffff);
        emailField.drawTextBox();
        SPORT.drawTextBox();
        EPORT.drawTextBox();
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) {
        super.keyTyped(typedChar, keyCode);
        emailField.textboxKeyTyped(typedChar, keyCode);
        SPORT.textboxKeyTyped(typedChar, keyCode);
        EPORT.textboxKeyTyped(typedChar, keyCode);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        emailField.mouseClicked(mouseX, mouseY, mouseButton);
        SPORT.mouseClicked(mouseX, mouseY, mouseButton);
        EPORT.mouseClicked(mouseX, mouseY, mouseButton);
        super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    @Override
    public void onGuiClosed() {
        Keyboard.enableRepeatEvents(false);
        super.onGuiClosed();
    }
}
