package me.satisfactory.base.gui;

import me.satisfactory.base.gui.Buttons.Checkbox;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.util.StringUtils;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.util.ArrayList;

public class GuiServers
        extends GuiScreen {
    public static GuiMultiplayer gui;
    private Checkbox box_1;
    private Checkbox box_2;
    private Checkbox box_3;
    private Checkbox box_4;
    private GuiTextField field_1;
    private String renderString = "";

    public GuiServers(GuiMultiplayer gui) {
        GuiServers.gui = gui;
    }

    public static void copyString(String toCopy) {
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(toCopy), null);
    }

    @Override
    public void initGui() {
        this.field_1 = new GuiTextField(100, GuiServers.mc.fontRendererObj, width / 2 + 15, height / 2 - 100, 105, 10);
        this.box_1 = new Checkbox(width / 2 - 25, height / 2 - 100, 10, 10, false);
        this.box_2 = new Checkbox(width / 2 - 25, height / 2 - 80, 10, 10, false);
        this.box_3 = new Checkbox(width / 2 - 25, height / 2 - 60, 10, 10, false);
        this.box_4 = new Checkbox(width / 2 - 25, height / 2 - 40, 10, 10, false);
        this.buttonList.add(new GuiButton(1, width / 2 - 100, height / 2 - 10, 60, 20, "Remove"));
        this.buttonList.add(new GuiButton(4, width / 2 + 25, height / 2 - 80, 85, 20, "Find Player"));
        this.buttonList.add(new GuiButton(5, width / 2 + 25, height / 2, 85, 20, "Copy"));
        this.buttonList.add(new GuiButton(2, width / 2 - 50, height / 2 + 80, 100, 20, "Back"));
        this.buttonList.add(new GuiButton(3, width / 2 - 50, height / 2 + 55, 100, 20, "Portscan"));
        this.buttonList.add(new GuiButton(6, width / 2 - 50, height / 2 + 30, 100, 20, "ServerScanner"));
        super.initGui();
    }

    protected void actionPerformed(GuiButton button) {
        switch (button.id) {
            case 6: {
                mc.displayGuiScreen(new GuiServerFinder(this));
                break;
            }

            case 5: {
                copyString(this.renderString);
                break;
            }

            case 4: {
                if (this.field_1.getText().trim().isEmpty()) {
                    return;
                }

                boolean hasFound = false;

                for (ServerData sd : GuiServers.gui.savedServerList.servers) {
                    try {
                        String[] players;
                        String[] arrstring = players = sd.playerList.split("\n");
                        int n = arrstring.length;
                        int n2 = 0;

                        while (n2 < n) {
                            String s = arrstring[n2];

                            if (s.equalsIgnoreCase(this.field_1.getText().trim())) {
                                hasFound = true;
                                this.renderString = sd.serverIP;
                            }

                            ++n2;
                        }
                    } catch (Exception players) {
                        // empty catch block
                    }
                }

                if (hasFound) {
                    break;
                }

                this.renderString = "\u00a7cNicht gefunden!";
                break;
            }

            case 1: {
                ArrayList<ServerData> filterdServers = new ArrayList<ServerData>();

                for (ServerData data : gui.savedServerList.servers) {
                    boolean mayAdd = true;

                    if (this.box_1.isChecked() && data.pingToServer <= 0) {
                        mayAdd = false;
                    }

                    if (this.box_2.isChecked() && data.version != 47) {
                        mayAdd = false;
                    }

                    try {
                        if (this.box_3.isChecked() && data.populationInfo.split("/").length == 2 && Integer.valueOf(StringUtils.stripControlCodes(data.populationInfo.split("/")[0])) <= 0) {
                            mayAdd = false;
                        }
                    } catch (Exception exception) {
                        // empty catch block
                    }

                    if (this.box_4.isChecked()) {
                        mayAdd = false;
                    }

                    if (!mayAdd) {
                        continue;
                    }

                    filterdServers.add(data);
                }

                GuiServers.gui.savedServerList.servers.clear();
                int i = 0;

                while (i != filterdServers.size()) {
                    ServerData d = (ServerData) filterdServers.get(i);
                    d.serverName = "\u00a7bServer #" + (i + 1) + " \u00a78| \u00a7c" + d.serverIP + "\u00a7r";
                    GuiServers.gui.savedServerList.servers.add(d);
                    ++i;
                }

                GuiServers.gui.savedServerList.saveServerList();
                GuiServers.gui.savedServerList.loadServerList();
                mc.displayGuiScreen(gui);
                gui.refreshServerList();
                break;
            }

            case 2: {
                mc.displayGuiScreen(gui);
                break;
            }

            case 3: {
                mc.displayGuiScreen(new GuiPortscan(this));
            }
        }

        super.actionPerformed(button);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawDefaultBackground();
        this.box_1.drawBoxString("No Connection", Color.green);
        this.box_2.drawBoxString("Wrong version", Color.green);
        this.box_3.drawBoxString("No Players", Color.green);
        this.box_4.drawBoxString("All", Color.green);
        this.box_1.drawScreen(Color.black);
        this.box_2.drawScreen(Color.black);
        this.box_3.drawScreen(Color.black);
        this.box_4.drawScreen(Color.black);
        GuiServers.drawOutline(Color.black.getRGB(), width / 2 - 130, height / 2 - 110, width / 2 - 5, height / 2 + 20);
        GuiServers.drawOutline(Color.black.getRGB(), width / 2 + 5, height / 2 - 110, width / 2 + 130, height / 2 + 20);
        GuiServers.drawCenteredString(GuiServers.mc.fontRendererObj, this.renderString, width / 2 + 70, height / 2 - 20, Color.green.getRGB());
        this.field_1.drawTextBox();
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        this.box_1.mouseClicked(mouseX, mouseY);
        this.box_2.mouseClicked(mouseX, mouseY);
        this.box_3.mouseClicked(mouseX, mouseY);
        this.box_4.mouseClicked(mouseX, mouseY);
        this.field_1.mouseClicked(mouseX, mouseY, mouseButton);
        super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) {
        this.field_1.textboxKeyTyped(typedChar, keyCode);
        super.keyTyped(typedChar, keyCode);
    }
}
