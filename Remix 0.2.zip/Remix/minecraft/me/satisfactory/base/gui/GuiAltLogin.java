package me.satisfactory.base.gui;

import com.mojang.authlib.Agent;
import com.mojang.authlib.UserAuthentication;
import com.mojang.authlib.exceptions.AuthenticationException;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import me.satisfactory.base.utils.FontUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.*;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Session;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.net.Proxy;

public class GuiAltLogin extends GuiScreen {
    public static GuiTextField theName;
    public static GuiPasswordField thePassword;
    public static GuiTextField theCombo;
    public static String loginstats = "Waiting...";
    public FontUtils fontRenderer = new FontUtils("Arial", Font.PLAIN, 23);
    private GuiScreen prevMenu;

    public GuiAltLogin(GuiScreen parent) {
        this.prevMenu = parent;
    }

    public static boolean login(String email, String password) throws AuthenticationException {
        login(email, password, Proxy.NO_PROXY);
        return true;
    }

    public static void login(String email, String password, Proxy proxy) throws AuthenticationException {
        YggdrasilAuthenticationService authService = new YggdrasilAuthenticationService(proxy, "");
        UserAuthentication auth = authService.createUserAuthentication(Agent.MINECRAFT);
        auth.setUsername(email);
        auth.setPassword(password);
        auth.logIn();
        Minecraft.getMinecraft().session = new Session(auth.getSelectedProfile().getName(),
                auth.getSelectedProfile().getId().toString(), auth.getAuthenticatedToken(), "mojang");
    }

    public static void changeName(String newName) {
        if (newName.equals("NoHaxJusttrivia") || newName.equals("Robin146") || newName.equals("triviaClient")
                || newName.equals("triviaDev")) {
            newName = "succ";
        }

        Minecraft.getMinecraft().session = new Session(newName, "", "", "mojang");
    }

    public static void drawRect(double d, double e, double g, double h, int col1) {
        float f = (col1 >> 24 & 0xFF) / 255.0F;
        float f1 = (col1 >> 16 & 0xFF) / 255.0F;
        float f2 = (col1 >> 8 & 0xFF) / 255.0F;
        float f3 = (col1 & 0xFF) / 255.0F;
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glPushMatrix();
        GL11.glColor4f(f1, f2, f3, f);
        GL11.glBegin(GL11.GL_QUADS);
        GL11.glVertex2d(g, e);
        GL11.glVertex2d(d, e);
        GL11.glVertex2d(d, h);
        GL11.glVertex2d(g, h);
        GL11.glEnd();
        GL11.glPopMatrix();
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
    }

    @Override
    public void initGui() {
        this.buttonList.clear();
        theName = new GuiTextField(0, Minecraft.getMinecraft().fontRendererObj, width / 2 - 100, height / 4, 200, 20);
        theName.setMaxStringLength(254);
        thePassword = new GuiPasswordField(0, this.fontRendererObj, width / 2 - 100, height / 4 + 50, 200, 20);
        thePassword.setMaxStringLength(254);
        theCombo = new GuiTextField(0, Minecraft.getMinecraft().fontRendererObj, width / 2 - 100, height / 4 + 100, 200, 20);
        theCombo.setMaxStringLength(254);
        this.buttonList.add(new GuiButtonDark(0, width / 2 - 101, height / 4 + 156, 202, 20, "Login"));
        this.buttonList.add(new GuiButtonDark(2, width / 2 - 101, height / 4 + 176, 202, 20, "Clipboard login"));
        this.buttonList.add(new GuiButtonDark(1, width / 2 - 101, height / 4 + 196, 202, 20, I18n.format("Back", new Object[0])));
        Keyboard.enableRepeatEvents((boolean) true);
    }

    @Override
    protected void actionPerformed(GuiButton button) {
        if (button.id == 0) {
            if ((thePassword.getText() == "" || thePassword.getText() == " ") && !theCombo.getText().contains(":") && theCombo.getText().equals("")) {
                System.out.println(thePassword.getText() + " <--- Password");

                try {
                    changeName(theName.getText());
                    loginstats = "Successfully logged in!";
                } catch (Exception E) {
                    loginstats = "Failed logging in!";
                }
            }

            if (theCombo.getText().contains(":")) {
                try {
                    String s = theCombo.getText();
                    String nm = s.split(":")[0];
                    String pw = s.split(":")[1];
                    login(nm, pw);
                    loginstats = "Successfully logged in!";
                } catch (Exception e) {
                    loginstats = "Failed logged in!";
                }
            }

            if (thePassword.getText() != "" && theName.getText() != "") {
                try {
                    login(theName.getText(), thePassword.getText());
                    loginstats = "Successfully logged in!";
                } catch (Exception e) {
                    loginstats = "Failed logged in!";
                }
            }
        }

        if (button.id == 1) {
            Minecraft.getMinecraft().displayGuiScreen(prevMenu);
        }

        if (button.id == 2) {
            try {
                Toolkit toolkit = Toolkit.getDefaultToolkit();
                Clipboard clipboard = toolkit.getSystemClipboard();
                String result = (String) clipboard.getData(DataFlavor.stringFlavor);
                String nm = result.split(":")[0];
                String pw = result.split(":")[1];
                login(nm, pw);
                loginstats = "Successfully logged in!";
            } catch (Exception e) {
                System.err.println(e);
                loginstats = "Failed logged in!";
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) {
        super.keyTyped(typedChar, keyCode);
        theName.textboxKeyTyped(typedChar, keyCode);
        thePassword.textboxKeyTyped(typedChar, keyCode);
        theCombo.textboxKeyTyped(typedChar, keyCode);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        theName.mouseClicked(mouseX, mouseY, mouseButton);
        thePassword.mouseClicked(mouseX, mouseY, mouseButton);
        theCombo.mouseClicked(mouseX, mouseY, mouseButton);
    }

    @Override
    public void updateScreen() {
        theName.updateCursorCounter();
        thePassword.updateCursorCounter();
        theCombo.updateCursorCounter();
        super.updateScreen();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.mc.getTextureManager().bindTexture(new ResourceLocation("remix/mainmenu.png"));
        this.drawTexturedModalRect(0, 0, 0, 0, width, height);
        ScaledResolution sr = new ScaledResolution(this.mc, this.mc.displayWidth, this.mc.displayHeight);
        drawScaledCustomSizeModalRect(0, 0, 0.0f, 0.0f, width, height, width, height, width, height);
        drawRect(width / 2 - 120, 0.0, width / 2 + 120, height, Integer.MIN_VALUE);
        theName.drawTextBox();
        thePassword.drawTextBox();
        theCombo.drawTextBox();
        Minecraft.getMinecraft().fontRendererObj.drawString("Username", sr.getScaledWidth() / 2 - 25, height / 4 - 17, 0x0ffffff);
        Minecraft.getMinecraft().fontRendererObj.drawString("Password", sr.getScaledWidth() / 2 - 25, height / 4 + 34, 0x0ffffff);
        Minecraft.getMinecraft().fontRendererObj.drawString("Email:Password", sr.getScaledWidth() / 2 - 35, height / 4 + 84, 0x0ffffff);
        int var3 = this.height / 4 + 48;
        String STats = mc.session.getToken().equals("") ? "Cracked" : "Premium";
        String SessiongText = "" + this.mc.session.getUsername() + " (" + STats + ")";
        fontRenderer.drawString(SessiongText, width / 500, height / 500, 0xFFFFFFFF);
        int meme;

        if (loginstats.equals("Successfully logged in!")) {
            meme = Color.green.getRGB();
        } else {
            meme = Color.red.getRGB();
        }

        fontRenderer.drawString(loginstats, width - fontRenderer.getWidth(loginstats) - 3, height / 500, meme);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }
}
