package me.satisfactory.base.module;

import net.minecraft.client.Minecraft;

/**
 * @author Zarzel.
 * @since 21/06/2017
 */

public class Mode<T> {
    public Minecraft mc = Minecraft.getMinecraft();
    protected T parent;
    private String name;

    public Mode(T parent, String name) {
        this.parent = parent;
        this.name = name;
    }

    public void onEnable() {
        if (mc.thePlayer == null || mc.theWorld == null) {
            return;
        }
    }

    public void onDisable() {
        if (mc.thePlayer == null || mc.theWorld == null) {
            return;
        }
    }

    public T getParent() {
        return parent;
    }

    public String getName() {
        return name;
    }
}
