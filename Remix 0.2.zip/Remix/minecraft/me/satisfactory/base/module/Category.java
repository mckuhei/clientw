package me.satisfactory.base.module;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */
public enum Category {
    COMBAT, EXPLOITS, MOVE, PLAYER, WORLD, RENDER, HIDDEN
}
