package me.satisfactory.base.module;


import me.satisfactory.base.Base;
import me.satisfactory.base.hero.settings.SettingsManager;
import me.satisfactory.base.setting.Setting;
import net.minecraft.client.Minecraft;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */
public class Module {
    protected Minecraft mc = Minecraft.getMinecraft();
    private String name;
    private int keybind;
    private Category category;
    private boolean state, enabled;

    private List<Mode> modes;
    private Mode mode;

    public Module(String name, int keybind, Category category) {
        this.name = name;
        this.keybind = keybind;
        this.category = category;
        this.modes = new ArrayList();
        Base.INSTANCE.getValueManager().register(this);
    }

    public void addSetting(Setting setting) {
        Base.INSTANCE.getSettingManager().rSetting(setting);
    }

    public Setting findSettingByName(String name) {
        return Base.INSTANCE.getSettingManager().getSettingByName(name);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getKeybind() {
        return keybind;
    }

    public void setKeybind(int keybind) {
        this.keybind = keybind;
        ModuleManager.save();
    }

    public Category getCategory() {
        return category;
    }

    public void toggle() {
        state = !state;
        this.onToggle();

        if (state) {
            if (this.mode != null) {
                Base.INSTANCE.getEventManager().register(this.mode);
                this.mode.onEnable();
            }

            this.onEnable();
            this.enabled = true;
        } else {
            if (mode != null) {
                Base.INSTANCE.getEventManager().unregister(mode);
                mode.onDisable();
            }

            this.onDisable();
            this.enabled = false;
        }

        ModuleManager.save();
    }

    public void addMode(Mode mode) {
        modes.add(mode);

        if (this.mode == null) {
            this.mode = mode;
        }
    }

    public Mode getMode() {
        return mode;
    }

    public void setMode(Mode themode) {
        if (this.mode != null) {
            Base.INSTANCE.getEventManager().unregister(mode);
            mode.onDisable();
        }

        if (enabled) {
            Base.INSTANCE.getEventManager().register(themode);
            themode.onEnable();
        }

        this.mode = themode;
        SettingsManager.save();
    }

    public List<Mode> getModes() {
        return modes;
    }

    public void onToggle() {
    }

    public void onEnable() {
        Base.INSTANCE.getEventManager().register(this);
    }

    public void onDisable() {
        Base.INSTANCE.getEventManager().unregister(this);

        if (mc.thePlayer == null || mc.theWorld == null) {
            return;
        }
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;

        if (enabled) {
            this.onEnable();
        } else {
            this.onDisable();
        }
    }
}
