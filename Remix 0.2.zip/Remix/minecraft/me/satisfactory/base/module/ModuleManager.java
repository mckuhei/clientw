package me.satisfactory.base.module;

import me.remixclient.client.modules.combat.*;
import me.remixclient.client.modules.exploit.ServerCrasher;
import me.remixclient.client.modules.movement.*;
import me.remixclient.client.modules.player.*;
import me.remixclient.client.modules.render.*;
import me.remixclient.client.modules.world.AntiBot;
import me.remixclient.client.modules.world.Fucker;
import me.remixclient.client.modules.world.Resolver;
import me.remixclient.client.modules.world.Scaffold;
import me.remixclient.client.tabs.TabExploits;
import me.satisfactory.base.Base;
import me.satisfactory.base.gui.tabgui.TabGUI;
import me.satisfactory.base.setting.Setting;
import me.satisfactory.base.utils.file.FileUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */
public class ModuleManager {
    private static final File MODULE_DIR;

    public static Map<String, Module> modules;

    static {
        MODULE_DIR = FileUtils.getConfigFile("Mods");
        ModuleManager.modules = new HashMap<String, Module>();
    }

    public ModuleManager() {
        this.modules = new HashMap<>();
        /**
         * Combat modules.
         */
        new TabExploits();
        addModule(new Resolver());
        addModule(new AntiBot());
        addModule(new AntiCopyright());
        addModule(new AntiKnockback());
        addModule(new AutoArmor());
        addModule(new AutoPotion());
        addModule(new BloodGFX());
        addModule(new ChestStealer());
        addModule(new ClickGui());
        addModule(new CreativeDrop());
        addModule(new Criticals());
        addModule(new CSGOGui());
        addModule(new Dab());
        addModule(new ESP());
        addModule(new Eagle());
        addModule(new FastPlace());
        addModule(new Fastbow());
        addModule(new Flight());
        addModule(new Fucker());
        addModule(new Fullbright());
        addModule(new HUD());
        addModule(new InvCleaner());
        addModule(new InvMove());
        addModule(new ItemPhysics());
        addModule(new Killaura());
        addModule(new IRC());
        addModule(new LagSign());
        addModule(new Longjump());
        addModule(new MCF());
        addModule(new Nametags());
        addModule(new NameProtect());
        addModule(new NoSlowDown());
        addModule(new NoSwing());
        addModule(new Nofall());
        addModule(new PotionSaver());
        addModule(new Phase());
        addModule(new Regen());
        addModule(new Scaffold());
        addModule(new ServerCrasher());
        addModule(new Speed());
        addModule(new Sprint());
        addModule(new TPAura());
        addModule(new WTap());
    }

    public static void load() {
        List<String> fileContent = FileUtils.read(MODULE_DIR);

        for (String line : fileContent) {
            try {
                String[] split = line.split(":");
                String name = split[0];
                String bind = split[1];
                String enable = split[2];
                int key = Integer.parseInt(bind);

                for (Module m : Base.INSTANCE.getModuleManager().modules.values()) {
                    if (!name.equalsIgnoreCase(m.getName())) {
                        continue;
                    }

                    m.setKeybind(key);

                    if (!enable.equalsIgnoreCase("true") || m.isEnabled()) {
                        continue;
                    }

                    if (!m.getName().equalsIgnoreCase("clickGuiFont") && (!m.getName().equalsIgnoreCase("CSGOGui"))) {
                        m.toggle();
                    }
                }
            } catch (Exception split) {
                System.err.println(split);
            }
        }
    }

    public static void save() {
        ArrayList<String> fileContent = new ArrayList<String>();

        for (Module m : Base.INSTANCE.getModuleManager().modules.values()) {
            fileContent.add(String.valueOf(m.getName()) + ":" + m.getKeybind() + ":" + m.isEnabled());
        }

        FileUtils.write(MODULE_DIR, fileContent, true);
    }

    public List<Module> getModsInCategory(Category Category) {
        List<Module> modList = new ArrayList<Module>();

        for (Module mod : TabGUI.getSortedModuleArray()) {
            if (mod.getCategory() == Category) {
                modList.add(mod);
            }
        }

        return modList;
    }

    /**
     * Method to add a module to the current map.
     *
     * @param module
     */

    private void addModule(Module module) {
        this.modules.put(module.getName(), module);
    }

    public Module getModByName(String theMod) {
        for (Module mod : modules.values()) {
            if (mod.getName().equalsIgnoreCase(theMod)) {
                return mod;
            }
        }

        return null;
    }

    public boolean hasDoubleValue(Module mod) {
        for (Setting s : Base.INSTANCE.getSettingManager().getSettingsByMod(mod)) {
            Double doub = s.doubleValue();
            Boolean bool = s.booleanValue();
            String stri = s.getValStringForSaving();

            if (doub != null && (Double) s.getMax() != 0.0) {
                return true;
            }
        }

        return false;
    }

    public boolean hasStringVal(Module mod) {
        try {
            for (Setting s : Base.INSTANCE.getSettingManager().getSettingsByMod(mod)) {
                Double doub = s.doubleValue();
                Boolean bool = s.booleanValue();
                String stri = s.getValStringForSaving();

                if (stri != null) {
                    return true;
                }
            }

            return false;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean hasBooleanVal(Module mod) {
        for (Setting s : Base.INSTANCE.getSettingManager().getSettingsByMod(mod)) {
            Double doub = s.doubleValue();
            Boolean bool = s.booleanValue();
            String stri = s.getValStringForSaving();

            if (bool != null && s.getMax() == 0.0 && s.getValStringForSaving() == null) {
                return true;
            }
        }

        return false;
    }
}
