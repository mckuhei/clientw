package me.satisfactory.base.events;


import me.satisfactory.base.events.event.Event;
import me.satisfactory.base.events.event.callables.EventCancellable;
import net.minecraft.block.Block;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;

/**
 * @author Zarzel.
 * @since 19/06/2017
 */
public class EventBBSet extends EventCancellable implements Event {
    private Block block;
    private BlockPos pos;
    private AxisAlignedBB boundingBox;

    public EventBBSet(Block block, BlockPos pos, AxisAlignedBB boundingBox) {
        this.block = block;
        this.pos = pos;
        this.boundingBox = boundingBox;
    }

    public Block getBlock() {
        return this.block;
    }

    public BlockPos getPos() {
        return this.pos;
    }

    public AxisAlignedBB getBoundingBox() {
        return this.boundingBox;
    }

    public void setBoundingBox(AxisAlignedBB boundingBox) {
        this.boundingBox = boundingBox;
    }
}
