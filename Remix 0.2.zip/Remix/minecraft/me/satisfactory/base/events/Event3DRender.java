package me.satisfactory.base.events;

import me.satisfactory.base.events.event.Event;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */
public class Event3DRender implements Event {
    public float partialTicks;

    public Event3DRender(float partialTicks) {
        this.partialTicks = partialTicks;
    }

    public float getPartialTicks() {
        return partialTicks;
    }
}