package me.satisfactory.base.events;

import me.satisfactory.base.events.event.EventType;
import me.satisfactory.base.events.event.callables.EventCancellable;
import me.satisfactory.base.events.event.Event;

public class EventMotion extends EventCancellable {
    public double x;
    public double y;
    public double z;
    public float yaw, pitch;
    public float lastReportedYaw, lastReportedPitch;
    private byte type;

    public EventMotion(float yaw, float pitch, float lastReportedYaw,
                       float lastReportedPitch) {
        this.yaw = yaw;
        this.pitch = pitch;
        this.lastReportedYaw = lastReportedYaw;
        this.lastReportedPitch = lastReportedPitch;
        this.type = EventType.PRE;
    }

    public EventMotion() {
        this.type = EventType.POST;
    }

    public double getX() {
        return this.x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return this.y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public double getZ() {
        return this.z;
    }

    public void setZ(double z) {
        this.z = z;
    }

    public float getYaw() {
        return this.yaw;
    }

    public void setYaw(float newyaw) {
        this.yaw = newyaw;
    }

    public float getPitch() {
        return this.pitch;
    }

    public void setPitch(float newpitch) {
        this.pitch = newpitch;
    }

    public byte getType() {
        return this.type;
    }

    // From EntityPlayerSP.java | line 319
    public boolean isRotating() {
        final double yaw = this.yaw - this.yaw;
        final double pitch = this.pitch - this.pitch;
        return Math.abs(yaw) != 0.0 || Math.abs(pitch) != 0.0;
    }
}
