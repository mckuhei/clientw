package me.satisfactory.base.events;

import me.satisfactory.base.events.event.Event;

/**
 * @author Zarzel.
 * @since 20/06/2017
 */
public class EventOpaqueBlock implements Event {
    public EventOpaqueBlock() {
    }
}
