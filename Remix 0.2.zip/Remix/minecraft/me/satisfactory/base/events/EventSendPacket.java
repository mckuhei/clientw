package me.satisfactory.base.events;

import me.satisfactory.base.events.event.Event;
import me.satisfactory.base.events.event.callables.EventCancellable;
import net.minecraft.network.Packet;

/**
 * @author Zarzel.
 * @since 28/07/2017
 */
public class EventSendPacket extends EventCancellable implements Event {
    private Packet packet;

    public EventSendPacket(Packet packet) {
        this.packet = packet;
    }

    public Packet getPacket() {
        return this.packet;
    }

    public void setPacket(Packet packet) {
        this.packet = packet;
    }
}
