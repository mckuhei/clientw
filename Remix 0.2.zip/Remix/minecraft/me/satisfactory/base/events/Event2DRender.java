package me.satisfactory.base.events;

import me.satisfactory.base.events.event.Event;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */
public class Event2DRender implements Event {
    public Event2DRender() {
    }
}
