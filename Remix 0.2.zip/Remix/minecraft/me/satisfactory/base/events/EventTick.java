package me.satisfactory.base.events;

import me.satisfactory.base.events.event.Event;

/**
 * @author Zarzel.
 * @since 22/06/2017
 */
public class EventTick implements Event {
}
