package me.satisfactory.base.events;

import me.satisfactory.base.events.event.Event;
import me.satisfactory.base.events.event.callables.EventCancellable;

/**
 * @author Zarzel.
 * @since 20/06/2017
 */
public class EventPushOutOfBlocks extends EventCancellable implements Event {
    public EventPushOutOfBlocks() {
    }
}
