package me.satisfactory.base.events;

import me.satisfactory.base.events.event.Event;
import me.satisfactory.base.events.event.callables.EventCancellable;
import net.minecraft.network.Packet;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */
public class EventPacketReceive extends EventCancellable implements Event {
    public Packet packet;

    public EventPacketReceive(Packet packet) {
        this.packet = packet;
    }

    /**
     * Gets the selected packet.
     *
     * @return packet.
     */
    public Packet getPacket() {
        return this.packet;
    }

    public void setPacket(Packet packet) {
        this.packet = packet;
    }
}
