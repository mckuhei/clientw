package me.satisfactory.base.hero.clickgui;

import me.satisfactory.base.hero.clickgui.component.Component;
import me.satisfactory.base.hero.clickgui.component.Frame;
import me.satisfactory.base.module.Category;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;

import java.util.ArrayList;

import org.lwjgl.input.Mouse;

public class ClickGui extends GuiScreen {
 public boolean clicked = false;
 int nignog = 50;
    public static ArrayList<Frame> frames;

    public ClickGui() {
        frames = new ArrayList<>();
        int frameX = 5;

        for (Category category : Category.values()) {
            if (category != Category.HIDDEN) {
                Frame frame = new Frame(category);
                frame.setX(frameX);
                frames.add(frame);
                frameX += frame.getWidth() + 1;
            }
        }
    }

    @Override
    public void initGui() {
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawDefaultBackground();
        
        for (Frame frame : frames) {
            frame.renderFrame(this.fontRendererObj);
            frame.updatePosition(mouseX, mouseY);

            for (Component comp : frame.getComponents()) {
                comp.updateComponent(mouseX, mouseY);
            }
        }
        if(Mouse.isButtonDown(0)) {
        	nignog = 50;
        clicked = true;
        }
        if(clicked)
        	nignog--;
        if(nignog <= 0) {
        	clicked = false;
        Gui.drawFilledCircle(mouseX, mouseY, nignog, 0x20FFFFFF);
        }
        
    }

    @Override
    protected void mouseClicked(final int mouseX, final int mouseY, final int mouseButton) {
    	
    	
        for (Frame frame : frames) {
            if (frame.isWithinHeader(mouseX, mouseY) && mouseButton == 0) {
                frame.setDrag(true);
                frame.dragX = mouseX - frame.getX();
                frame.dragY = mouseY - frame.getY();
            }

            if (frame.isWithinHeader(mouseX, mouseY) && mouseButton == 1) {
                frame.setOpen(!frame.isOpen());
            }

            if (frame.isOpen()) {
                if (!frame.getComponents().isEmpty()) {
                    for (Component component : frame.getComponents()) {
                        component.mouseClicked(mouseX, mouseY, mouseButton);
                    }
                }
            }
        }
        
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) {
        for (Frame frame : frames) {
            if (frame.isOpen() && keyCode != 1) {
                if (!frame.getComponents().isEmpty()) {
                    for (Component component : frame.getComponents()) {
                        component.keyTyped(typedChar, keyCode);
                    }
                }
            }
        }

        if (keyCode == 1) {
            mc.displayGuiScreen(null);
        }
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        for (Frame frame : frames) {
            frame.setDrag(false);
        }

        for (Frame frame : frames) {
            if (frame.isOpen()) {
                if (!frame.getComponents().isEmpty()) {
                    for (Component component : frame.getComponents()) {
                        component.mouseReleased(mouseX, mouseY, state);
                    }
                }
            }
        }
    }

    @Override
    public boolean doesGuiPauseGame() {
        return true;
    }
    public void circle(double n, double n2, double n3, int n4) {
        float n5 = (n4 >> 24 & 0xFF) / 255.0f;
        float n6 = (n4 >> 16 & 0xFF) / 255.0f;
        float n7 = (n4 >> 8 & 0xFF) / 255.0f;
        float n8 = (n4 & 0xFF) / 255.0f;
        GlStateManager.alphaFunc(516, 0.001f);
        GlStateManager.color(n6, n7, n8, n5);
        GlStateManager.enableAlpha();
        GlStateManager.enableBlend();
        GlStateManager.func_179090_x();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        Tessellator instance = Tessellator.getInstance();
        WorldRenderer worldRenderer = instance.getWorldRenderer();
        for (double n9 = 0.0; n9 < 360.0; ++n9) {
            double n10 = n9 * 3.141592653589793 / 180.0;
            double n11 = (n9 - 1.0) * 3.141592653589793 / 180.0;
            double[] array = { Math.cos(n10) * n3, -Math.sin(n10) * n3, Math.cos(n11) * n3, -Math.sin(n11) * n3 };
            worldRenderer.startDrawing(6);
            worldRenderer.addVertex(n + array[2], n2 + array[3], 0.0);
            worldRenderer.addVertex(n + array[0], n2 + array[1], 0.0);
            worldRenderer.addVertex(n, n2, 0.0);
            instance.draw();
        }
        GlStateManager.disableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.func_179098_w();
        GlStateManager.alphaFunc(516, 0.1f);
    }
}
