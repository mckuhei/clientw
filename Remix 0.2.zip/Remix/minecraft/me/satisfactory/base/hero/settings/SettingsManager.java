package me.satisfactory.base.hero.settings;

import me.satisfactory.base.Base;
import me.satisfactory.base.module.Mode;
import me.satisfactory.base.module.Module;
import me.satisfactory.base.setting.Setting;
import me.satisfactory.base.utils.file.FileUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Made by HeroCode
 * it's free to use
 * but you have to credit him
 *
 * @author HeroCode
 */
public class SettingsManager {
    private static final File SETTING_DIR;
    public static ArrayList<Setting> settings;

    static {
        SETTING_DIR = FileUtils.getConfigFile("Settings");
    }

    public SettingsManager() {
        settings = new ArrayList<>();
    }

    public static void load() {
        List<String> fileContent = FileUtils.read(SETTING_DIR);

        for (String line : fileContent) {
            try {
                String[] split = line.split(":");
                String name = split[0];
                String value = split[1];
                String whatitis = split[2];

                for (Setting m : settings) {
                    if (!name.equalsIgnoreCase(m.getName())) {
                        continue;
                    }

                    if (whatitis.equalsIgnoreCase("Double")) {
                        m.setValDouble(Double.parseDouble(value));
                        // MiscellaneousUtil.addChatMessage(name + " " + value + " double");
                    }

                    if (whatitis.equalsIgnoreCase("String")) {
                        Mode mode = null;

                        try {
                            for (Mode m2 : m.getParentMod().getModes()) {
                                if (!m2.getName().equalsIgnoreCase(value)) {
                                    continue;
                                }

                                mode = m2;
                            }

                            if (mode == null) {
                                continue;
                            }

                            m.getParentMod().setMode(mode);
                        } catch (Exception e10) {
                            e10.printStackTrace();
                        }
                    }

                    if (whatitis.equalsIgnoreCase("Boolean")) {
                        m.setValBoolean(Boolean.valueOf(value));
                        // MiscellaneousUtil.addChatMessage(name + " " + value + " boolean");
                    }
                }
            } catch (Exception split) {
                System.err.println(split);
            }
        }
    }

    public static void save() {
        ArrayList<String> fileContent = new ArrayList<String>();

        for (Setting setting : settings) {
            if (setting != null) {
                Double doub = setting.doubleValue();
                Boolean bool = setting.booleanValue();
                String stri = setting.getValStringForSaving();

                if (doub != null && setting.getMax() != 0.0) {
                    fileContent.add(setting.getName() + ":"
                            + setting.doubleValue() + ":Double");
                }

                if (stri != null) {
                    try {
                        fileContent.add(setting.getName() + ":"
                                + setting.getParentMod().getMode().getName() + ":String");
                    } catch (Exception ignored) {
                    }
                }

                if (bool != null && setting.getMax() == 0.0 && setting.getValStringForSaving() == null) {
                    fileContent.add(setting.getName() + ":"
                            + setting.booleanValue() + ":Boolean");
                }
            }
        }

        FileUtils.write(SETTING_DIR, fileContent, true);
    }

    public void rSetting(Setting in) {
        settings.add(in);
    }

    public ArrayList<Setting> getSettings() {
        return settings;
    }

    public ArrayList<Setting> getSettingsByMod(Module mod) {
        try {
            ArrayList<Setting> out = new ArrayList<Setting>();

            for (Setting s : getSettings()) {
                if (s.getParentMod().equals(mod)) {
                    out.add(s);
                }
            }

            if (out.isEmpty()) {
                return null;
            }

            return out;
        } catch (Exception e) {
            return null;
        }
    }

    public Setting getSettingByName(String name) {
        try {
            for (Setting set : getSettings()) {
                if (set.getName().equalsIgnoreCase(name)) {
                    return set;
                }
            }

            System.err.println("[" + Base.INSTANCE.getCLIENT_NAME() + "] Error Setting NOT found: '" + name + "'!");
            return null;
        } catch (Exception e) {
            return null;
        }
    }
}