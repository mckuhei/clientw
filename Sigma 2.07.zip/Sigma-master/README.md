Public source for Sigma. 

Any unauthorized redistributions of this will result in a legal notice.