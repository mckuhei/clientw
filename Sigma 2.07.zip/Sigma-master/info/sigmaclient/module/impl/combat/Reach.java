package info.sigmaclient.module.impl.combat;

import info.sigmaclient.event.Event;
import info.sigmaclient.module.Module;
import info.sigmaclient.module.data.ModuleData;

/**
 * Created by Arithmo on 5/31/2017 at 7:48 PM.
 */
public class Reach extends Module {

    private String REACH = "REACH";

    public Reach(ModuleData data) {
        super(data);
    }

    @Override
    public void onEvent(Event event) {

    }

}
