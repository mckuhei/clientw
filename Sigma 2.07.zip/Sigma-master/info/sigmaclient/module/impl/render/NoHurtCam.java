package info.sigmaclient.module.impl.render;

import info.sigmaclient.event.Event;
import info.sigmaclient.module.Module;
import info.sigmaclient.module.data.ModuleData;

/**
 * Created by Arithmo on 5/8/2017 at 7:02 PM.
 */
public class NoHurtCam extends Module {

    public NoHurtCam(ModuleData data) {
        super(data);
    }

    public void onEvent(Event event) {

    }

}
