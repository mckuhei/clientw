package info.sigmaclient.event.impl;

import info.sigmaclient.event.Event;

public class EventTick extends Event {
	
}
