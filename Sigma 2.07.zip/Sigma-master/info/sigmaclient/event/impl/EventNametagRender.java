package info.sigmaclient.event.impl;

import info.sigmaclient.event.Event;

public class EventNametagRender extends Event {

}
