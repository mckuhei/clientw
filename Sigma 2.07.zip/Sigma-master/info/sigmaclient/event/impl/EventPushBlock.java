/**
 * Time: 12:13:38 AM
 * Date: Jan 2, 2017
 * Creator: cool1
 */
package info.sigmaclient.event.impl;

import info.sigmaclient.event.Event;

/**
 * @author cool1
 *
 */
public class EventPushBlock extends Event {

	public void fire(){
		
	}
	
}
