package info.sigmaclient.management.notifications;

import java.util.List;

public interface INotificationRenderer {
	
	public void draw(List<INotification> notifications);
	
	
}
