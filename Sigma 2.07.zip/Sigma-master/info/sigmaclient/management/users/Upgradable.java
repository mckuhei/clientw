package info.sigmaclient.management.users;

/**
 * Created by Arithmo on 8/11/2017 at 9:37 PM.
 */
public interface Upgradable {

    void applyModules();

    void upgradeFeatures();

}
