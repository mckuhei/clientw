package info.sigmaclient.management.friend;

import java.util.UUID;

public class Friend
{
    public String name;
    public String alias;
    
    public Friend(final String name, final String alias) {
        this.name = name;
        this.alias = alias;
    }
}
