package info.sigmaclient.management.account.relation;

public enum EnumRelationship {
	Friend, Rival, Neutral
}
