package info.sigmaclient.gui.click.components;

/**
 * Created by Arithmo on 4/13/2017 at 12:02 AM.
 */
public class BindButton {



}
