package info.sigmaclient.gui.screen.impl.mainmenu;

/**
 * Created by Arithmo on 9/24/2017 at 12:23 PM.
 */
public class GuiFirstLaunch {
}
