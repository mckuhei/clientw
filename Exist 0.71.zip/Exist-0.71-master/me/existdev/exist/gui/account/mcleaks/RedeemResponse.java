package me.existdev.exist.gui.account.mcleaks;

class RedeemResponse {
   // $FF: synthetic field
   private String session;
   // $FF: synthetic field
   private String mcName;

   // $FF: synthetic method
   public String getSession() {
      return this.session;
   }

   // $FF: synthetic method
   public void setSession(String session) {
      this.session = session;
   }

   // $FF: synthetic method
   public String getMcName() {
      return this.mcName;
   }

   // $FF: synthetic method
   public void setMcName(String mcName) {
      this.mcName = mcName;
   }
}
