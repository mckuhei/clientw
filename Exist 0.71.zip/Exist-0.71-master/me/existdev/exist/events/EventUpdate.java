package me.existdev.exist.events;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;

public class EventUpdate extends EventCancellable implements Event {
}
