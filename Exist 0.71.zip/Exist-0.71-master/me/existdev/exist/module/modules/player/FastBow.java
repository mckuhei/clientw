package me.existdev.exist.module.modules.player;

import me.existdev.exist.module.Module;

public class FastBow extends Module {
   public FastBow() {
      super("FastBow", 0, Module.Category.Player);
   }
}
