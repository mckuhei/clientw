package me.existdev.exist.module.modules.render;

import me.existdev.exist.module.Module;

public class FullBright extends Module {
   public FullBright() {
      super("FullBright", 0, Module.Category.Render);
   }
}
