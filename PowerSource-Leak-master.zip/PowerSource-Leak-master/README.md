# Power B19 Source Leak
> 经过ZelixKiller & SkidderKiller 反混淆后，使用CFR进行反编译，通过对比MCP Map得到的源码。

本项目会持续到Power B19 Eclipse Ready。
由于涉及到DMCA，无法添加Minecraft客户端部分。

完整源码将会在完全Eclipse Ready后放出。

各位Skidder对着Modules抄就完了！