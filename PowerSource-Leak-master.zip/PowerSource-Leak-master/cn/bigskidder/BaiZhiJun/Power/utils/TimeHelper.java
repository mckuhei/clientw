/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.utils;

public enum Class161 {
    rcm(-15024996),
    rcg(-16711423),
    rca(-13710223),
    rcl(-13330213),
    rcb(-6596170),
    rci(-13350562),
    rcw(-932849),
    rce(-812014),
    rsd(-1618884),
    rsn(-1249039),
    rsp(-4340793),
    rsv(-14057287),
    rsj(-14176672),
    rsz(-15294331),
    rsq(-7453523),
    rsc(-13877680),
    rss(-1671646),
    rsx(-2927616),
    rso(-6969946),
    rsu(-4179669),
    rsy(-8418163);
    
    public int rsk;

    private Class161(int n2) {
        this.rsk = n2;
    }
}

