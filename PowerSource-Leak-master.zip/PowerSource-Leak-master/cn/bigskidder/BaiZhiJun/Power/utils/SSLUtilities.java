/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.utils;

import package3.package2.package1.Class2556;
import package3.package2.package1.package4133.Class0;
import package3.package2.package152.Class608;

public class Class155 {
    public static float rsh;
    public static float rsr;
    public static boolean rsf;

    static {
        rsf = false;
    }

    public static float jgp() {
        Class2556.nmk();
        return Class608.jp(Class2556.vhw.oi) - rsh;
    }

    public static float jgv() {
        Class2556.nmk();
        return Class608.jp(Class2556.vhw.ow) - rsr;
    }
}

