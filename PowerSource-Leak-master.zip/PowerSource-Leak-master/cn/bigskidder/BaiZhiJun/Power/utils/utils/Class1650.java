/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.utils.package4614;

import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C01PacketChatMessage;
import cn.bigskidder.BaiZhiJun.Power.utils.Class164;
import package3.package2.package1.Class2556;
import package3.package2.package1.package2064.Class2268;
import package3.package2.package1.package4133.Class0;
import package3.package2.package152.Class397;
import package3.package2.package152.Class398;

public class Class1650
implements Class164 {
    public static void vu(String string) {
        Class2556.vhw.n(new Class397(string));
    }

    public static void zr(String string) {
        Class2556.vhw.jao.j(new C01PacketChatMessage(string));
    }

    public static void zf(String string) {
        Class2556.vhw.zn(string);
    }
}

