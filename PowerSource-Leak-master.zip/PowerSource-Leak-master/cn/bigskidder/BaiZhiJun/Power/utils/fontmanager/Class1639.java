/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.utils.package5073;

public class Class1639 {
    private String vtp;
    private String vtv;

    public Class1639(String string, String string2) {
        this.vtp = string;
        this.vtv = string2;
    }

    public String ce() {
        return this.vtp;
    }

    public String nri() {
        return this.vtv;
    }

    public void vl(String string) {
        this.vtv = string;
    }
}

