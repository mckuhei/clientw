/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.utils;

public class Class1385 {
    public static void jhi() {
        System.exit(0);
    }
}

