/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.utils.package4337;

public class Class2487 {
    private boolean hls;

    public boolean qu(boolean bl) {
        if (bl) {
            if (!this.hls) {
                this.hls = true;
                return true;
            }
        } else {
            this.hls = false;
        }
        return false;
    }
}

