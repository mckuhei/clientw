/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.utils;

import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import cn.bigskidder.BaiZhiJun.Power.utils.Class164;
import package3.package2.package1.Class2556;
import package3.package2.package1.package2064.Class2268;
import package3.package2.package1.package4133.Class0;

public class Class1380
implements Class164 {
    public static void z(Packet packet) {
        Class2556.nms().we().sendPacketNoEvent(packet);
    }

    public static void q(Packet packet) {
        Class2556.vhw.jao.j(packet);
    }
}

