/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.utils;

import package3.package2.package1.Class2556;
import package3.package2.package1.package4133.Class0;
import package3.package2.package152.Class397;
import package3.package2.package152.Class398;

public class Class1401 {
    public static void kn(String string) {
        Class2556.nmk();
        Class2556.vhw.n(new Class397(string));
    }
}

