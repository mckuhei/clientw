/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.utils;

public enum Class160 {
    rqn,
    rqp,
    rqv;
    
}

