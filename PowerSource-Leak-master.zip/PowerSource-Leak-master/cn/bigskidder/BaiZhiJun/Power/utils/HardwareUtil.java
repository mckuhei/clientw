/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.utils;

public class Class158 {
    public double rcy;
    public double rck;
    public double rct;
    public double rch;
    public double rcr;
    public double rcf;

    public Class158(double d, double d2, double d3, double d4, double d5, double d6) {
        this.rcy = d;
        this.rck = d2;
        this.rct = d3;
        this.rch = d4;
        this.rcr = d5;
        this.rcf = d6;
    }
}

