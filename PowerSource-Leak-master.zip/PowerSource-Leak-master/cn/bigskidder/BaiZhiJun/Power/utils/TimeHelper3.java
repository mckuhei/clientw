/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.utils;

import package3.package2.package1.Class2556;

public interface Class164 {
    public static final Class2556 rqo = Class2556.nmk();
}

