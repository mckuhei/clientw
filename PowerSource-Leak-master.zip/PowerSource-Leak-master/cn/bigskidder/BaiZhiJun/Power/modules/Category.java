/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.modules;

public enum Category {
    Combat,
    World,
    Misc,
    Render,
    Player;
    
}

