/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.package185.package588;

public class Class200 {
    private String net = "";
    private final String neh;
    private String ner;

    public Class200(String string, String string2) {
        this(string, string2, "");
    }

    public Class200(String string, String string2, String string3) {
        this.neh = string;
        this.ner = string2;
        this.net = string3;
    }

    public String npz() {
        return this.net;
    }

    public String npq() {
        return this.ner;
    }

    public String npc() {
        return this.neh;
    }

    public void ne(String string) {
        this.net = string;
    }

    public void pd(String string) {
        this.ner = string;
    }
}

