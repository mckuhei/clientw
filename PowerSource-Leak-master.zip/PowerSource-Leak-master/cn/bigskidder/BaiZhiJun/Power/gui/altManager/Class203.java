/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.package185.package588;

import java.util.ArrayList;
import java.util.List;
import cn.bigskidder.BaiZhiJun.Power.package185.package588.Class200;

public class Class203 {
    static List<Class200> nwe;
    static Class200 ned;

    public static void ry() {
        Class203.npv();
        Class203.npj();
    }

    public Class200 npp() {
        return ned;
    }

    public void d(Class200 class200) {
        ned = class200;
    }

    public static void npv() {
        nwe = new ArrayList<Class200>();
    }

    public static List<Class200> npj() {
        return nwe;
    }
}

