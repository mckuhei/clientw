package me.slowly.client.shaders.fragment;

import me.slowly.client.shaders.SlowlyShader;

public class SlowlyParticleShader extends SlowlyShader {
   public SlowlyParticleShader() {
      super("particle.shader");
   }
}
