/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.package185.package4516;

import cn.bigskidder.BaiZhiJun.Power.package185.package4516.Class144;

//SlowlyParticleShader.java
public class Class137
extends Class144 {
    public Class137() {
        super("particle.shader");
    }
}

