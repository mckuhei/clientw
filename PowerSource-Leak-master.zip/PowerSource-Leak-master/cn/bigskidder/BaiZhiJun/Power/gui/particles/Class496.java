/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.lwjgl.util.vector.Vector2f
 */
package cn.bigskidder.BaiZhiJun.Power.package185.package4926;

import org.lwjgl.util.vector.Vector2f;

//Particle.java
public class Class496 {
    public Vector2f nwd = new Vector2f();

    public void pi(int n) {
    }
}

