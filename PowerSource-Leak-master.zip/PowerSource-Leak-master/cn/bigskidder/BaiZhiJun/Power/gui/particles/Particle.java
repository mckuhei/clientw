package me.slowly.client.ui.particles.particle;

import org.lwjgl.util.vector.Vector2f;

public class Particle {
   public Vector2f vector = new Vector2f();

   public void draw(int xAdd) {
   }
}
