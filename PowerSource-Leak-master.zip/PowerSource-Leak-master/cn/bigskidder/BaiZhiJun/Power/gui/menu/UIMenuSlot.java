/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.package185.package4102;

import package3.package2.package1.Class2556;
import package3.package2.package1.package0.Class970;

public class Class1123 {
    public String vgt;
    private Class970 vgh;
    public double vgr;

    public Class1123(String string, Class970 class970) {
        this.vgt = string;
        this.vgh = class970;
    }

    public void nre() {
        if (this.vgh == null) {
            Class2556.nmk().nfb();
        } else {
            Class2556.nmk().d(this.vgh);
        }
    }
}

