/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.package1087;

public class Class1818 {
    private String[] ea;
    private String el;

    public Class1818(String[] arrstring) {
        this.ea = arrstring;
    }

    public String[] tj() {
        return this.ea;
    }

    public void d(String[] arrstring) {
    }

    public void e(String string) {
        this.el = string;
    }

    public String tz() {
        return this.el;
    }
}

