/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.package1087.package2140;

import cn.bigskidder.BaiZhiJun.Power.package1087.Class1818;
import package3.package2.package1.Class2556;
import package3.package2.package1.package4133.Class0;

public class Class1626
extends Class1818 {
    public Class1626(String[] arrstring) {
        super(arrstring);
        this.e("-AutoBind");
    }

    @Override
    public void d(String[] arrstring) {
        Class2556.vhw.zn("-bind killaura R");
        Class2556.vhw.zn("-bind scaffold G");
        Class2556.vhw.zn("-bind zoomfly V");
        Class2556.vhw.zn("-bind speed T");
        Class2556.vhw.zn("-bind fly F");
        Class2556.vhw.zn("-bind ChestStealer X");
        Class2556.vhw.zn("-bind InvCleaner Y");
        Class2556.vhw.zn("-bind Fucker Z");
    }
}

