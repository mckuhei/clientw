/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.package1087.package2140;

import cn.bigskidder.BaiZhiJun.Power.Class2525;
import cn.bigskidder.BaiZhiJun.Power.package1087.Class1818;
import cn.bigskidder.BaiZhiJun.Power.package185.Class1610;
import cn.bigskidder.BaiZhiJun.Power.utils.Class1386;

public class Class1628
extends Class1818 {
    public Class1628(String[] arrstring) {
        super(arrstring);
    }

    @Override
    public void d(String[] arrstring) {
        Class1386.d(String.valueOf(Class2525.oiz) + " v" + Class2525.oix + " by suchen <3", Class1610.hez);
    }
}

