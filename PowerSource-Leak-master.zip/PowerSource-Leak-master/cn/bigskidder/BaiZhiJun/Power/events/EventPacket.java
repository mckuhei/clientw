/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.package858;

import com.darkmagician6.eventapi.events.Event;

public class Class2230
implements Event {
    public boolean kw;

    public Class2230(boolean bl) {
        this.kw = bl;
    }

    public void r(boolean bl) {
        this.kw = bl;
    }
}

