/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.package858;

import com.darkmagician6.eventapi.events.Event;
import net.minecraft.network.Packet;

public class Class2255
implements Event {
    private Packet kh;
    public boolean kr;

    public Class2255(Packet packet) {
        this.kh = packet;
    }

    public Packet xv() {
        return this.kh;
    }
}

