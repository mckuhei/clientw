/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.package858;

import com.darkmagician6.eventapi.events.Event;

public class Class2227
implements Event {
    private float hi;

    public Class2227(float f) {
        this.hi = f;
    }

    public float on() {
        return this.hi;
    }

    public void m(float f) {
        this.hi = f;
    }
}

