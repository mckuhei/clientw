/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.package858;

import com.darkmagician6.eventapi.events.Event;
import package3.package2.package1.package0.Class1815;

public class Class2204
implements Event {
    private Class1815 ks;

    public Class1815 sg() {
        return this.ks;
    }
}

