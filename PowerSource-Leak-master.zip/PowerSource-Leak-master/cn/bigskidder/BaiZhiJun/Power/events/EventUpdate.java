/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.package858;

public enum Class2202 {
    kf,
    km;
    
}

