/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.package858;

import com.darkmagician6.eventapi.events.Event;

public class Class2210
implements Event {
    public float hy;
    public float hk;
    public double ht;
    public double hh;
    public double hr;
    public boolean hf;

    public Class2210(float f, float f2, double d, double d2, double d3, boolean bl) {
        this.hy = f;
        this.hk = f2;
        this.hh = d2;
        this.ht = d;
        this.hr = d3;
        this.hf = bl;
    }
}

