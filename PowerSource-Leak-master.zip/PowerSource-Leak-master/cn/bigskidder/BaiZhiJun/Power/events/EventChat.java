/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.package858;

import com.darkmagician6.eventapi.events.Event;
import java.util.List;
import package3.package2.package152.Class614;
import package3.package2.package152.Class891;
import package3.package2.package159.package520.Class1789;

public class Class2199
implements Event {
    public Class1789 tm;
    public Class891 tg;
    public List<Class614> ta;

    public Class2199(Class1789 class1789, Class891 class891, List<Class614> list) {
        this.tm = class1789;
        this.tg = class891;
        this.ta = list;
    }
}

