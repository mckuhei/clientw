/*
 * Decompiled with CFR 0.145.
 */
package cn.bigskidder.BaiZhiJun.Power.package858;

import com.darkmagician6.eventapi.events.Event;
import package3.package2.package159.Class1886;

public class Class2252
implements Event {
    private int hs;
    private int hx;
    private int ho;
    private Class1886 hu;

    public Class2252(int n, int n2, int n3, Class1886 class1886) {
        this.hs = n;
        this.hx = n2;
        this.ho = n3;
        this.hu = class1886;
    }

    public int xl() {
        return this.hs;
    }

    public int xb() {
        return this.hx;
    }

    public int xi() {
        return this.ho;
    }

    public Class1886 xk() {
        return this.hu;
    }
}

