package net.minecraft.entity.player.Really.Client.utils.proxy;

public class ConnectionInfo {
   public String ip;
   public int port;
}
