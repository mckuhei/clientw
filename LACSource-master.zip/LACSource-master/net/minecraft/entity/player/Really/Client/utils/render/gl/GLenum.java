/*
 * Decompiled with CFR 0_132.
 */
package net.minecraft.entity.player.Really.Client.utils.render.gl;

public interface GLenum {
    public String getName();

    public int getCap();
}

