package net.minecraft.entity.player.Really.Client.module.modules.render;

import net.minecraft.entity.player.Really.Client.module.Module;
import net.minecraft.entity.player.Really.Client.module.ModuleType;

public class ViewClip extends Module {
   public ViewClip() {
      super("ViewClip", new String[]{"ViewClip"}, ModuleType.Render);
   }
}
