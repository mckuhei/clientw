package net.minecraft.entity.player.Really.Client.utils;

import net.minecraft.entity.player.Really.Client.api.Event;

public class EventClickMouse extends Event {
}
