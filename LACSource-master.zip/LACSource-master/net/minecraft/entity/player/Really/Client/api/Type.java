package net.minecraft.entity.player.Really.Client.api;

public class Type {
   public static final byte PRE = 0;
   public static final byte POST = 1;
   public static final byte OUTGOING = 2;
   public static final byte INCOMING = 3;
}
