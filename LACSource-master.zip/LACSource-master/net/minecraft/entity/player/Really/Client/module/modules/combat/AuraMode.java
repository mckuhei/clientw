package net.minecraft.entity.player.Really.Client.module.modules.combat;

enum AuraMode {
   Switch;
}
