package net.minecraft.entity.player.Really.Client.module.modules.render;

import net.minecraft.entity.player.Really.Client.module.Module;
import net.minecraft.entity.player.Really.Client.module.ModuleType;

public class ItemPhysic extends Module {
   public ItemPhysic() {
      super("ItemPhysic", new String[]{"ItemPhysic"}, ModuleType.Render);
   }
}
