package net.minecraft.entity.player.Really.Client.module;

public enum ModuleType {
   Combat,
   Render,
   Movement,
   Player,
   World,
   Legit;
}
