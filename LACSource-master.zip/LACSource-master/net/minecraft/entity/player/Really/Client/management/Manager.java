package net.minecraft.entity.player.Really.Client.management;

public interface Manager {
   void init();
}
