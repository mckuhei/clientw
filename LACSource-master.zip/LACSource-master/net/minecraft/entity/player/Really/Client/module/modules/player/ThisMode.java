package net.minecraft.entity.player.Really.Client.module.modules.player;

enum ThisMode {
   Normal,
   AAC;
}
