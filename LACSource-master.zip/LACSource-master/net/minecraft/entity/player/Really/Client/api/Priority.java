package net.minecraft.entity.player.Really.Client.api;

public class Priority {
   public static final byte HIGH = 0;
   public static final byte NORMAL = 1;
   public static final byte LOW = 2;
}
