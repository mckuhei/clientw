# Envy
This is an 1.8.8 Minecraft Hacked Client. Remove the AltLogin code from Envy.java before compiling client.
