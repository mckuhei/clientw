package net.minecraft.block;

public class BlockButtonStone extends BlockButton
{
    protected BlockButtonStone()
    {
        super(false);
    }
}
